<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Lapor Tamu';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';
define('MAX_EDIT_TAMU', 3);

$pendudukUser = null;
if (!isAdmin()) {
    $s = $pdo->prepare("SELECT * FROM penduduk WHERE user_id=? AND status='aktif'");
    $s->execute([$user['id']]); $pendudukUser = $s->fetch();
}

// Proses TAMBAH
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'buat') {
    $pid      = isAdmin() ? intval($_POST['penduduk_id']) : ($pendudukUser['id'] ?? 0);
    $namaTamu = trim($_POST['nama_tamu']);
    $nikTamu  = trim($_POST['nik_tamu']);
    $alamatT  = trim($_POST['alamat_tamu']);
    $kotaT    = trim($_POST['kota_tamu']);
    $hubungan = trim($_POST['hubungan']);
    $tglD     = $_POST['tanggal_datang'];
    $tglP     = $_POST['tanggal_pergi'] ?: null;
    $keperluan= trim($_POST['keperluan']);

    if (!$pid)       $error = 'Data penduduk tidak ditemukan.';
    elseif (!$namaTamu) $error = 'Nama tamu wajib diisi.';
    elseif (!$tglD)  $error = 'Tanggal datang wajib diisi.';
    else {
        $pdo->prepare(
            "INSERT INTO laporan_tamu (penduduk_id,nama_tamu,nik_tamu,alamat_tamu,kota_tamu,hubungan,tanggal_datang,tanggal_pergi,keperluan,dibuat_oleh)
             VALUES (?,?,?,?,?,?,?,?,?,?)"
        )->execute([$pid,$namaTamu,$nikTamu,$alamatT,$kotaT,$hubungan,$tglD,$tglP,$keperluan,$user['id']]);
        setFlash('success','Laporan tamu berhasil dikirim.');
        redirect('lapor_tamu.php');
    }
}

// Proses EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit') {
    $lid      = intval($_POST['lap_id']);
    $namaTamu = trim($_POST['nama_tamu']);
    $alamatT  = trim($_POST['alamat_tamu']);
    $kotaT    = trim($_POST['kota_tamu']);
    $hubungan = trim($_POST['hubungan']);
    $tglD     = $_POST['tanggal_datang'];
    $tglP     = $_POST['tanggal_pergi'] ?: null;
    $keperluan= trim($_POST['keperluan']);

    $cek = $pdo->prepare("SELECT * FROM laporan_tamu WHERE id=? AND dibuat_oleh=?");
    $cek->execute([$lid,$user['id']]); $lap = $cek->fetch();

    if (!$lap)                                       $error = 'Laporan tidak ditemukan.';
    elseif ($lap['edit_count'] >= MAX_EDIT_TAMU)     $error = 'Batas edit telah mencapai maksimal ' . MAX_EDIT_TAMU . ' kali.';
    elseif (!$namaTamu)                              $error = 'Nama tamu wajib diisi.';
    else {
        $pdo->prepare("UPDATE laporan_tamu SET nama_tamu=?,alamat_tamu=?,kota_tamu=?,hubungan=?,tanggal_datang=?,tanggal_pergi=?,keperluan=?,edit_count=edit_count+1 WHERE id=?")
            ->execute([$namaTamu,$alamatT,$kotaT,$hubungan,$tglD,$tglP,$keperluan,$lid]);
        setFlash('success','Laporan tamu diperbarui ('.($lap['edit_count']+1).'/'.MAX_EDIT_TAMU.' edit).');
        redirect('lapor_tamu.php');
    }
}

// Proses tandai sudah pergi
if (isset($_GET['pergi'])) {
    $pid = intval($_GET['pergi']);
    $pdo->prepare("UPDATE laporan_tamu SET status='sudah pergi',tanggal_pergi=CURDATE() WHERE id=? AND dibuat_oleh=?")
        ->execute([$pid,$user['id']]);
    setFlash('info','Status tamu diperbarui menjadi sudah pergi.');
    redirect('lapor_tamu.php');
}

$riwayat = [];
if ($pendudukUser) {
    $s = $pdo->prepare("SELECT * FROM laporan_tamu WHERE penduduk_id=? ORDER BY created_at DESC");
    $s->execute([$pendudukUser['id']]); $riwayat = $s->fetchAll();
}

$editLap = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $s   = $pdo->prepare("SELECT * FROM laporan_tamu WHERE id=? AND dibuat_oleh=?");
    $s->execute([$eid,$user['id']]); $editLap = $s->fetch();
    if ($editLap && $editLap['edit_count'] >= MAX_EDIT_TAMU) $editLap = null;
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4" style="max-width:860px">
  <div class="d-flex align-items-center gap-2 mb-4">
    <a href="../index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
      <h4 class="fw-bold mb-0"><i class="bi bi-person-plus text-info me-1"></i>Lapor Tamu Menginap</h4>
      <small class="text-muted">Daftarkan tamu yang menginap di rumah kamu</small>
    </div>
  </div>
  <?= flashHtml() ?>

  <?php if (!$pendudukUser && !isAdmin()): ?>
  <div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle me-1"></i>
    Data penduduk kamu belum terdaftar. Hubungi Pak RT untuk pendataan.
  </div>
  <?php else: ?>

  <div class="card mb-4">
    <div class="card-header d-flex align-items-center gap-2">
      <i class="bi bi-<?= $editLap ? 'pencil' : 'file-earmark-plus' ?>"></i>
      <?= $editLap ? 'Edit Laporan Tamu' : 'Form Laporan Tamu' ?>
      <?php if ($editLap): ?>
      <span class="badge bg-info ms-auto"><?= $editLap['edit_count'] ?>/<?= MAX_EDIT_TAMU ?> edit</span>
      <?php endif; ?>
    </div>
    <div class="card-body">
      <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>
      <div class="alert alert-info small mb-3">
        <i class="bi bi-info-circle me-1"></i>
        Wajib lapor jika ada tamu menginap lebih dari <strong>1×24 jam</strong>.
        Laporan dapat diedit maksimal <strong><?= MAX_EDIT_TAMU ?> kali</strong>.
      </div>
      <form method="POST">
        <input type="hidden" name="aksi" value="<?= $editLap ? 'edit' : 'buat' ?>">
        <?php if ($editLap): ?><input type="hidden" name="lap_id" value="<?= $editLap['id'] ?>"><?php endif; ?>
        <?php if (!$editLap && isAdmin()): ?>
        <div class="mb-3">
          <label class="form-label fw-semibold small">Rumah yang Dikunjungi <span class="text-danger">*</span></label>
          <?php
          $allP = $pdo->query("SELECT id,nama,nik FROM penduduk WHERE status='aktif' ORDER BY nama")->fetchAll();
          ?>
          <select name="penduduk_id" class="form-select" required>
            <option value="">-- Pilih Penduduk --</option>
            <?php foreach ($allP as $p): ?>
            <option value="<?= $p['id'] ?>"><?= clean($p['nama']) ?> — NIK: <?= clean($p['nik']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php elseif (!$editLap && $pendudukUser): ?>
        <div class="alert alert-info small mb-3">
          <i class="bi bi-house me-1"></i>Tamu bertamu ke rumah: <strong><?= clean($pendudukUser['nama']) ?></strong>
        </div>
        <?php if (!isAdmin()): ?>
        <input type="hidden" name="penduduk_id" value="<?= $pendudukUser['id'] ?>">
        <?php endif; ?>
        <?php endif; ?>

        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Nama Tamu <span class="text-danger">*</span></label>
            <input type="text" name="nama_tamu" class="form-control"
                   value="<?= $editLap ? clean($editLap['nama_tamu']) : '' ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">NIK Tamu</label>
            <input type="text" name="nik_tamu" class="form-control font-monospace" maxlength="16"
                   inputmode="numeric" placeholder="(opsional)"
                   value="<?= $editLap ? clean($editLap['nik_tamu']) : '' ?>"
                   oninput="this.value=this.value.replace(/\D/g,'').slice(0,16)">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Kota Asal Tamu</label>
            <input type="text" name="kota_tamu" class="form-control" placeholder="cth: Semarang"
                   value="<?= $editLap ? clean($editLap['kota_tamu']) : '' ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Hubungan dengan Tuan Rumah</label>
            <input type="text" name="hubungan" class="form-control" placeholder="Saudara, Teman, dll."
                   value="<?= $editLap ? clean($editLap['hubungan']) : '' ?>">
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Alamat Tamu</label>
            <input type="text" name="alamat_tamu" class="form-control"
                   value="<?= $editLap ? clean($editLap['alamat_tamu']) : '' ?>">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold small">Tanggal Datang <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_datang" class="form-control"
                   value="<?= $editLap ? $editLap['tanggal_datang'] : today() ?>" required>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold small">Rencana Tanggal Pergi</label>
            <input type="date" name="tanggal_pergi" class="form-control"
                   value="<?= $editLap && $editLap['tanggal_pergi'] ? $editLap['tanggal_pergi'] : '' ?>">
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Keperluan / Tujuan</label>
            <textarea name="keperluan" class="form-control" rows="2" placeholder="Liburan, menghadiri acara, dll."><?= $editLap ? clean($editLap['keperluan']) : '' ?></textarea>
          </div>
          <div class="col-12 d-flex gap-2 flex-wrap">
            <button type="submit" class="btn btn-info text-white px-4">
              <i class="bi bi-send me-1"></i><?= $editLap ? 'Simpan Perubahan' : 'Kirim Laporan' ?>
            </button>
            <?php if ($editLap): ?><a href="lapor_tamu.php" class="btn btn-outline-secondary">Batal</a><?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php if (!empty($riwayat)): ?>
  <div class="card">
    <div class="card-header"><i class="bi bi-clock-history me-1"></i>Riwayat Laporan Tamu</div>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 small">
        <thead class="table-light">
          <tr><th>Nama Tamu</th><th>Hubungan</th><th>Tgl Datang</th><th>Tgl Pergi</th><th>Status</th><th>Edit</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php foreach ($riwayat as $r): ?>
          <tr>
            <td class="fw-semibold"><?= clean($r['nama_tamu']) ?></td>
            <td class="text-muted"><?= clean($r['hubungan'] ?: '-') ?></td>
            <td><?= formatTanggal($r['tanggal_datang']) ?></td>
            <td><?= $r['tanggal_pergi'] ? formatTanggal($r['tanggal_pergi']) : '<span class="text-warning">Masih di sini</span>' ?></td>
            <td><?= statusBadge($r['status']) ?></td>
            <td>
              <span class="badge bg-<?= $r['edit_count'] >= MAX_EDIT_TAMU ? 'secondary' : 'light text-dark' ?>">
                <?= $r['edit_count'] ?>/<?= MAX_EDIT_TAMU ?>
              </span>
            </td>
            <td class="d-flex gap-1">
              <?php if ($r['edit_count'] < MAX_EDIT_TAMU): ?>
              <a href="?edit=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                <i class="bi bi-pencil"></i>
              </a>
              <?php endif; ?>
              <?php if ($r['status'] === 'menginap'): ?>
              <a href="?pergi=<?= $r['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Tandai sudah pergi"
                 onclick="return confirm('Tandai tamu sudah pergi?')">
                <i class="bi bi-door-open"></i>
              </a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
