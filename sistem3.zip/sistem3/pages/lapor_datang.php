<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Lapor Datang';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';
define('MAX_EDIT_DATANG', 3);

// Proses TAMBAH
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'buat') {
    $nik       = trim($_POST['nik']);
    $no_kk     = trim($_POST['no_kk']);
    $nama      = trim($_POST['nama']);
    $jk        = $_POST['jenis_kelamin'];
    $tl        = trim($_POST['tempat_lahir']);
    $tgl_l     = $_POST['tanggal_lahir'];
    $asal      = trim($_POST['alamat_asal']);
    $kota_asal = trim($_POST['kota_asal']);
    $tgl_d     = $_POST['tanggal_datang'];
    $alasan    = trim($_POST['alasan']);

    if (strlen($nik) !== 16 || !ctype_digit($nik)) $error = 'NIK harus 16 digit angka.';
    elseif (!$nama)  $error = 'Nama wajib diisi.';
    elseif (!$asal)  $error = 'Alamat asal wajib diisi.';
    elseif (!$tgl_d) $error = 'Tanggal datang wajib diisi.';
    else {
        $pdo->prepare(
            "INSERT INTO laporan_datang (nik,no_kk,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,
             alamat_asal,kota_asal,tanggal_datang,alasan,dibuat_oleh) VALUES (?,?,?,?,?,?,?,?,?,?,?)"
        )->execute([$nik,$no_kk,$nama,$jk,$tl,$tgl_l,$asal,$kota_asal,$tgl_d,$alasan,$user['id']]);
        setFlash('success','Laporan datang berhasil dikirim. Menunggu persetujuan Pak RT.');
        redirect('lapor_datang.php');
    }
}

// Proses EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit') {
    $lid  = intval($_POST['lap_id']);
    $asal = trim($_POST['alamat_asal']);
    $kota = trim($_POST['kota_asal']);
    $tgl_d= $_POST['tanggal_datang'];
    $alasan=trim($_POST['alasan']);

    $cek = $pdo->prepare("SELECT * FROM laporan_datang WHERE id=? AND dibuat_oleh=?");
    $cek->execute([$lid, $user['id']]); $lap = $cek->fetch();

    if (!$lap)                                          $error = 'Laporan tidak ditemukan.';
    elseif ($lap['status'] === 'disetujui')             $error = 'Laporan yang sudah disetujui tidak dapat diedit.';
    elseif ($lap['edit_count'] >= MAX_EDIT_DATANG)      $error = 'Batas edit telah mencapai maksimal ' . MAX_EDIT_DATANG . ' kali.';
    elseif (!$asal)                                     $error = 'Alamat asal wajib diisi.';
    else {
        $pdo->prepare("UPDATE laporan_datang SET alamat_asal=?,kota_asal=?,tanggal_datang=?,alasan=?,edit_count=edit_count+1,status='pending' WHERE id=?")
            ->execute([$asal,$kota,$tgl_d,$alasan,$lid]);
        setFlash('success','Laporan berhasil diperbarui ('.($lap['edit_count']+1).'/'.MAX_EDIT_DATANG.' edit).');
        redirect('lapor_datang.php');
    }
}

// Riwayat
$riwayat = $pdo->prepare("SELECT * FROM laporan_datang WHERE dibuat_oleh=? ORDER BY created_at DESC");
$riwayat->execute([$user['id']]);
$riwayat = $riwayat->fetchAll();

$editLap = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $s   = $pdo->prepare("SELECT * FROM laporan_datang WHERE id=? AND dibuat_oleh=?");
    $s->execute([$eid, $user['id']]); $editLap = $s->fetch();
    if ($editLap && ($editLap['status'] === 'disetujui' || $editLap['edit_count'] >= MAX_EDIT_DATANG)) $editLap = null;
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4" style="max-width:860px">
  <div class="d-flex align-items-center gap-2 mb-4">
    <a href="../index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
      <h4 class="fw-bold mb-0">Lapor Datang</h4>
      <small class="text-muted">Pendataan warga baru yang pindah ke RT 001/RW 003</small>
    </div>
  </div>
  <?= flashHtml() ?>

  <div class="card mb-4">
    <div class="card-header d-flex align-items-center gap-2">
      <i class="bi bi-<?= $editLap ? 'pencil' : 'file-earmark-plus' ?>"></i>
      <?= $editLap ? 'Edit Laporan Datang' : 'Form Laporan Kedatangan' ?>
      <?php if ($editLap): ?>
      <span class="badge bg-warning ms-auto"><?= $editLap['edit_count'] ?>/<?= MAX_EDIT_DATANG ?> edit</span>
      <?php endif; ?>
    </div>
    <div class="card-body">
      <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>
      <?php if (!$editLap): ?>
      <div class="alert alert-info small mb-3">
        <i class="bi bi-info-circle me-1"></i>
        Gunakan form ini untuk mendaftarkan warga baru yang pindah ke wilayah RT 001/RW 003.
        Laporan dapat diedit maksimal <strong><?= MAX_EDIT_DATANG ?> kali</strong> sebelum disetujui.
      </div>
      <?php endif; ?>
      <form method="POST">
        <input type="hidden" name="aksi" value="<?= $editLap ? 'edit' : 'buat' ?>">
        <?php if ($editLap): ?><input type="hidden" name="lap_id" value="<?= $editLap['id'] ?>"><?php endif; ?>

        <?php if (!$editLap): ?>
        <div class="row g-3 mb-3">
          <div class="col-12"><p class="fw-bold text-success small mb-0"><i class="bi bi-person-vcard me-1"></i>Data Warga Baru</p></div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">NIK (16 digit) <span class="text-danger">*</span></label>
            <input type="text" name="nik" class="form-control font-monospace" maxlength="16"
                   inputmode="numeric" placeholder="3471XXXXXXXXXXXX"
                   value="<?= clean($_POST['nik'] ?? '') ?>" required
                   oninput="this.value=this.value.replace(/\D/g,'').slice(0,16)">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">No. KK</label>
            <input type="text" name="no_kk" class="form-control font-monospace" maxlength="16"
                   inputmode="numeric" placeholder="(opsional)"
                   value="<?= clean($_POST['no_kk'] ?? '') ?>"
                   oninput="this.value=this.value.replace(/\D/g,'').slice(0,16)">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Nama Lengkap <span class="text-danger">*</span></label>
            <input type="text" name="nama" class="form-control" value="<?= clean($_POST['nama'] ?? '') ?>" required>
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold small">Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-select">
              <option value="L">Laki-laki</option><option value="P">Perempuan</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label fw-semibold small">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Tempat Lahir</label>
            <input type="text" name="tempat_lahir" class="form-control" value="<?= clean($_POST['tempat_lahir'] ?? '') ?>">
          </div>
        </div>
        <hr class="my-3">
        <p class="fw-bold text-primary small mb-3"><i class="bi bi-geo-alt me-1"></i>Info Kedatangan</p>
        <?php endif; ?>

        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label fw-semibold small">Tanggal Datang <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_datang" class="form-control"
                   value="<?= $editLap ? $editLap['tanggal_datang'] : today() ?>" required>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold small">Kota / Kab. Asal</label>
            <input type="text" name="kota_asal" class="form-control" placeholder="cth: Klaten"
                   value="<?= $editLap ? clean($editLap['kota_asal']) : clean($_POST['kota_asal'] ?? '') ?>">
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Alamat Asal Lengkap <span class="text-danger">*</span></label>
            <textarea name="alamat_asal" class="form-control" rows="2" required><?= $editLap ? clean($editLap['alamat_asal']) : '' ?></textarea>
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Alasan Pindah ke Sini</label>
            <textarea name="alasan" class="form-control" rows="2" placeholder="Menikah, pindah kerja, dll."><?= $editLap ? clean($editLap['alasan']) : '' ?></textarea>
          </div>
          <div class="col-12 d-flex gap-2 flex-wrap">
            <button type="submit" class="btn btn-primary px-4">
              <i class="bi bi-send me-1"></i><?= $editLap ? 'Simpan Perubahan' : 'Kirim Laporan' ?>
            </button>
            <?php if ($editLap): ?>
            <a href="lapor_datang.php" class="btn btn-outline-secondary">Batal</a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Riwayat -->
  <?php if (!empty($riwayat)): ?>
  <div class="card">
    <div class="card-header"><i class="bi bi-clock-history me-1"></i>Riwayat Laporan Datang</div>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 small">
        <thead class="table-light">
          <tr><th>Nama</th><th>NIK</th><th>Tgl Datang</th><th>Asal</th><th>Status</th><th>Catatan</th><th>Edit</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php foreach ($riwayat as $r): ?>
          <tr>
            <td class="fw-semibold"><?= clean($r['nama']) ?></td>
            <td class="font-monospace text-muted"><?= clean($r['nik']) ?></td>
            <td><?= formatTanggal($r['tanggal_datang']) ?></td>
            <td><?= clean($r['kota_asal'] ?: '-') ?></td>
            <td><?= statusBadge($r['status']) ?></td>
            <td class="text-muted"><?= clean($r['catatan_admin'] ?: '-') ?></td>
            <td>
              <span class="badge bg-<?= $r['edit_count'] >= MAX_EDIT_DATANG ? 'secondary' : 'light text-dark' ?>">
                <?= $r['edit_count'] ?>/<?= MAX_EDIT_DATANG ?>
              </span>
            </td>
            <td>
              <?php if ($r['status'] === 'pending' && $r['edit_count'] < MAX_EDIT_DATANG): ?>
              <a href="?edit=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary">
                <i class="bi bi-pencil"></i>
              </a>
              <?php else: ?>
              <span class="text-muted">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
