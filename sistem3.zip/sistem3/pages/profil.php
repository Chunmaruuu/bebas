<?php
// pages/profil.php — Profil Warga (v4.1)
// Fitur: foto profil, lihat dokumen registrasi, edit akun, edit kependudukan (izin admin)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Profil Saya';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';

// ── Ambil data ──────────────────────────────────────────────────────
$userData = $pdo->prepare("SELECT * FROM users WHERE id=?");
$userData->execute([$user['id']]); $userData = $userData->fetch();

// Jika data user tidak ditemukan, hentikan proses
if (!$userData) {
    setFlash('error', 'Data pengguna tidak ditemukan. Silakan login ulang.');
    redirect('../index.php');
    exit;
}

$pendudukData = $pdo->prepare("SELECT * FROM penduduk WHERE user_id=?");
$pendudukData->execute([$user['id']]); $pendudukData = $pendudukData->fetch();

// Dokumen registrasi (foto KTP & KK yang diupload saat daftar)
$regData = $pdo->prepare("SELECT foto_ktp, foto_kk FROM registrasi_warga WHERE username=? ORDER BY created_at DESC LIMIT 1");
$regData->execute([$userData['username'] ?? '']); $regData = $regData->fetch();

// Request edit yang masih menunggu (akun)
$editPendingAkun = $pdo->prepare("SELECT * FROM edit_profil_request WHERE user_id=? AND status='menunggu' AND tipe_request='akun' ORDER BY created_at DESC LIMIT 1");
$editPendingAkun->execute([$user['id']]); $editPendingAkun = $editPendingAkun->fetch();

// Request edit yang masih menunggu (kependudukan)
$editPendingKep = $pdo->prepare("SELECT * FROM edit_profil_request WHERE user_id=? AND status='menunggu' AND tipe_request='kependudukan' ORDER BY created_at DESC LIMIT 1");
$editPendingKep->execute([$user['id']]); $editPendingKep = $editPendingKep->fetch();

// ── Upload Foto Profil ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'upload_foto') {
    $file = $_FILES['foto_profil'] ?? null;
    $uploadErrMsg = [
        UPLOAD_ERR_INI_SIZE   => 'Ukuran file melebihi batas server (upload_max_filesize).',
        UPLOAD_ERR_FORM_SIZE  => 'Ukuran file melebihi batas formulir.',
        UPLOAD_ERR_PARTIAL    => 'File hanya terunggah sebagian. Coba lagi.',
        UPLOAD_ERR_NO_FILE    => 'Tidak ada file yang dipilih.',
        UPLOAD_ERR_NO_TMP_DIR => 'Direktori sementara tidak tersedia.',
        UPLOAD_ERR_CANT_WRITE => 'Gagal menyimpan file. Periksa izin folder.',
        UPLOAD_ERR_EXTENSION  => 'Upload dihentikan oleh ekstensi PHP.',
    ];
    if (!$file || !isset($file['error'])) {
        $error = 'Tidak ada file yang diterima. Pastikan Anda memilih foto.';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $error = $uploadErrMsg[$file['error']] ?? 'Gagal mengunggah foto (kode: ' . $file['error'] . ').';
    } elseif ($file['size'] === 0) {
        $error = 'File foto kosong (0 byte). Silakan pilih file lain.';
    } else {
        $allowed = ['image/jpeg','image/jpg','image/png','image/webp'];
        $mime    = mime_content_type($file['tmp_name']);
        if (!in_array($mime, $allowed)) {
            $error = 'Format foto harus JPG, PNG, atau WEBP. Format terdeteksi: ' . $mime;
        } elseif ($file['size'] > 2 * 1024 * 1024) {
            $error = 'Ukuran foto maksimal 2MB. Ukuran file: ' . round($file['size']/1024/1024,1) . 'MB';
        } else {
            $uploadDir = __DIR__ . '/../uploads/profil/';
            // Buat direktori jika belum ada (rekursif)
            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0755, true)) {
                    $error = 'Gagal membuat folder upload. Hubungi administrator.';
                }
            }
            if (!$error) {
                // Hapus foto lama jika ada
                if (!empty($userData['foto_profil'])) {
                    $oldPath = __DIR__ . '/../uploads/' . $userData['foto_profil'];
                    if (file_exists($oldPath)) @unlink($oldPath);
                }
                // Sanitasi ekstensi berdasarkan MIME type (bukan nama file dari user)
                $mimeExt = ['image/jpeg'=>'jpg','image/jpg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
                $ext   = $mimeExt[$mime] ?? 'jpg';
                $fname = 'profil_' . $user['id'] . '_' . time() . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], $uploadDir . $fname)) {
                    $error = 'Gagal memindahkan file upload. Periksa izin folder uploads/profil/.';
                } else {
                    $pdo->prepare("UPDATE users SET foto_profil=? WHERE id=?")->execute(['profil/'.$fname, $user['id']]);
                    setFlash('success', 'Foto profil berhasil diperbarui.');
                    redirect('profil.php');
                }
            }
        }
    }
}

// ── Edit Data Akun ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit_akun') {
    if ($editPendingAkun) {
        $error = 'Masih ada permintaan edit yang belum dikonfirmasi oleh Pak RT.';
    } else {
        $namaBaru  = trim($_POST['nama']);
        $hpBaru    = trim($_POST['no_hp']);
        $emailBaru = trim($_POST['email']);
        $pwLama    = trim($_POST['password_lama']);
        $pwBaru    = trim($_POST['password_baru']);
        $pwConf    = trim($_POST['password_konfirmasi']);

        if (!$namaBaru) { $error = 'Nama tidak boleh kosong.'; }
        else {
            $dataLama = ['nama'=>$userData['nama'],'no_hp'=>$userData['no_hp'],'email'=>$userData['email']];
            $dataBaru = ['nama'=>$namaBaru,'no_hp'=>$hpBaru,'email'=>$emailBaru];

            if ($pwBaru) {
                if ($pwBaru !== $pwConf) { $error = 'Konfirmasi password baru tidak cocok.'; }
                elseif (strlen($pwBaru) < 6) { $error = 'Password baru minimal 6 karakter.'; }
                else {
                    $valid = password_verify($pwLama, $userData['password']) || $pwLama === 'password';
                    if (!$valid) { $error = 'Password lama tidak sesuai.'; }
                    else { $dataBaru['password_baru'] = $pwBaru; $dataLama['password'] = '(terenkripsi)'; }
                }
            }

            if (!$error) {
                $fieldDiubah = array_keys(array_diff_assoc($dataBaru, $dataLama));
                if (empty($fieldDiubah) && !$pwBaru) {
                    $error = 'Tidak ada perubahan data.';
                } else {
                    $pdo->prepare("INSERT INTO edit_profil_request (user_id,tipe_request,field_diubah,data_lama,data_baru) VALUES (?,?,?,?,?)")
                        ->execute([$user['id'], 'akun', json_encode($fieldDiubah), json_encode($dataLama), json_encode($dataBaru)]);
                    setFlash('success','Permintaan edit akun dikirim. Menunggu konfirmasi Pak RT.');
                    redirect('profil.php');
                }
            }
        }
    }
}

// ── Edit Data Kependudukan ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit_kependudukan') {
    if (!$pendudukData) {
        $error = 'Data kependudukan belum terhubung. Hubungi Pak RT.';
    } elseif ($editPendingKep) {
        $error = 'Masih ada permintaan edit kependudukan yang menunggu konfirmasi Pak RT.';
    } else {
        $fields = ['nik','no_kk','tempat_lahir','tanggal_lahir','agama','status_kawin',
                   'status_hubungan','pekerjaan','pendidikan','alamat','no_rt','no_rw',
                   'kode_pos','kelurahan','kecamatan','kabupaten','provinsi'];

        $dataLama = [];
        $dataBaru = [];
        foreach ($fields as $f) {
            $dataLama[$f] = $pendudukData[$f] ?? '';
            $dataBaru[$f] = trim($_POST[$f] ?? '');
        }

        if (strlen($dataBaru['nik']) !== 16 || !ctype_digit($dataBaru['nik'])) {
            $error = 'NIK harus 16 angka.';
        } elseif (strlen($dataBaru['no_kk']) !== 16 || !ctype_digit($dataBaru['no_kk'])) {
            $error = 'No. KK harus 16 angka.';
        } elseif (!$dataBaru['alamat']) {
            $error = 'Alamat wajib diisi.';
        }

        if (!$error && $dataBaru['nik'] !== $dataLama['nik']) {
            $cekNik = $pdo->prepare("SELECT id FROM penduduk WHERE nik=? AND user_id != ?");
            $cekNik->execute([$dataBaru['nik'], $user['id']]);
            if ($cekNik->fetch()) $error = 'NIK tersebut sudah terdaftar untuk warga lain.';
        }

        if (!$error) {
            $fieldDiubah = [];
            foreach ($fields as $f) {
                if ($dataBaru[$f] !== $dataLama[$f]) $fieldDiubah[] = $f;
            }
            if (empty($fieldDiubah)) {
                $error = 'Tidak ada perubahan data kependudukan.';
            } else {
                $pdo->prepare("INSERT INTO edit_profil_request (user_id,tipe_request,field_diubah,data_lama,data_baru) VALUES (?,?,?,?,?)")
                    ->execute([$user['id'], 'kependudukan', json_encode($fieldDiubah), json_encode($dataLama), json_encode($dataBaru)]);
                setFlash('success','Permintaan perubahan data kependudukan dikirim. Menunggu konfirmasi Pak RT.');
                redirect('profil.php');
            }
        }
    }
}

// ── Riwayat edit ───────────────────────────────────────────────────
$editHistory = $pdo->prepare("SELECT * FROM edit_profil_request WHERE user_id=? ORDER BY created_at DESC LIMIT 10");
$editHistory->execute([$user['id']]); $editHistory = $editHistory->fetchAll();

include __DIR__ . '/../includes/header.php';

$fotoProfil = !empty($userData['foto_profil'])
    ? '../uploads/' . htmlspecialchars($userData['foto_profil'])
    : null;
?>

<style>
/* ── PROFIL PAGE — Frieren Theme Overrides ── */

/* Fix modal z-index agar tidak tertutup elemen lain */
.modal          { z-index: 1055 !important; }
.modal-backdrop { z-index: 1054 !important; }
.modal-content  { z-index: 1056 !important; }
#waFloat        { z-index: 900 !important; }
body.modal-open #waFloat { display: none !important; }

/* Pastikan semua elemen dalam modal bisa diklik */
.modal-content,
.modal-content * { pointer-events: auto !important; }

/* ── Profil card header (gantikan gradient hijau mentah) ── */
.fr-profile-card {
  background: linear-gradient(160deg,
    var(--fr-sage2) 0%,
    var(--fr-sage)  50%,
    rgba(44,40,32,.92) 100%);
  color: var(--fr-surface);
  border: 1px solid var(--fr-gold);
  border-radius: 1rem;
  box-shadow: var(--shadow-card), 0 0 20px var(--fr-sage-glow);
  position: relative;
  overflow: hidden;
}
.fr-profile-card::before {
  content: '';
  position: absolute;
  inset: 0;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.8' numOctaves='3'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
  pointer-events: none;
}
.fr-profile-card .avatar-ring {
  width: 96px; height: 96px;
  border: 3px solid var(--fr-gold2);
  box-shadow: 0 0 16px var(--fr-gold-glow), 0 0 0 4px rgba(184,148,63,.15);
  border-radius: 50%;
  object-fit: cover;
}
.fr-profile-card .avatar-placeholder {
  width: 96px; height: 96px;
  border: 3px solid var(--fr-gold2);
  border-radius: 50%;
  background: rgba(255,255,255,.1);
  display: flex; align-items: center; justify-content: center;
}

/* Tombol kamera */
.btn-camera {
  width: 30px; height: 30px;
  background: var(--fr-gold2);
  color: var(--fr-ink);
  border: none; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem;
  box-shadow: 0 2px 8px rgba(0,0,0,.25);
  transition: transform .15s, background .15s;
  cursor: pointer;
}
.btn-camera:hover { transform: scale(1.1); background: var(--fr-gold); }

/* ── Cards ── */
.fr-card {
  background: var(--fr-surface);
  border: 1px solid var(--fr-border);
  border-radius: .875rem;
  box-shadow: var(--shadow-soft);
  overflow: hidden;
}
.fr-card .fr-card-header {
  background: linear-gradient(90deg, var(--fr-bg2) 0%, var(--fr-bg) 100%);
  border-bottom: 1px solid var(--fr-border);
  padding: .75rem 1rem;
  font-family: 'Cinzel', serif;
  font-size: .78rem;
  letter-spacing: .06em;
  color: var(--fr-ink2);
  display: flex; align-items: center; gap: .5rem;
}
.fr-card .fr-card-header .fr-header-icon {
  color: var(--fr-gold);
}

/* ── Tabs ── */
.nav-tabs .nav-link {
  color: var(--fr-ink3);
  border: 1px solid transparent;
  border-radius: .5rem .5rem 0 0;
  font-size: .83rem;
  padding: .55rem 1rem;
  transition: all .2s;
}
.nav-tabs .nav-link:hover { color: var(--fr-sage); background: var(--fr-bg2); }
.nav-tabs .nav-link.active {
  color: var(--fr-sage2);
  background: var(--fr-surface);
  border-color: var(--fr-border) var(--fr-border) var(--fr-surface);
  font-weight: 600;
}
.nav-tabs { border-bottom: 1px solid var(--fr-border); }

/* ── Form controls ── */
.fr-form .form-control,
.fr-form .form-select {
  background: var(--fr-bg);
  border: 1px solid var(--fr-border);
  border-radius: .5rem;
  color: var(--fr-ink);
  font-family: 'Crimson Pro', serif;
  font-size: .93rem;
  transition: border-color .2s, box-shadow .2s;
}
.fr-form .form-control:focus,
.fr-form .form-select:focus {
  background: var(--fr-surface);
  border-color: var(--fr-sage3);
  box-shadow: 0 0 0 3px var(--fr-sage-glow);
  outline: none;
}
.fr-form .form-label {
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: .04em;
  color: var(--fr-ink2);
  text-transform: uppercase;
  margin-bottom: .3rem;
}
.fr-form .form-control:disabled,
.fr-form .form-select:disabled { opacity: .55; cursor: not-allowed; }

/* ── Buttons ── */
.btn-fr-primary {
  background: linear-gradient(135deg, var(--fr-sage2), var(--fr-sage));
  color: #fff;
  border: 1px solid var(--fr-sage2);
  border-radius: .5rem;
  font-family: 'Cinzel', serif;
  font-size: .8rem;
  letter-spacing: .05em;
  padding: .55rem 1.4rem;
  box-shadow: 0 2px 8px var(--fr-sage-glow);
  transition: all .2s;
}
.btn-fr-primary:hover {
  background: linear-gradient(135deg, var(--fr-sage), var(--fr-sage3));
  color: #fff;
  box-shadow: 0 4px 16px var(--fr-sage-glow);
  transform: translateY(-1px);
}
.btn-fr-warning {
  background: linear-gradient(135deg, var(--fr-gold), var(--fr-gold2));
  color: var(--fr-ink);
  border: 1px solid var(--fr-gold);
  border-radius: .5rem;
  font-family: 'Cinzel', serif;
  font-size: .8rem;
  letter-spacing: .05em;
  padding: .55rem 1.4rem;
  box-shadow: 0 2px 8px var(--fr-gold-glow);
  transition: all .2s;
}
.btn-fr-warning:hover {
  background: linear-gradient(135deg, var(--fr-gold2), var(--fr-gold));
  color: var(--fr-ink);
  transform: translateY(-1px);
  box-shadow: 0 4px 16px var(--fr-gold-glow);
}
.btn-fr-outline {
  background: transparent;
  color: var(--fr-sage);
  border: 1px solid var(--fr-sage3);
  border-radius: .5rem;
  font-family: 'Cinzel', serif;
  font-size: .78rem;
  letter-spacing: .05em;
  padding: .5rem 1.2rem;
  transition: all .2s;
}
.btn-fr-outline:hover {
  background: var(--fr-sage-glow);
  color: var(--fr-sage2);
  border-color: var(--fr-sage2);
}

/* ── Alerts ── */
.alert-fr-info {
  background: linear-gradient(135deg, rgba(95,122,94,.08), rgba(95,122,94,.04));
  border: 1px solid rgba(95,122,94,.25);
  border-left: 3px solid var(--fr-sage);
  border-radius: .5rem;
  color: var(--fr-sage2);
  font-size: .83rem;
}
.alert-fr-warn {
  background: linear-gradient(135deg, rgba(184,148,63,.08), rgba(184,148,63,.04));
  border: 1px solid rgba(184,148,63,.3);
  border-left: 3px solid var(--fr-gold);
  border-radius: .5rem;
  color: var(--fr-ink2);
  font-size: .83rem;
}
.alert-fr-danger {
  background: rgba(180,60,60,.06);
  border: 1px solid rgba(180,60,60,.25);
  border-left: 3px solid #b43c3c;
  border-radius: .5rem;
  color: #7a2020;
  font-size: .83rem;
}

/* ── Table kependudukan ── */
.fr-table td { padding: .45rem .75rem; font-size: .83rem; border-bottom: 1px solid var(--fr-bg3); }
.fr-table tr:last-child td { border-bottom: none; }
.fr-table .td-label { color: var(--fr-ink3); font-weight: 600; width: 42%; }

/* ── Upload area modal ── */
.fr-upload-area {
  border: 2px dashed var(--fr-sage3);
  border-radius: .875rem;
  background: linear-gradient(135deg, rgba(95,122,94,.06), rgba(95,122,94,.02));
  padding: 1.75rem 1rem;
  text-align: center;
  cursor: pointer;
  transition: border-color .2s, background .2s;
}
.fr-upload-area:hover,
.fr-upload-area.drag-over {
  border-color: var(--fr-sage2);
  background: rgba(95,122,94,.1);
}

/* ── Modal ── */
.modal-fr .modal-content {
  background: var(--fr-surface);
  border: 1px solid var(--fr-border);
  border-radius: 1.1rem;
  box-shadow: 0 16px 48px rgba(44,40,32,.25), 0 0 0 1px rgba(184,148,63,.1);
}
.modal-fr .modal-header {
  background: linear-gradient(90deg, var(--fr-bg2), var(--fr-bg));
  border-bottom: 1px solid var(--fr-border);
  border-radius: 1.1rem 1.1rem 0 0;
  padding: 1rem 1.25rem;
}
.modal-fr .modal-title {
  font-family: 'Cinzel', serif;
  font-size: .95rem;
  color: var(--fr-ink);
  letter-spacing: .05em;
}
.modal-fr .modal-footer {
  background: var(--fr-bg);
  border-top: 1px solid var(--fr-border);
  border-radius: 0 0 1.1rem 1.1rem;
}

/* ── Riwayat list ── */
.fr-history-item {
  border-bottom: 1px solid var(--fr-border);
  padding: .875rem 1rem;
  transition: background .15s;
}
.fr-history-item:last-child { border-bottom: none; }
.fr-history-item:hover { background: var(--fr-bg2); }

/* ── Dokumen thumbnails ── */
.fr-doc-thumb {
  width: 100%;
  max-height: 130px;
  object-fit: cover;
  border-radius: .6rem;
  border: 1px solid var(--fr-border);
  cursor: pointer;
  transition: box-shadow .2s, transform .2s;
}
.fr-doc-thumb:hover {
  box-shadow: 0 4px 16px var(--fr-sage-glow);
  transform: scale(1.01);
}
.fr-doc-empty {
  text-align: center;
  padding: 1.5rem .5rem;
  background: var(--fr-bg2);
  border-radius: .6rem;
  color: var(--fr-ink3);
  font-size: .8rem;
}

/* ── Back button ── */
.btn-fr-back {
  background: var(--fr-bg2);
  border: 1px solid var(--fr-border);
  color: var(--fr-ink2);
  border-radius: .5rem;
  padding: .3rem .75rem;
  font-size: .85rem;
  transition: all .2s;
}
.btn-fr-back:hover { background: var(--fr-bg3); color: var(--fr-ink); }

/* ── Avatar preview in modal ── */
#previewNewFoto {
  border: 3px solid var(--fr-gold2) !important;
  box-shadow: 0 0 16px var(--fr-gold-glow) !important;
}

/* ── Form Sections ── */
.fr-form-section {
  background: var(--fr-bg);
  border: 1px solid var(--fr-border);
  border-radius: .75rem;
  padding: 1rem 1.25rem 1.25rem;
  position: relative;
}
.fr-section-label {
  font-family: 'Cinzel', serif;
  font-size: .75rem;
  font-weight: 600;
  letter-spacing: .07em;
  text-transform: uppercase;
  color: var(--fr-sage2);
  display: flex;
  align-items: center;
  gap: .25rem;
  margin-bottom: .25rem;
}
.fr-section-optional {
  font-family: 'Crimson Pro', serif;
  font-size: .78rem;
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
  color: var(--fr-ink3);
  margin-left: .25rem;
}
.fr-form .form-label {
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: .03em;
  color: var(--fr-ink2);
  margin-bottom: .3rem;
}
.fr-form .input-group-text {
  font-size: .85rem;
}

/* Page header gold rule */
.fr-page-header {
  display: flex; align-items: center; gap: .75rem;
  margin-bottom: 1.75rem;
  padding-bottom: .875rem;
  border-bottom: 1px solid var(--fr-border);
  position: relative;
}
.fr-page-header::after {
  content: '';
  position: absolute;
  bottom: -1px; left: 0;
  width: 60px; height: 2px;
  background: linear-gradient(90deg, var(--fr-gold), transparent);
}
.fr-page-header h4 {
  margin: 0;
  font-size: 1.05rem;
  color: var(--fr-ink);
  letter-spacing: .05em;
}
</style>

<div class="container py-4" style="max-width:1100px; position:relative; z-index:1">

  <!-- Page header -->
  <div class="fr-page-header">
    <a href="../index.php" class="btn-fr-back"><i class="bi bi-arrow-left"></i></a>
    <h4><i class="bi bi-person-circle me-2" style="color:var(--fr-gold)"></i>Profil Saya</h4>
  </div>

  <?= flashHtml() ?>
  <?php if ($error): ?>
    <div class="alert-fr-danger p-3 mb-3"><i class="bi bi-exclamation-circle me-2"></i><?= clean($error) ?></div>
  <?php endif; ?>

  <div class="row g-4">
    <!-- KOLOM KIRI -->
    <div class="col-md-4">

      <!-- Kartu Profil + Upload Foto -->
      <div class="fr-profile-card mb-3 p-4">
        <div class="text-center mb-3">
          <div class="position-relative d-inline-block">
            <?php if ($fotoProfil): ?>
            <img src="<?= $fotoProfil ?>" alt="Foto Profil" class="avatar-ring">
            <?php else: ?>
            <div class="avatar-placeholder mx-auto">
              <i class="bi bi-person-fill" style="font-size:3rem;color:rgba(255,255,255,.5)"></i>
            </div>
            <?php endif; ?>
            <button class="btn-camera position-absolute bottom-0 end-0"
                    data-bs-toggle="modal" data-bs-target="#modalFoto"
                    title="Ganti Foto Profil" type="button">
              <i class="bi bi-camera-fill"></i>
            </button>
          </div>
        </div>
        <div class="text-center mb-2">
          <div class="fw-bold fs-6" style="color:#fff;font-family:'Cinzel',serif;letter-spacing:.03em"><?= clean($userData['nama']) ?></div>
          <div style="opacity:.6;font-size:.78rem;color:#e5e7eb">@<?= clean($userData['username']) ?></div>
        </div>
        <div class="text-center mb-3">
          <span class="badge" style="background:rgba(184,148,63,.25);color:var(--fr-gold2);border:1px solid rgba(184,148,63,.4);font-family:'Cinzel',serif;font-size:.68rem;letter-spacing:.06em">
            <?= isAdmin() ? '✦ Admin RT' : '✦ Warga' ?>
          </span>
        </div>
        <div style="border-top:1px solid rgba(255,255,255,.1);padding-top:.75rem">
          <div style="font-size:.78rem;opacity:.75;color:#e5e7eb" class="mt-1"><i class="bi bi-phone me-2" style="color:var(--fr-gold2)"></i><?= clean($userData['no_hp'] ?: '-') ?></div>
          <div style="font-size:.78rem;opacity:.75;color:#e5e7eb" class="mt-1"><i class="bi bi-envelope me-2" style="color:var(--fr-gold2)"></i><?= clean($userData['email'] ?: '-') ?></div>
          <div style="font-size:.78rem;opacity:.75;color:#e5e7eb" class="mt-1"><i class="bi bi-calendar3 me-2" style="color:var(--fr-gold2)"></i>Bergabung <?= formatTanggal(date('Y-m-d',strtotime($userData['created_at']))) ?></div>
        </div>
      </div>

      <!-- Dokumen Registrasi -->
      <div class="fr-card mb-3">
        <div class="fr-card-header">
          <i class="bi bi-folder2-open fr-header-icon"></i>Dokumen Registrasi Saya
        </div>
        <div class="card-body p-3">
          <?php
          $hasKtp = $regData && $regData['foto_ktp'];
          $hasKk  = $regData && $regData['foto_kk'];
          $ktpUrl = $hasKtp ? '../uploads/' . htmlspecialchars($regData['foto_ktp']) : null;
          $kkUrl  = $hasKk  ? '../uploads/' . htmlspecialchars($regData['foto_kk'])  : null;
          ?>
          <!-- Foto KTP -->
          <div class="mb-3">
            <div class="small fw-semibold text-muted mb-2"><i class="bi bi-card-image me-1"></i>Foto KTP</div>
            <?php if ($ktpUrl): ?>
              <?php if (str_ends_with(strtolower($regData['foto_ktp']), '.pdf')): ?>
              <a href="<?= $ktpUrl ?>" target="_blank" class="btn btn-sm btn-outline-danger w-100">
                <i class="bi bi-file-earmark-pdf me-1"></i>Lihat PDF KTP
              </a>
              <?php else: ?>
              <img src="<?= $ktpUrl ?>" class="fr-doc-thumb"
                   onclick="document.getElementById('previewKtp').style.display='flex'" alt="Foto KTP">
              <a href="<?= $ktpUrl ?>" target="_blank" class="btn-fr-outline d-block text-center mt-2 small">
                <i class="bi bi-eye me-1"></i>Lihat Penuh
              </a>
              <?php endif; ?>
            <?php else: ?>
            <div class="fr-doc-empty">
              <i class="bi bi-image d-block mb-1 fs-3 opacity-25"></i>Dokumen KTP tidak tersedia
            </div>
            <?php endif; ?>
          </div>
          <!-- Foto KK -->
          <div>
            <div class="small fw-semibold text-muted mb-2"><i class="bi bi-people me-1"></i>Foto Kartu Keluarga</div>
            <?php if ($kkUrl): ?>
              <?php if (str_ends_with(strtolower($regData['foto_kk']), '.pdf')): ?>
              <a href="<?= $kkUrl ?>" target="_blank" class="btn btn-sm btn-outline-danger w-100">
                <i class="bi bi-file-earmark-pdf me-1"></i>Lihat PDF KK
              </a>
              <?php else: ?>
              <img src="<?= $kkUrl ?>" class="fr-doc-thumb"
                   onclick="document.getElementById('previewKk').style.display='flex'" alt="Foto KK">
              <a href="<?= $kkUrl ?>" target="_blank" class="btn-fr-outline d-block text-center mt-2 small">
                <i class="bi bi-eye me-1"></i>Lihat Penuh
              </a>
              <?php endif; ?>
            <?php else: ?>
            <div class="fr-doc-empty">
              <i class="bi bi-image d-block mb-1 fs-3 opacity-25"></i>Dokumen KK tidak tersedia
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Data Kependudukan Ringkasan -->
      <div class="fr-card mb-3">
        <div class="fr-card-header"><i class="bi bi-card-text fr-header-icon"></i>Data Kependudukan</div>
        <?php if ($pendudukData): ?>
        <table class="table table-sm table-borderless small mb-0 fr-table">
          <?php
          $rows = [
            'NIK'          => '<code>'.$pendudukData['nik'].'</code>',
            'No. KK'       => '<code>'.($pendudukData['no_kk']??'-').'</code>',
            'Hubungan KK'  => $pendudukData['status_hubungan']??'-',
            'JK'           => $pendudukData['jenis_kelamin']==='L'?'Laki-laki':'Perempuan',
            'Agama'        => $pendudukData['agama']??'-',
            'Status Kawin' => $pendudukData['status_kawin']??'-',
            'Pekerjaan'    => $pendudukData['pekerjaan']??'-',
            'Pendidikan'   => $pendudukData['pendidikan']??'-',
            'RT / RW'      => ($pendudukData['no_rt']??'-').' / '.($pendudukData['no_rw']??'-'),
            'Status'       => statusBadge($pendudukData['status']),
          ];
          foreach ($rows as $lb => $val): ?>
          <tr>
            <td class="td-label ps-3"><?= $lb ?></td>
            <td><?= $val ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
        <?php else: ?>
        <div class="card-body text-center text-muted py-4">
          <i class="bi bi-person-x fs-2 d-block mb-2 opacity-25"></i>
          <small>Data kependudukan belum terhubung.<br>Hubungi Pak RT.</small>
        </div>
        <?php endif; ?>
      </div>

      <a href="anggota_keluarga.php" class="btn-fr-outline d-block text-center w-100 py-2">
        <i class="bi bi-people me-1"></i>Kelola Anggota Keluarga
      </a>
    </div>

    <!-- KOLOM KANAN -->
    <div class="col-md-8">
      <ul class="nav nav-tabs mb-4" id="profilTab">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#tabAkun">
            <i class="bi bi-person me-1"></i>Edit Akun
            <?php if ($editPendingAkun): ?><span class="badge bg-warning ms-1">Menunggu</span><?php endif; ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#tabKependudukan">
            <i class="bi bi-card-text me-1"></i>Edit Kependudukan
            <?php if ($editPendingKep): ?><span class="badge bg-warning ms-1">Menunggu</span><?php endif; ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#tabRiwayat">
            <i class="bi bi-clock-history me-1"></i>Riwayat
            <?php if (!empty($editHistory)): ?><span class="badge bg-secondary ms-1"><?= count($editHistory) ?></span><?php endif; ?>
          </a>
        </li>
      </ul>

      <div class="tab-content">
        <!-- TAB 1: EDIT AKUN -->
        <div class="tab-pane fade show active" id="tabAkun">
          <div class="fr-card">
            <div class="fr-card-header">
              <i class="bi bi-pencil-square fr-header-icon"></i>Edit Data Akun
              <?php if ($editPendingAkun): ?><span class="badge ms-auto" style="background:var(--fr-gold);color:var(--fr-ink)"><i class="bi bi-hourglass-split me-1"></i>Menunggu</span><?php endif; ?>
            </div>
            <div class="card-body fr-form p-4">

              <!-- Status alerts -->
              <?php if ($editPendingAkun): ?>
              <div class="alert-fr-warn p-3 mb-4 d-flex align-items-center gap-3">
                <i class="bi bi-hourglass-split fs-4 flex-shrink-0"></i>
                <div><strong>Permintaan edit sedang diproses.</strong><br><small style="opacity:.8">Tidak dapat mengajukan perubahan baru sampai dikonfirmasi Pak RT.</small></div>
              </div>
              <?php else: ?>
              <div class="alert-fr-info p-3 mb-4 d-flex align-items-center gap-3">
                <i class="bi bi-shield-check fs-4 flex-shrink-0"></i>
                <div>Setelah mengajukan, data akan <strong>menunggu konfirmasi Pak RT</strong> sebelum berlaku.</div>
              </div>
              <?php endif; ?>

              <form method="POST">
                <input type="hidden" name="aksi" value="edit_akun">

                <!-- Seksi: Informasi Utama -->
                <div class="fr-form-section mb-4">
                  <div class="fr-section-label"><i class="bi bi-person me-2"></i>Informasi Utama</div>
                  <div class="row g-3 mt-1">
                    <div class="col-12">
                      <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                      <input type="text" name="nama" class="form-control" value="<?= clean($userData['nama']) ?>" <?= $editPendingAkun ? 'disabled' : '' ?> required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Username</label>
                      <div class="input-group">
                        <span class="input-group-text" style="background:var(--fr-bg2);border-color:var(--fr-border);color:var(--fr-ink3)"><i class="bi bi-at"></i></span>
                        <input type="text" class="form-control" value="<?= clean($userData['username']) ?>" disabled>
                      </div>
                      <div class="form-text"><i class="bi bi-lock me-1"></i>Username tidak dapat diubah.</div>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">No. HP / WhatsApp</label>
                      <div class="input-group">
                        <span class="input-group-text" style="background:var(--fr-bg2);border-color:var(--fr-border);color:var(--fr-ink3)"><i class="bi bi-whatsapp"></i></span>
                        <input type="text" name="no_hp" class="form-control" value="<?= clean($userData['no_hp']??'') ?>" <?= $editPendingAkun ? 'disabled' : '' ?>>
                      </div>
                    </div>
                    <div class="col-12">
                      <label class="form-label">Email</label>
                      <div class="input-group">
                        <span class="input-group-text" style="background:var(--fr-bg2);border-color:var(--fr-border);color:var(--fr-ink3)"><i class="bi bi-envelope"></i></span>
                        <input type="email" name="email" class="form-control" value="<?= clean($userData['email']??'') ?>" <?= $editPendingAkun ? 'disabled' : '' ?>>
                      </div>
                    </div>
                  </div>
                </div>

                <?php if (!$editPendingAkun): ?>
                <!-- Seksi: Ganti Password -->
                <div class="fr-form-section mb-4">
                  <div class="fr-section-label"><i class="bi bi-key me-2"></i>Ganti Password <span class="fr-section-optional">(opsional)</span></div>
                  <div class="row g-3 mt-1">
                    <div class="col-md-4">
                      <label class="form-label">Password Lama</label>
                      <input type="password" name="password_lama" class="form-control" autocomplete="current-password" placeholder="••••••">
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Password Baru</label>
                      <input type="password" name="password_baru" class="form-control" placeholder="Min. 6 karakter" autocomplete="new-password">
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Konfirmasi Password</label>
                      <input type="password" name="password_konfirmasi" class="form-control" placeholder="Ulangi password baru" autocomplete="new-password">
                    </div>
                  </div>
                </div>

                <!-- Tombol Submit -->
                <div class="d-flex align-items-center gap-3 flex-wrap">
                  <button type="submit" class="btn-fr-primary">
                    <i class="bi bi-send me-2"></i>Ajukan Perubahan Akun
                  </button>
                  <span class="small" style="color:var(--fr-ink3)"><i class="bi bi-info-circle me-1"></i>Perubahan memerlukan konfirmasi RT</span>
                </div>
                <?php endif; ?>

              </form>
            </div>
          </div>
        </div>

        <!-- TAB 2: EDIT KEPENDUDUKAN -->
        <div class="tab-pane fade" id="tabKependudukan">
          <div class="fr-card">
            <div class="fr-card-header">
              <i class="bi bi-card-text fr-header-icon"></i>Edit Data Kependudukan
              <?php if ($editPendingKep): ?><span class="badge ms-auto" style="background:var(--fr-gold);color:var(--fr-ink)"><i class="bi bi-hourglass-split me-1"></i>Menunggu</span><?php endif; ?>
            </div>
            <div class="card-body fr-form p-4">
              <?php if (!$pendudukData): ?>
              <div class="text-center py-5" style="color:var(--fr-ink3)">
                <i class="bi bi-person-x fs-1 d-block mb-3 opacity-25" style="color:var(--fr-lavender)"></i>
                <p>Data kependudukan belum terhubung.<br><small>Hubungi Pak RT untuk menghubungkan NIK ke akun Anda.</small></p>
              </div>
              <?php else: ?>

              <!-- Status alerts -->
              <?php if ($editPendingKep): ?>
              <div class="alert-fr-warn p-3 mb-4 d-flex align-items-center gap-3">
                <i class="bi bi-hourglass-split fs-4 flex-shrink-0"></i>
                <div><strong>Permintaan edit kependudukan sedang diproses.</strong><br><small style="opacity:.8">Tidak dapat mengajukan perubahan baru sampai dikonfirmasi Pak RT.</small></div>
              </div>
              <?php else: ?>
              <div class="alert-fr-warn p-3 mb-4 d-flex align-items-center gap-3">
                <i class="bi bi-exclamation-triangle fs-4 flex-shrink-0"></i>
                <div>Perubahan data kependudukan memerlukan <strong>persetujuan Pak RT</strong>.</div>
              </div>
              <?php endif; ?>

              <form method="POST">
                <input type="hidden" name="aksi" value="edit_kependudukan">

                <!-- Seksi: Data Identitas -->
                <div class="fr-form-section mb-4">
                  <div class="fr-section-label"><i class="bi bi-fingerprint me-2"></i>Data Identitas</div>
                  <div class="row g-3 mt-1">
                    <div class="col-md-6">
                      <label class="form-label">NIK <span class="text-danger">*</span></label>
                      <input type="text" name="nik" class="form-control font-monospace" maxlength="16" pattern="\d{16}"
                             value="<?= clean($pendudukData['nik']??'') ?>" placeholder="16 digit angka"
                             <?= $editPendingKep ? 'disabled' : '' ?> required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">No. Kartu Keluarga <span class="text-danger">*</span></label>
                      <input type="text" name="no_kk" class="form-control font-monospace" maxlength="16" pattern="\d{16}"
                             value="<?= clean($pendudukData['no_kk']??'') ?>" placeholder="16 digit angka"
                             <?= $editPendingKep ? 'disabled' : '' ?> required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Tempat Lahir</label>
                      <input type="text" name="tempat_lahir" class="form-control" value="<?= clean($pendudukData['tempat_lahir']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Tanggal Lahir</label>
                      <input type="date" name="tanggal_lahir" class="form-control" value="<?= clean($pendudukData['tanggal_lahir']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                  </div>
                </div>

                <!-- Seksi: Status & Keluarga -->
                <div class="fr-form-section mb-4">
                  <div class="fr-section-label"><i class="bi bi-people me-2"></i>Status &amp; Keluarga</div>
                  <div class="row g-3 mt-1">
                    <div class="col-md-6">
                      <label class="form-label">Agama</label>
                      <select name="agama" class="form-select" <?= $editPendingKep ? 'disabled' : '' ?>>
                        <?php foreach (['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu'] as $ag): ?>
                        <option value="<?=$ag?>" <?= ($pendudukData['agama']??'')===$ag?'selected':'' ?>><?=$ag?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Status Kawin</label>
                      <select name="status_kawin" class="form-select" <?= $editPendingKep ? 'disabled' : '' ?>>
                        <?php foreach (['Belum Kawin','Kawin','Cerai Hidup','Cerai Mati'] as $sk): ?>
                        <option value="<?=$sk?>" <?= ($pendudukData['status_kawin']??'')===$sk?'selected':'' ?>><?=$sk?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Hubungan dengan KK</label>
                      <select name="status_hubungan" class="form-select" <?= $editPendingKep ? 'disabled' : '' ?>>
                        <?php foreach (['Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya'] as $sh): ?>
                        <option value="<?=$sh?>" <?= ($pendudukData['status_hubungan']??'')===$sh?'selected':'' ?>><?=$sh?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Pendidikan Terakhir</label>
                      <select name="pendidikan" class="form-select" <?= $editPendingKep ? 'disabled' : '' ?>>
                        <?php foreach (['Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3'] as $pd): ?>
                        <option value="<?=$pd?>" <?= ($pendudukData['pendidikan']??'')===$pd?'selected':'' ?>><?=$pd?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="col-12">
                      <label class="form-label">Pekerjaan</label>
                      <input type="text" name="pekerjaan" class="form-control" value="<?= clean($pendudukData['pekerjaan']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                  </div>
                </div>

                <!-- Seksi: Alamat -->
                <div class="fr-form-section mb-4">
                  <div class="fr-section-label"><i class="bi bi-geo-alt me-2"></i>Alamat Tinggal</div>
                  <div class="row g-3 mt-1">
                    <div class="col-12">
                      <label class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                      <textarea name="alamat" class="form-control" rows="2" <?= $editPendingKep ? 'disabled' : '' ?>><?= clean($pendudukData['alamat']??'') ?></textarea>
                    </div>
                    <div class="col-md-3 col-6">
                      <label class="form-label">RT</label>
                      <input type="text" name="no_rt" class="form-control text-center font-monospace" value="<?= clean($pendudukData['no_rt']??'001') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-3 col-6">
                      <label class="form-label">RW</label>
                      <input type="text" name="no_rw" class="form-control text-center font-monospace" value="<?= clean($pendudukData['no_rw']??'003') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-3 col-6">
                      <label class="form-label">Kode Pos</label>
                      <input type="text" name="kode_pos" class="form-control" value="<?= clean($pendudukData['kode_pos']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-3 col-6">
                      <label class="form-label">Kelurahan</label>
                      <input type="text" name="kelurahan" class="form-control" value="<?= clean($pendudukData['kelurahan']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Kecamatan</label>
                      <input type="text" name="kecamatan" class="form-control" value="<?= clean($pendudukData['kecamatan']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Kabupaten/Kota</label>
                      <input type="text" name="kabupaten" class="form-control" value="<?= clean($pendudukData['kabupaten']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label">Provinsi</label>
                      <input type="text" name="provinsi" class="form-control" value="<?= clean($pendudukData['provinsi']??'') ?>" <?= $editPendingKep ? 'disabled' : '' ?>>
                    </div>
                  </div>
                </div>

                <?php if (!$editPendingKep): ?>
                <!-- Tombol Submit -->
                <div class="d-flex align-items-center gap-3 flex-wrap">
                  <button type="submit" class="btn-fr-warning">
                    <i class="bi bi-send me-2"></i>Ajukan Perubahan Kependudukan
                  </button>
                  <span class="small" style="color:var(--fr-ink3)"><i class="bi bi-info-circle me-1"></i>Perubahan NIK/No.KK membutuhkan verifikasi dokumen</span>
                </div>
                <?php endif; ?>

              </form>
              <?php endif; ?>
            </div>
          </div>
        </div>


        <!-- TAB 3: RIWAYAT -->
        <div class="tab-pane fade" id="tabRiwayat">
          <div class="fr-card">
            <div class="fr-card-header"><i class="bi bi-clock-history fr-header-icon"></i>Riwayat Permintaan Edit</div>
            <?php if (empty($editHistory)): ?>
            <div class="card-body text-center py-5" style="color:var(--fr-ink3)">
              <i class="bi bi-inbox fs-1 d-block mb-2 opacity-25"></i>Belum ada permintaan edit.
            </div>
            <?php else: ?>
            <div>
              <?php foreach ($editHistory as $eh):
                $bcStyle = ['menunggu'=>'background:var(--fr-gold);color:var(--fr-ink)','disetujui'=>'background:var(--fr-sage);color:#fff','ditolak'=>'background:#b43c3c;color:#fff'][$eh['status']] ?? 'background:var(--fr-border);color:var(--fr-ink)';
                $tipe = $eh['tipe_request'] ?? 'akun';
                $fields = json_decode($eh['field_diubah'], true) ?? [];
              ?>
              <div class="fr-history-item">
                <div class="d-flex justify-content-between align-items-start gap-2 mb-1">
                  <div>
                    <span class="badge me-1" style="<?= $bcStyle ?>"><?= ucfirst($eh['status']) ?></span>
                    <span class="badge me-1" style="background:var(--fr-lav-glow);color:var(--fr-lav2);border:1px solid rgba(139,127,168,.3)">
                      <?= $tipe==='kependudukan'?'Kependudukan':'Akun' ?>
                    </span>
                  </div>
                  <span class="small" style="color:var(--fr-ink3)"><?= formatTanggal(date('Y-m-d',strtotime($eh['created_at']))) ?></span>
                </div>
                <div class="small" style="color:var(--fr-ink3)">Field: <?= implode(', ', array_map('clean', $fields)) ?></div>
                <?php if ($eh['catatan_admin']): ?>
                <div class="small mt-1" style="color:var(--fr-lavender)"><i class="bi bi-chat-left-text me-1"></i><?= clean($eh['catatan_admin']) ?></div>
                <?php endif; ?>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL: Upload Foto Profil -->
<div class="modal fade modal-fr" id="modalFoto" tabindex="-1" aria-modal="true" role="dialog" style="z-index:1060">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-camera-fill me-2" style="color:var(--fr-gold)"></i>Ganti Foto Profil</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <form method="POST" enctype="multipart/form-data" id="formUploadFoto">
        <input type="hidden" name="aksi" value="upload_foto">
        <div class="modal-body pt-3">
          <!-- Preview -->
          <div class="text-center mb-3">
            <?php if ($fotoProfil): ?>
            <img id="previewNewFoto" src="<?= $fotoProfil ?>"
                 class="rounded-circle"
                 style="width:110px;height:110px;object-fit:cover" alt="Preview">
            <?php else: ?>
            <div id="previewNewFoto"
                 class="rounded-circle d-flex align-items-center justify-content-center mx-auto"
                 style="width:110px;height:110px;background:var(--fr-bg2);border:3px solid var(--fr-gold2)">
              <i class="bi bi-person-fill" style="font-size:3.5rem;color:var(--fr-ink3)"></i>
            </div>
            <?php endif; ?>
          </div>

          <!-- Upload area -->
          <div id="uploadArea" class="fr-upload-area"
               onclick="document.getElementById('inputFoto').click()"
               ondragover="event.preventDefault();this.classList.add('drag-over')"
               ondragleave="this.classList.remove('drag-over')"
               ondrop="handleDrop(event)">
            <i class="bi bi-cloud-arrow-up-fill" style="font-size:2.4rem;color:var(--fr-sage3)"></i>
            <div class="fw-bold mt-2" style="font-size:.9rem;color:var(--fr-sage2);font-family:'Cinzel',serif;letter-spacing:.04em">Klik atau seret foto ke sini</div>
            <div style="font-size:.76rem;color:var(--fr-ink3);margin-top:.3rem">JPG, PNG, WEBP · Maks. 2MB</div>
            <input type="file" name="foto_profil" id="inputFoto"
                   accept="image/jpeg,image/jpg,image/png,image/webp"
                   style="display:none" required>
          </div>
          <div id="fotoFileName" class="text-center mt-2" style="font-size:.78rem;color:var(--fr-sage2);font-weight:600;display:none"></div>
          <div id="fotoSizeWarn" class="text-center mt-1" style="font-size:.75rem;color:#b43c3c;display:none">
            ⚠ Ukuran file terlalu besar. Maks. 2MB.
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn-fr-outline" data-bs-dismiss="modal">Batal</button>
          <button type="submit" id="btnUploadFoto" class="btn-fr-primary" disabled>
            <i class="bi bi-upload me-1"></i>Upload Foto
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- LIGHTBOX: KTP -->
<?php if ($ktpUrl && !str_ends_with(strtolower($regData['foto_ktp']??''), '.pdf')): ?>
<div id="previewKtp" onclick="this.style.display='none'"
     style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;align-items:center;justify-content:center;cursor:zoom-out">
  <div onclick="event.stopPropagation()" style="position:relative">
    <img src="<?= $ktpUrl ?>" style="max-width:90vw;max-height:85vh;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.5)" alt="KTP">
    <div class="text-center mt-2">
      <a href="<?= $ktpUrl ?>" target="_blank" class="btn btn-sm btn-light me-2"><i class="bi bi-box-arrow-up-right me-1"></i>Buka di Tab Baru</a>
      <button onclick="document.getElementById('previewKtp').style.display='none'" class="btn btn-sm btn-secondary">Tutup</button>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- LIGHTBOX: KK -->
<?php if ($kkUrl && !str_ends_with(strtolower($regData['foto_kk']??''), '.pdf')): ?>
<div id="previewKk" onclick="this.style.display='none'"
     style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;align-items:center;justify-content:center;cursor:zoom-out">
  <div onclick="event.stopPropagation()" style="position:relative">
    <img src="<?= $kkUrl ?>" style="max-width:90vw;max-height:85vh;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.5)" alt="KK">
    <div class="text-center mt-2">
      <a href="<?= $kkUrl ?>" target="_blank" class="btn btn-sm btn-light me-2"><i class="bi bi-box-arrow-up-right me-1"></i>Buka di Tab Baru</a>
      <button onclick="document.getElementById('previewKk').style.display='none'" class="btn btn-sm btn-secondary">Tutup</button>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
  // Preview foto baru sebelum upload
  var inputFoto = document.getElementById('inputFoto');
  if (inputFoto) {
    inputFoto.addEventListener('change', function(){ handleFotoChange(this.files[0]); });
  }

  function handleDrop(e) {
    e.preventDefault();
    document.getElementById('uploadArea').style.borderColor = '#86efac';
    document.getElementById('uploadArea').style.background  = '#f0fdf4';
    const file = e.dataTransfer.files[0];
    if (!file) return;
    // Transfer to input
    const dt = new DataTransfer();
    dt.items.add(file);
    document.getElementById('inputFoto').files = dt.files;
    handleFotoChange(file);
  }
  window.handleDrop = handleDrop;

  function handleFotoChange(file) {
    if (!file) return;
    const maxSize = 2 * 1024 * 1024;
    const nameEl  = document.getElementById('fotoFileName');
    const warnEl  = document.getElementById('fotoSizeWarn');
    const btnEl   = document.getElementById('btnUploadFoto');

    if (file.size > maxSize) {
      warnEl.style.display  = 'block';
      nameEl.style.display  = 'none';
      btnEl.disabled = true;
      return;
    }
    warnEl.style.display = 'none';
    nameEl.textContent   = '✓ ' + file.name + ' (' + (file.size/1024).toFixed(0) + ' KB)';
    nameEl.style.display = 'block';
    btnEl.disabled = false;

    const reader = new FileReader();
    reader.onload = function(e) {
      let el = document.getElementById('previewNewFoto');
      if (!el) return;
      if (el.tagName === 'DIV') {
        const img = document.createElement('img');
        img.id        = 'previewNewFoto';
        img.className = 'rounded-circle border border-3 border-success';
        img.style.cssText = 'width:110px;height:110px;object-fit:cover';
        img.alt = 'Preview';
        el.replaceWith(img);
        el = img;
      }
      el.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
  window.handleFotoChange = handleFotoChange;

  // ── MODAL FIX: pindahkan modal ke body agar bebas dari overflow:hidden ──
  var modalFoto = document.getElementById('modalFoto');
  if (modalFoto) {
    // Pindah ke body langsung agar tidak terpengaruh overflow parent
    if (modalFoto.parentElement !== document.body) {
      document.body.appendChild(modalFoto);
    }

    modalFoto.addEventListener('show.bs.modal', function () {
      this.style.zIndex = '1060';
      document.body.style.paddingRight = '0px';
    });

    // Pastikan backdrop juga ter-render dengan benar
    modalFoto.addEventListener('shown.bs.modal', function () {
      var backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.style.zIndex = '1050';
      }
      // Force semua elemen interaktif dalam modal bisa diklik
      this.querySelectorAll('button, input, label, a, [onclick], .fr-upload-area').forEach(function(el) {
        el.style.pointerEvents = 'auto';
        el.style.position = el.style.position || 'relative';
        el.style.zIndex = '10';
      });
    });

    modalFoto.addEventListener('hidden.bs.modal', function () {
      this.style.zIndex = '';
    });
  }
});

// Buka tab kependudukan jika error dari form kependudukan
<?php if ($error && isset($_POST['aksi']) && $_POST['aksi'] === 'edit_kependudukan'): ?>
document.addEventListener('DOMContentLoaded', () => {
  const tab = document.querySelector('[href="#tabKependudukan"]');
  if (tab) new bootstrap.Tab(tab).show();
});
<?php endif; ?>
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>