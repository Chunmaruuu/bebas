<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Lapor Pindah';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';
define('MAX_EDIT_PINDAH', 3);

$pendudukUser = null;
if (!isAdmin()) {
    $s = $pdo->prepare("SELECT * FROM penduduk WHERE user_id=? AND status='aktif'");
    $s->execute([$user['id']]); $pendudukUser = $s->fetch();
}
$allPenduduk = [];
if (isAdmin()) {
    $allPenduduk = $pdo->query("SELECT id,nama,nik FROM penduduk WHERE status='aktif' ORDER BY nama")->fetchAll();
}

// Proses TAMBAH
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'buat') {
    $pid    = isAdmin() ? intval($_POST['penduduk_id']) : ($pendudukUser['id'] ?? 0);
    $tgl    = $_POST['tanggal_pindah'];
    $alamat = trim($_POST['alamat_tujuan']);
    $kota   = trim($_POST['kota_tujuan']);
    $alasan = trim($_POST['alasan']);

    if (!$pid)    $error = 'Pilih penduduk yang akan pindah.';
    elseif (!$tgl)$error = 'Tanggal pindah wajib diisi.';
    elseif (!$alamat) $error = 'Alamat tujuan wajib diisi.';
    else {
        $pdo->prepare("INSERT INTO laporan_pindah (penduduk_id,tanggal_pindah,alamat_tujuan,kota_tujuan,alasan,dibuat_oleh) VALUES (?,?,?,?,?,?)")
            ->execute([$pid,$tgl,$alamat,$kota,$alasan,$user['id']]);
        setFlash('success','Laporan pindah berhasil dikirim. Menunggu persetujuan Pak RT.');
        redirect('lapor_pindah.php');
    }
}

// Proses EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit') {
    $lid    = intval($_POST['lap_id']);
    $tgl    = $_POST['tanggal_pindah'];
    $alamat = trim($_POST['alamat_tujuan']);
    $kota   = trim($_POST['kota_tujuan']);
    $alasan = trim($_POST['alasan']);

    $cek = $pdo->prepare("SELECT * FROM laporan_pindah WHERE id=? AND dibuat_oleh=?");
    $cek->execute([$lid,$user['id']]); $lap = $cek->fetch();

    if (!$lap)                                           $error = 'Laporan tidak ditemukan.';
    elseif ($lap['status'] === 'disetujui')              $error = 'Laporan yang sudah disetujui tidak dapat diedit.';
    elseif ($lap['edit_count'] >= MAX_EDIT_PINDAH)       $error = 'Batas edit telah mencapai maksimal ' . MAX_EDIT_PINDAH . ' kali.';
    elseif (!$alamat)                                    $error = 'Alamat tujuan wajib diisi.';
    else {
        $pdo->prepare("UPDATE laporan_pindah SET tanggal_pindah=?,alamat_tujuan=?,kota_tujuan=?,alasan=?,edit_count=edit_count+1,status='pending' WHERE id=?")
            ->execute([$tgl,$alamat,$kota,$alasan,$lid]);
        setFlash('success','Laporan berhasil diperbarui ('.($lap['edit_count']+1).'/'.MAX_EDIT_PINDAH.' edit).');
        redirect('lapor_pindah.php');
    }
}

$riwayat = [];
if ($pendudukUser) {
    $s = $pdo->prepare("SELECT * FROM laporan_pindah WHERE penduduk_id=? ORDER BY created_at DESC");
    $s->execute([$pendudukUser['id']]); $riwayat = $s->fetchAll();
}

$editLap = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $s   = $pdo->prepare("SELECT * FROM laporan_pindah WHERE id=? AND dibuat_oleh=?");
    $s->execute([$eid,$user['id']]); $editLap = $s->fetch();
    if ($editLap && ($editLap['status'] === 'disetujui' || $editLap['edit_count'] >= MAX_EDIT_PINDAH)) $editLap = null;
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4" style="max-width:860px">
  <div class="d-flex align-items-center gap-2 mb-4">
    <a href="../index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
      <h4 class="fw-bold mb-0">Lapor Pindah</h4>
      <small class="text-muted">Laporkan kepindahan dari wilayah RT 001/RW 003</small>
    </div>
  </div>
  <?= flashHtml() ?>

  <?php if (!$pendudukUser && !isAdmin()): ?>
  <div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle me-1"></i>
    Data penduduk kamu belum terdaftar. Hubungi Pak RT untuk pendataan.
  </div>
  <?php else: ?>

  <div class="card mb-4">
    <div class="card-header d-flex align-items-center gap-2">
      <i class="bi bi-<?= $editLap ? 'pencil' : 'file-earmark-plus' ?>"></i>
      <?= $editLap ? 'Edit Laporan Pindah' : 'Form Laporan Pindah' ?>
      <?php if ($editLap): ?>
      <span class="badge bg-warning ms-auto"><?= $editLap['edit_count'] ?>/<?= MAX_EDIT_PINDAH ?> edit</span>
      <?php endif; ?>
    </div>
    <div class="card-body">
      <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>
      <div class="alert alert-warning small mb-3">
        <i class="bi bi-info-circle me-1"></i>
        Laporan dapat diedit maksimal <strong><?= MAX_EDIT_PINDAH ?> kali</strong> selama masih berstatus <em>pending</em>.
      </div>
      <form method="POST">
        <input type="hidden" name="aksi" value="<?= $editLap ? 'edit' : 'buat' ?>">
        <?php if ($editLap): ?><input type="hidden" name="lap_id" value="<?= $editLap['id'] ?>"><?php endif; ?>
        <div class="row g-3">
          <?php if (isAdmin()): ?>
          <div class="col-12">
            <label class="form-label fw-semibold small">Pilih Penduduk <span class="text-danger">*</span></label>
            <select name="penduduk_id" class="form-select" required>
              <option value="">-- Pilih Penduduk --</option>
              <?php foreach ($allPenduduk as $p): ?>
              <option value="<?= $p['id'] ?>"><?= clean($p['nama']) ?> — NIK: <?= clean($p['nik']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php else: ?>
          <div class="col-12">
            <div class="alert alert-info small mb-0">
              <i class="bi bi-person-check me-1"></i>
              Laporan atas nama: <strong><?= clean($pendudukUser['nama']) ?></strong>
              &nbsp;|&nbsp; NIK: <code><?= clean($pendudukUser['nik']) ?></code>
            </div>
          </div>
          <?php endif; ?>
          <div class="col-md-4">
            <label class="form-label fw-semibold small">Tanggal Pindah <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_pindah" class="form-control"
                   value="<?= $editLap ? $editLap['tanggal_pindah'] : today() ?>" required>
          </div>
          <div class="col-md-8">
            <label class="form-label fw-semibold small">Kota / Kabupaten Tujuan</label>
            <input type="text" name="kota_tujuan" class="form-control" placeholder="cth: Bantul"
                   value="<?= $editLap ? clean($editLap['kota_tujuan']) : '' ?>">
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Alamat Tujuan Lengkap <span class="text-danger">*</span></label>
            <textarea name="alamat_tujuan" class="form-control" rows="2" required><?= $editLap ? clean($editLap['alamat_tujuan']) : '' ?></textarea>
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Alasan Pindah</label>
            <textarea name="alasan" class="form-control" rows="2" placeholder="Pindah kerja, menikah, dll."><?= $editLap ? clean($editLap['alasan']) : '' ?></textarea>
          </div>
          <div class="col-12 d-flex gap-2 flex-wrap">
            <button type="submit" class="btn btn-warning px-4">
              <i class="bi bi-send me-1"></i><?= $editLap ? 'Simpan Perubahan' : 'Kirim Laporan' ?>
            </button>
            <?php if ($editLap): ?><a href="lapor_pindah.php" class="btn btn-outline-secondary">Batal</a><?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php if (!empty($riwayat)): ?>
  <div class="card">
    <div class="card-header"><i class="bi bi-clock-history me-1"></i>Riwayat Laporan Pindah</div>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 small">
        <thead class="table-light">
          <tr><th>Tgl Pindah</th><th>Tujuan</th><th>Status</th><th>Catatan</th><th>Edit</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php foreach ($riwayat as $r): ?>
          <tr>
            <td><?= formatTanggal($r['tanggal_pindah']) ?></td>
            <td><?= clean($r['kota_tujuan'] ?: '-') ?></td>
            <td><?= statusBadge($r['status']) ?></td>
            <td class="text-muted"><?= clean($r['catatan_admin'] ?: '-') ?></td>
            <td>
              <span class="badge bg-<?= $r['edit_count'] >= MAX_EDIT_PINDAH ? 'secondary' : 'light text-dark' ?>">
                <?= $r['edit_count'] ?>/<?= MAX_EDIT_PINDAH ?>
              </span>
            </td>
            <td>
              <?php if ($r['status'] === 'pending' && $r['edit_count'] < MAX_EDIT_PINDAH): ?>
              <a href="?edit=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
              <?php else: ?><span class="text-muted">—</span><?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
