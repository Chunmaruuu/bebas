<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Jadwal Bertemu Pak RT';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';

// Proses buat jadwal baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'buat') {
    $keperluan = trim($_POST['keperluan']);
    $catatan   = trim($_POST['catatan']);
    $tanggal   = $_POST['tanggal_pilihan'];
    $jam       = $_POST['jam_pilihan'];

    if (!$keperluan)                   $error = 'Keperluan wajib diisi.';
    elseif (!$tanggal || $tanggal < date('Y-m-d')) $error = 'Pilih tanggal yang valid (hari ini atau setelahnya).';
    elseif (!$jam)                     $error = 'Jam pertemuan wajib dipilih.';
    else {
        $pdo->prepare("INSERT INTO jadwal_bertemu_rt (user_id,keperluan,catatan,tanggal_pilihan,jam_pilihan) VALUES (?,?,?,?,?)")
            ->execute([$user['id'],$keperluan,$catatan,$tanggal,$jam]);
        setFlash('success','Permintaan jadwal berhasil dikirim. Pak RT akan segera mengkonfirmasi.');
        redirect('jadwal_rt.php');
    }
}

// Proses batalkan jadwal (hanya yang masih menunggu)
if (isset($_GET['batal'])) {
    $bid = intval($_GET['batal']);
    $pdo->prepare("DELETE FROM jadwal_bertemu_rt WHERE id=? AND user_id=? AND status='menunggu'")
        ->execute([$bid,$user['id']]);
    setFlash('info','Permintaan jadwal dibatalkan.');
    redirect('jadwal_rt.php');
}

// Daftar jadwal user
$jadwalList = $pdo->prepare("SELECT * FROM jadwal_bertemu_rt WHERE user_id=? ORDER BY created_at DESC");
$jadwalList->execute([$user['id']]);
$jadwalList = $jadwalList->fetchAll();

include __DIR__ . '/../includes/header.php';

$badgeMap = [
    'menunggu'     => ['color'=>'warning',   'icon'=>'bi-hourglass-split', 'label'=>'Menunggu Konfirmasi'],
    'dikonfirmasi' => ['color'=>'success',   'icon'=>'bi-check-circle',    'label'=>'Dikonfirmasi'],
    'ditolak'      => ['color'=>'danger',    'icon'=>'bi-x-circle',        'label'=>'Ditolak'],
    'selesai'      => ['color'=>'secondary', 'icon'=>'bi-check-all',       'label'=>'Selesai'],
];
?>
<div class="container py-4" style="max-width:800px">
  <div class="d-flex align-items-center gap-2 mb-4">
    <a href="../index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
      <h4 class="fw-bold mb-0"><i class="bi bi-calendar2-check text-success me-1"></i>Jadwal Bertemu Pak RT</h4>
      <small class="text-muted">Ajukan pertemuan untuk keperluan administrasi</small>
    </div>
  </div>
  <?= flashHtml() ?>

  <div class="card mb-4">
    <div class="card-header"><i class="bi bi-calendar-plus me-1"></i>Ajukan Jadwal Pertemuan</div>
    <div class="card-body">
      <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>
      <div class="alert alert-info small mb-3">
        <i class="bi bi-info-circle me-1"></i>
        Pak RT biasanya tersedia pada <strong>hari Selasa–Kamis</strong>, pukul <strong>19.00–21.00 WIB</strong>.
        Setelah mengajukan, tunggu konfirmasi dari Pak RT.
      </div>
      <form method="POST">
        <input type="hidden" name="aksi" value="buat">
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label fw-semibold small">Keperluan <span class="text-danger">*</span></label>
            <select name="keperluan" class="form-select" required>
              <option value="">-- Pilih Keperluan --</option>
              <option value="Mengurus surat keterangan domisili">Surat Keterangan Domisili</option>
              <option value="Mengurus surat keterangan usaha">Surat Keterangan Usaha</option>
              <option value="Mengurus surat keterangan tidak mampu">Surat Keterangan Tidak Mampu</option>
              <option value="Konsultasi administrasi kependudukan">Konsultasi Administrasi</option>
              <option value="Pelaporan masalah lingkungan">Pelaporan Masalah Lingkungan</option>
              <option value="Keperluan lainnya">Keperluan Lainnya</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Tanggal Pilihan <span class="text-danger">*</span></label>
            <input type="date" name="tanggal_pilihan" class="form-control"
                   min="<?= today() ?>" value="<?= today() ?>" required>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small">Jam Pilihan <span class="text-danger">*</span></label>
            <select name="jam_pilihan" class="form-select" required>
              <option value="">-- Pilih Jam --</option>
              <?php for ($h=8;$h<=21;$h++): ?>
              <?php foreach(['00','30'] as $m): ?>
              <?php $t=sprintf('%02d:%s',$h,$m); ?>
              <option value="<?=$t?>"><?=$t?> WIB</option>
              <?php endforeach; endfor; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label fw-semibold small">Catatan Tambahan</label>
            <textarea name="catatan" class="form-control" rows="2"
                      placeholder="Jelaskan lebih detail jika perlu..."></textarea>
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-success px-4">
              <i class="bi bi-send me-1"></i>Kirim Permintaan
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php if (!empty($jadwalList)): ?>
  <div class="card">
    <div class="card-header"><i class="bi bi-list-check me-1"></i>Riwayat Permintaan Jadwal</div>
    <div class="card-body p-0">
      <?php foreach ($jadwalList as $j):
        $b = $badgeMap[$j['status']] ?? ['color'=>'secondary','icon'=>'bi-question','label'=>$j['status']];
      ?>
      <div class="d-flex align-items-start gap-3 p-3 border-bottom">
        <div class="rounded-circle d-flex align-items-center justify-content-center flex-shrink-0"
             style="width:40px;height:40px;background:var(--bs-<?=$b['color']?>-bg,#f8f9fa)">
          <i class="bi <?=$b['icon']?> text-<?=$b['color']?>"></i>
        </div>
        <div class="flex-grow-1">
          <div class="fw-semibold"><?= clean($j['keperluan']) ?></div>
          <div class="small text-muted mt-1">
            <i class="bi bi-calendar3 me-1"></i><?= formatTanggal($j['tanggal_pilihan']) ?>
            &nbsp;&bull;&nbsp;
            <i class="bi bi-clock me-1"></i><?= substr($j['jam_pilihan'],0,5) ?> WIB
          </div>
          <?php if ($j['catatan']): ?>
          <div class="small text-muted fst-italic mt-1"><?= clean($j['catatan']) ?></div>
          <?php endif; ?>
          <?php if ($j['catatan_admin']): ?>
          <div class="small text-primary mt-1"><i class="bi bi-chat-left-text me-1"></i><?= clean($j['catatan_admin']) ?></div>
          <?php endif; ?>
        </div>
        <div class="d-flex flex-column align-items-end gap-2">
          <span class="badge bg-<?=$b['color']?>"><?=$b['label']?></span>
          <?php if ($j['status'] === 'menunggu'): ?>
          <a href="?batal=<?=$j['id']?>" class="btn btn-sm btn-outline-danger"
             onclick="return confirm('Batalkan permintaan jadwal ini?')">
            <i class="bi bi-x"></i> Batal
          </a>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
