<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';

$pageTitle = 'Pengumuman';
$basePath  = '..';
$pdo       = getDB();

$filter   = clean($_GET['kategori'] ?? '');
$where    = $filter ? "WHERE p.kategori=:kat" : "";
$stmt     = $pdo->prepare(
    "SELECT p.*, u.nama as penulis FROM pengumuman p LEFT JOIN users u ON p.dibuat_oleh=u.id $where ORDER BY p.created_at DESC"
);
$stmt->execute($filter ? ['kat' => $filter] : []);
$list = $stmt->fetchAll();

$kategoriList = ['sosial','keamanan','kesehatan','lingkungan','laporan_keuangan','lainnya'];
$bColors      = [
    'sosial'            => 'primary',
    'keamanan'          => 'danger',
    'kesehatan'         => 'success',
    'lingkungan'        => 'success',
    'laporan_keuangan'  => 'warning',
    'lainnya'           => 'info',
];
$bLabels = [
    'sosial'           => 'Sosial',
    'keamanan'         => 'Keamanan',
    'kesehatan'        => 'Kesehatan',
    'lingkungan'       => 'Lingkungan',
    'laporan_keuangan' => 'Laporan Keuangan',
    'lainnya'          => 'Lainnya',
];

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4" style="max-width:900px">
  <div class="d-flex align-items-center gap-2 mb-3">
    <a href="../index.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <h4 class="fw-bold mb-0"><i class="bi bi-megaphone text-warning"></i> Pengumuman RT</h4>
  </div>

  <!-- Filter kategori -->
  <div class="d-flex gap-2 mb-4 flex-wrap">
    <a href="pengumuman.php" class="btn btn-sm <?= !$filter ? 'btn-dark' : 'btn-outline-secondary' ?>">Semua</a>
    <?php foreach ($kategoriList as $kat): ?>
    <a href="?kategori=<?= $kat ?>"
       class="btn btn-sm <?= $filter===$kat ? 'btn-'.($bColors[$kat]??'secondary') : 'btn-outline-secondary' ?>">
      <?= $bLabels[$kat] ?? ucfirst($kat) ?>
    </a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($list)): ?>
  <div class="text-center text-muted py-5">
    <i class="bi bi-megaphone fs-1 opacity-25"></i>
    <p class="mt-2">Belum ada pengumuman.</p>
  </div>
  <?php endif; ?>

  <div class="row g-3">
    <?php foreach ($list as $p):
      $bc    = $bColors[$p['kategori']] ?? 'secondary';
      $label = $bLabels[$p['kategori']] ?? ucfirst($p['kategori']);
      $isKeuangan = $p['kategori'] === 'laporan_keuangan';
    ?>
    <div class="col-md-6">
      <div class="card h-100 <?= $isKeuangan ? 'border-warning' : '' ?>">
        <?php if ($isKeuangan): ?>
        <div class="card-header bg-warning bg-opacity-10 border-bottom border-warning d-flex align-items-center gap-2 py-2">
          <i class="bi bi-cash-coin text-warning"></i>
          <small class="fw-semibold text-warning-emphasis">Laporan Keuangan RT</small>
        </div>
        <?php endif; ?>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <span class="badge bg-<?= $bc ?>"><?= $label ?></span>
            <small class="text-muted"><?= formatTanggal(date('Y-m-d', strtotime($p['created_at']))) ?></small>
          </div>
          <h6 class="fw-bold mb-2"><?= clean($p['judul']) ?></h6>
          <p class="small text-muted" style="line-height:1.6"><?= nl2br(clean($p['isi'])) ?></p>

          <?php if (!empty($p['file_pdf'])): ?>
          <a href="../uploads/pengumuman/<?= clean($p['file_pdf']) ?>"
             target="_blank"
             class="btn btn-sm <?= $isKeuangan ? 'btn-warning' : 'btn-outline-danger' ?> mt-2">
            <i class="bi bi-file-earmark-pdf"></i>
            <?= $isKeuangan ? 'Lihat Laporan PDF' : 'Lihat Dokumen PDF' ?>
          </a>
          <?php endif; ?>

          <div class="mt-3">
            <small class="text-muted"><i class="bi bi-person-circle"></i> <?= clean($p['penulis'] ?? 'Pengurus RT') ?></small>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
