<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireLogin();

$pageTitle = 'Anggota Keluarga';
$basePath  = '..';
$pdo       = getDB();
$user      = currentUser();
$error     = '';

// Ambil data diri penduduk (untuk no_kk)
$myData = $pdo->prepare("SELECT * FROM penduduk WHERE user_id=?");
$myData->execute([$user['id']]); $myData = $myData->fetch();
$noKK = $myData['no_kk'] ?? null;

// Tambah anggota
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'tambah') {
    $nik  = trim($_POST['nik']);
    $nama = trim($_POST['nama']);
    $jk   = $_POST['jenis_kelamin'];
    $tl   = trim($_POST['tempat_lahir']);
    $tgl  = $_POST['tanggal_lahir'];
    $agama= $_POST['agama'];
    $kawin= $_POST['status_kawin'];
    $hub  = $_POST['status_hubungan'];
    $pkj  = trim($_POST['pekerjaan']);
    $pend = $_POST['pendidikan'];

    if (!$noKK)                                          $error = 'Data KK Anda belum terdaftar. Hubungi Pak RT.';
    elseif (strlen($nik)!==16||!ctype_digit($nik))       $error = 'NIK harus 16 digit angka.';
    elseif (!$nama)                                      $error = 'Nama anggota wajib diisi.';
    else {
        $cek = $pdo->prepare("SELECT id FROM anggota_keluarga WHERE nik=?");
        $cek->execute([$nik]);
        if ($cek->fetch()) $error = 'NIK sudah terdaftar sebagai anggota keluarga.';
        else {
            $pdo->prepare(
                "INSERT INTO anggota_keluarga (no_kk,user_id_kepala,nik,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,agama,status_kawin,status_hubungan,pekerjaan,pendidikan)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
            )->execute([$noKK,$user['id'],$nik,$nama,$jk,$tl,$tgl,$agama,$kawin,$hub,$pkj,$pend]);
            setFlash('success','Anggota keluarga <strong>'.htmlspecialchars($nama).'</strong> berhasil ditambahkan.');
            redirect('anggota_keluarga.php');
        }
    }
}

// Edit anggota
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'edit') {
    $aid  = intval($_POST['anggota_id']);
    $nama = trim($_POST['nama']);
    $kawin= $_POST['status_kawin'];
    $hub  = $_POST['status_hubungan'];
    $pkj  = trim($_POST['pekerjaan']);
    $pend = $_POST['pendidikan'];

    if (!$nama) $error = 'Nama anggota wajib diisi.';
    else {
        $pdo->prepare("UPDATE anggota_keluarga SET nama=?,status_kawin=?,status_hubungan=?,pekerjaan=?,pendidikan=? WHERE id=? AND user_id_kepala=?")
            ->execute([$nama,$kawin,$hub,$pkj,$pend,$aid,$user['id']]);
        setFlash('success','Data anggota berhasil diperbarui.');
        redirect('anggota_keluarga.php');
    }
}

// Hapus anggota
if (isset($_GET['hapus'])) {
    $hid = intval($_GET['hapus']);
    $pdo->prepare("DELETE FROM anggota_keluarga WHERE id=? AND user_id_kepala=?")->execute([$hid,$user['id']]);
    setFlash('success','Data anggota dihapus.');
    redirect('anggota_keluarga.php');
}

// Daftar anggota
$anggota = [];
if ($noKK) {
    $stmt = $pdo->prepare("SELECT * FROM anggota_keluarga WHERE user_id_kepala=? ORDER BY FIELD(status_hubungan,'Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya'), nama");
    $stmt->execute([$user['id']]); $anggota = $stmt->fetchAll();
}

$editAnggota = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $s   = $pdo->prepare("SELECT * FROM anggota_keluarga WHERE id=? AND user_id_kepala=?");
    $s->execute([$eid,$user['id']]); $editAnggota = $s->fetch();
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4" style="max-width:960px">
  <div class="d-flex align-items-center gap-2 mb-4">
    <a href="profil.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
      <h4 class="fw-bold mb-0"><i class="bi bi-people-fill text-success me-1"></i>Anggota Keluarga</h4>
      <small class="text-muted">Kelola data anggota Kartu Keluarga kamu &nbsp;|&nbsp; No. KK: <code><?= $noKK ? clean($noKK) : '—' ?></code></small>
    </div>
  </div>
  <?= flashHtml() ?>

  <?php if (!$noKK): ?>
  <div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle me-1"></i>
    Data kependudukan kamu belum terdaftar. Hubungi Pak RT untuk mendaftarkan NIK dan No. KK kamu.
  </div>
  <?php else: ?>
  <div class="row g-4">
    <!-- Form tambah / edit -->
    <div class="col-lg-5">
      <div class="card">
        <div class="card-header d-flex align-items-center gap-2">
          <i class="bi bi-<?= $editAnggota ? 'pencil' : 'person-plus' ?>"></i>
          <?= $editAnggota ? 'Edit Data Anggota' : 'Tambah Anggota Keluarga' ?>
        </div>
        <div class="card-body">
          <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>
          <form method="POST">
            <input type="hidden" name="aksi" value="<?= $editAnggota ? 'edit' : 'tambah' ?>">
            <?php if ($editAnggota): ?><input type="hidden" name="anggota_id" value="<?= $editAnggota['id'] ?>"><?php endif; ?>
            <div class="row g-3">
              <?php if (!$editAnggota): ?>
              <div class="col-12">
                <label class="form-label fw-semibold small">NIK (16 digit) <span class="text-danger">*</span></label>
                <input type="text" name="nik" class="form-control font-monospace" maxlength="16"
                       inputmode="numeric" placeholder="3471XXXXXXXXXXXX" required
                       oninput="this.value=this.value.replace(/\D/g,'').slice(0,16)">
              </div>
              <?php endif; ?>
              <div class="col-12">
                <label class="form-label fw-semibold small">Nama Lengkap <span class="text-danger">*</span></label>
                <input type="text" name="nama" class="form-control"
                       value="<?= $editAnggota ? clean($editAnggota['nama']) : '' ?>" required>
              </div>
              <?php if (!$editAnggota): ?>
              <div class="col-6">
                <label class="form-label fw-semibold small">Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-select">
                  <option value="L">Laki-laki</option><option value="P">Perempuan</option>
                </select>
              </div>
              <div class="col-6">
                <label class="form-label fw-semibold small">Agama</label>
                <select name="agama" class="form-select">
                  <?php foreach(['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu'] as $ag): ?>
                  <option><?=$ag?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-6">
                <label class="form-label fw-semibold small">Tempat Lahir</label>
                <input type="text" name="tempat_lahir" class="form-control">
              </div>
              <div class="col-6">
                <label class="form-label fw-semibold small">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" class="form-control">
              </div>
              <?php endif; ?>
              <div class="col-12">
                <label class="form-label fw-semibold small">Hubungan dalam KK</label>
                <select name="status_hubungan" class="form-select">
                  <?php foreach(['Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya'] as $h): ?>
                  <option value="<?=$h?>" <?=$editAnggota&&$editAnggota['status_hubungan']===$h?'selected':''?>><?=$h?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label fw-semibold small">Status Kawin</label>
                <select name="status_kawin" class="form-select">
                  <?php foreach(['Belum Kawin','Kawin','Cerai Hidup','Cerai Mati'] as $sk): ?>
                  <option value="<?=$sk?>" <?=$editAnggota&&$editAnggota['status_kawin']===$sk?'selected':''?>><?=$sk?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label fw-semibold small">Pekerjaan</label>
                <input type="text" name="pekerjaan" class="form-control"
                       value="<?= $editAnggota ? clean($editAnggota['pekerjaan']) : '' ?>">
              </div>
              <div class="col-12">
                <label class="form-label fw-semibold small">Pendidikan Terakhir</label>
                <select name="pendidikan" class="form-select">
                  <?php foreach(['Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3'] as $pd): ?>
                  <option value="<?=$pd?>" <?=$editAnggota&&$editAnggota['pendidikan']===$pd?'selected':''?>><?=$pd?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-12 d-flex gap-2">
                <button type="submit" class="btn btn-success px-3">
                  <i class="bi bi-<?= $editAnggota ? 'check-lg' : 'plus-lg' ?> me-1"></i>
                  <?= $editAnggota ? 'Simpan' : 'Tambah Anggota' ?>
                </button>
                <?php if ($editAnggota): ?>
                <a href="anggota_keluarga.php" class="btn btn-outline-secondary">Batal</a>
                <?php endif; ?>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Daftar anggota -->
    <div class="col-lg-7">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span><i class="bi bi-people me-1"></i>Daftar Anggota</span>
          <span class="badge bg-success"><?= count($anggota) ?> orang</span>
        </div>
        <?php if (empty($anggota)): ?>
        <div class="card-body text-center text-muted py-5">
          <i class="bi bi-people fs-1 d-block mb-2 opacity-25"></i>
          <p class="mb-1">Belum ada anggota keluarga ditambahkan.</p>
          <small>Tambahkan data anggota KK menggunakan form di samping.</small>
        </div>
        <?php else: ?>
        <div class="list-group list-group-flush">
          <?php foreach ($anggota as $a):
            $hubColors=['Kepala Keluarga'=>'success','Istri'=>'info','Anak'=>'primary',
                        'Orang Tua'=>'warning','Mertua'=>'warning','Cucu'=>'info','Lainnya'=>'secondary'];
            $hc=$hubColors[$a['status_hubungan']]??'secondary';
          ?>
          <div class="list-group-item py-3">
            <div class="d-flex align-items-center gap-3">
              <div class="rounded-circle bg-<?=$hc?> bg-opacity-10 border border-<?=$hc?> d-flex align-items-center justify-content-center flex-shrink-0"
                   style="width:42px;height:42px">
                <i class="bi bi-person text-<?=$hc?>"></i>
              </div>
              <div class="flex-grow-1 min-w-0">
                <div class="fw-semibold"><?= clean($a['nama']) ?></div>
                <div class="d-flex flex-wrap gap-1 mt-1">
                  <span class="badge bg-<?=$hc?> bg-opacity-75"><?= $a['status_hubungan'] ?></span>
                  <span class="badge bg-light text-dark border"><?= $a['jenis_kelamin']==='L'?'Laki-laki':'Perempuan' ?></span>
                  <?php if ($a['pekerjaan']): ?>
                  <span class="badge bg-light text-dark border"><?= clean($a['pekerjaan']) ?></span>
                  <?php endif; ?>
                </div>
                <div class="small text-muted mt-1 font-monospace">NIK: <?= clean($a['nik']) ?></div>
              </div>
              <div class="d-flex gap-1">
                <a href="?edit=<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                  <i class="bi bi-pencil"></i>
                </a>
                <a href="?hapus=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger" title="Hapus"
                   onclick="return confirm('Hapus data <?= clean($a['nama']) ?>?')">
                  <i class="bi bi-trash"></i>
                </a>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
