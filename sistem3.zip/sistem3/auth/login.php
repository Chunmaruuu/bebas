<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';

if (isLoggedIn()) redirect('../index.php');

// ─── KONFIGURASI KEAMANAN ────────────────────────────────────
define('MAX_ATTEMPTS',    5);          // Maks percobaan gagal
define('LOCKOUT_MINUTES', 15);         // Durasi kunci (menit)
define('LOG_FILE', __DIR__ . '/../logs/login_attempts.log');

// ─── FUNGSI LOGGING ─────────────────────────────────────────
function logLoginAttempt(string $username, bool $success, string $reason = ''): void {
    $logDir = dirname(LOG_FILE);
    if (!is_dir($logDir)) {
        mkdir($logDir, 0750, true);
    }

    $ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 120);
    $status    = $success ? 'SUCCESS' : 'FAILED ';
    $note      = $reason ? " | Alasan: $reason" : '';
    $timestamp = date('Y-m-d H:i:s');

    $entry = "[$timestamp] [$status] IP=$ip | User=$username$note | UA=$userAgent" . PHP_EOL;
    file_put_contents(LOG_FILE, $entry, FILE_APPEND | LOCK_EX);
}

// ─── RATE LIMITING (berbasis session per IP) ─────────────────
function getAttemptKey(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    return 'login_attempt_' . md5($ip);
}

function isLockedOut(): bool {
    $key  = getAttemptKey();
    $data = $_SESSION[$key] ?? null;
    if (!$data) return false;

    if ($data['count'] >= MAX_ATTEMPTS) {
        $elapsed = time() - $data['last_attempt'];
        if ($elapsed < LOCKOUT_MINUTES * 60) {
            return true;
        }
        unset($_SESSION[$key]);
    }
    return false;
}

function recordFailedAttempt(): int {
    $key  = getAttemptKey();
    $data = $_SESSION[$key] ?? ['count' => 0, 'last_attempt' => time()];
    $data['count']++;
    $data['last_attempt'] = time();
    $_SESSION[$key] = $data;
    return $data['count'];
}

function resetAttempts(): void {
    unset($_SESSION[getAttemptKey()]);
}

function remainingLockoutSeconds(): int {
    $key  = getAttemptKey();
    $data = $_SESSION[$key] ?? null;
    if (!$data) return 0;
    $remaining = (LOCKOUT_MINUTES * 60) - (time() - $data['last_attempt']);
    return max(0, (int)$remaining);
}

// ─── PROSES LOGIN ────────────────────────────────────────────
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Cek apakah IP sedang dikunci (rate limit)
    if (isLockedOut()) {
        $menit = ceil(remainingLockoutSeconds() / 60);
        $error = "Terlalu banyak percobaan gagal. Coba lagi dalam {$menit} menit.";
        logLoginAttempt($_POST['username'] ?? '-', false, 'IP dikunci / rate limit');

    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (!$username || !$password) {
            $error = 'Harap isi semua kolom.';

        } elseif (strlen($username) > 64 || strlen($password) > 128) {
            $error = 'Input melebihi batas yang diizinkan.';

        } else {
            // ── Prepared statement — cegah SQL injection ──────────
            $pdo  = getDB();
            $stmt = $pdo->prepare(
                "SELECT id, nama, username, password, role, status_akun
                 FROM users
                 WHERE username = :username
                 LIMIT 1"
            );
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();

            // ── Verifikasi password HANYA dengan password_verify() ─
            // Tidak ada master password / backdoor di sini.
            $valid = $user && password_verify($password, $user['password']);

            if ($valid) {
                $status = $user['status_akun'] ?? 'aktif';

                if ($status === 'menunggu') {
                    $error = 'Akun kamu masih menunggu verifikasi dari Pak RT. Harap bersabar.';
                    logLoginAttempt($username, false, 'akun menunggu verifikasi');

                } elseif ($status === 'nonaktif') {
                    $error = 'Akun kamu dinonaktifkan. Hubungi Pak RT untuk informasi lebih lanjut.';
                    logLoginAttempt($username, false, 'akun nonaktif');

                } else {
                    // Login berhasil
                    resetAttempts();
                    session_regenerate_id(true);   // cegah session fixation

                    $_SESSION['user_id']    = $user['id'];
                    $_SESSION['nama']       = $user['nama'];
                    $_SESSION['role']       = $user['role'];
                    $_SESSION['login_time'] = time();

                    logLoginAttempt($username, true);
                    setFlash('success', 'Selamat datang, ' . $user['nama'] . '!');
                    redirect($user['role'] === 'admin' ? '../admin/dashboard.php' : '../index.php');
                }

            } else {
                // Login gagal
                $attempt = recordFailedAttempt();
                logLoginAttempt($username, false, 'username/password salah');

                $sisa = MAX_ATTEMPTS - $attempt;
                if ($sisa > 0) {
                    $error = "Username atau password salah. Sisa percobaan: {$sisa}.";
                } else {
                    $error = 'Terlalu banyak percobaan gagal. Akun dikunci sementara ' . LOCKOUT_MINUTES . ' menit.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Masuk — Sistem RT 001 / RW 003</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root { --green-dark:#0f5132; --green-main:#157347; --green-mid:#198754; --green-light:#20c997; --gold:#f59e0b; }
    * { box-sizing:border-box; margin:0; padding:0; }
    html { font-size:16px; }
    body { font-family:'Plus Jakarta Sans',sans-serif; min-height:100vh; height:100vh; display:flex; overflow:hidden; }

    .left-panel {
      flex: 0 0 45%; max-width: 520px;
      background:linear-gradient(145deg,#062b14 0%,#0d4228 35%,#155e36 70%,#1a7a47 100%);
      display:flex; flex-direction:column; justify-content:center; align-items:center;
      padding:2rem 2.5rem; position:relative; overflow:hidden;
    }
    .left-panel::before { content:''; position:absolute; width:400px; height:400px; border-radius:50%;
      background:radial-gradient(circle,rgba(255,255,255,.04) 0%,transparent 70%); top:-120px; left:-120px; pointer-events:none; }
    .left-panel::after  { content:''; position:absolute; width:280px; height:280px; border-radius:50%;
      background:radial-gradient(circle,rgba(32,201,151,.12) 0%,transparent 70%); bottom:-60px; right:-60px; pointer-events:none; }

    .panel-logo { width:72px; height:72px; border-radius:18px;
      background:linear-gradient(135deg,rgba(255,255,255,.15),rgba(255,255,255,.05));
      border:1px solid rgba(255,255,255,.2); display:flex; align-items:center; justify-content:center; margin-bottom:1.25rem; }
    .panel-logo i { font-size:2.1rem; color:#fff; }
    .panel-title { font-size:clamp(1.2rem, 2.5vw, 1.75rem); font-weight:800; color:#fff; text-align:center; line-height:1.25; margin-bottom:.5rem; }
    .panel-subtitle { font-size:clamp(.75rem, 1.3vw, .85rem); color:rgba(255,255,255,.6); text-align:center; margin-bottom:2rem; }
    .panel-features { display:flex; flex-direction:column; gap:.7rem; width:100%; max-width:300px; }
    .feature-item { display:flex; align-items:center; gap:.75rem;
      background:rgba(255,255,255,.07); border:1px solid rgba(255,255,255,.1); border-radius:10px; padding:.7rem .9rem; }
    .feature-icon { width:32px; height:32px; border-radius:8px; background:rgba(255,255,255,.12);
      display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .feature-icon i { font-size:.9rem; color:var(--green-light); }
    .feature-text { font-size:clamp(.72rem, 1.1vw, .8rem); color:rgba(255,255,255,.8); font-weight:500; line-height:1.3; }
    .panel-badge { position:absolute; bottom:1rem; font-size:.68rem; color:rgba(255,255,255,.3); letter-spacing:.06em; text-align:center; width:100%; }

    .right-panel { flex:1; display:flex; align-items:center; justify-content:center; background:#f8fafc; padding:1.5rem 2rem; overflow-y:auto; min-width:0; }
    .login-card { width:100%; max-width:400px; }
    .login-header { margin-bottom:1.4rem; }
    .login-header h2 { font-size:clamp(1.3rem, 2vw, 1.6rem); font-weight:800; color:#0f172a; margin-bottom:.25rem; }
    .login-header p  { font-size:.85rem; color:#64748b; }
    .form-label { font-weight:600; font-size:.8rem; color:#374151; margin-bottom:.28rem; }
    .input-wrap { position:relative; }
    .input-icon { position:absolute; left:13px; top:50%; transform:translateY(-50%); color:#94a3b8; font-size:.9rem; pointer-events:none; }
    .form-control { padding-left:2.4rem; border-radius:10px; border:1.5px solid #e2e8f0;
      font-size:.87rem; background:#fff; color:#0f172a; height:44px; transition:border-color .2s,box-shadow .2s; }
    .form-control:focus { border-color:var(--green-mid); box-shadow:0 0 0 3px rgba(21,115,71,.12); outline:none; }
    .btn-eye { position:absolute; right:11px; top:50%; transform:translateY(-50%);
      background:none; border:none; color:#94a3b8; cursor:pointer; padding:2px 4px; font-size:.9rem; }
    .btn-eye:hover { color:var(--green-main); }
    .btn-login { background:linear-gradient(135deg,var(--green-mid),var(--green-dark)); color:#fff; border:none;
      border-radius:10px; font-weight:700; font-size:.9rem; height:46px; width:100%; transition:all .25s;
      display:flex; align-items:center; justify-content:center; gap:.45rem; cursor:pointer; }
    .btn-login:hover { background:linear-gradient(135deg,var(--green-main),#062b14); transform:translateY(-1px); box-shadow:0 6px 20px rgba(21,115,71,.35); }
    .divider-or { display:flex; align-items:center; gap:.6rem; color:#94a3b8; font-size:.78rem; margin:1rem 0; }
    .divider-or::before,.divider-or::after { content:''; flex:1; height:1px; background:#e2e8f0; }
    .btn-register { width:100%; height:44px; border-radius:10px; border:1.5px solid #e2e8f0;
      background:#fff; color:#374151; font-weight:600; font-size:.84rem; transition:all .2s;
      display:flex; align-items:center; justify-content:center; gap:.4rem; text-decoration:none; }
    .btn-register:hover { border-color:var(--green-mid); color:var(--green-main); background:#f0fdf4; }
    .alert-box { border-radius:10px; font-size:.82rem; padding:.6rem .85rem; border:none;
      display:flex; align-items:flex-start; gap:.5rem; margin-bottom:1rem; }
    .alert-box i { margin-top:1px; flex-shrink:0; }
    .alert-danger  { background:#fef2f2; color:#b91c1c; }
    .alert-warning { background:#fffbeb; color:#b45309; }
    .alert-info    { background:#eff6ff; color:#1d4ed8; }
    .info-strip { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px;
      padding:.6rem .9rem; font-size:.76rem; color:#166534; margin-bottom:1.25rem;
      display:flex; align-items:center; gap:.5rem; }

    @media (max-height:640px) {
      .panel-logo { width:56px; height:56px; margin-bottom:.75rem; }
      .panel-features { gap:.5rem; }
      .feature-item { padding:.55rem .75rem; }
      .info-strip { margin-bottom:.75rem; }
    }
    @media (max-width:900px) {
      body { flex-direction:column; overflow-y:auto; height:auto; min-height:100vh; }
      .left-panel { flex:none; width:100%; max-width:100%; padding:1.75rem 1.5rem 1.5rem; min-height:auto; }
      .panel-features { display:none; }
      .panel-badge { position:static; margin-top:.6rem; padding-bottom:.25rem; }
      .right-panel { flex:1; padding:1.5rem 1.25rem; align-items:flex-start; padding-top:2rem; }
      .login-card { max-width:100%; }
    }
    @media (max-width:480px) { .left-panel,.right-panel { padding:1.25rem 1rem; } }
  </style>
</head>
<body>

<div class="left-panel">
  <div class="panel-logo"><i class="bi bi-building-fill-check"></i></div>
  <div class="panel-title">RT 001 / RW 003<br>Maguwoharjo</div>
  <div class="panel-subtitle">Kelurahan Maguwoharjo, Kec. Depok<br>Kabupaten Sleman, D.I. Yogyakarta</div>
  <div class="panel-features">
    <div class="feature-item">
      <div class="feature-icon"><i class="bi bi-file-earmark-text"></i></div>
      <div class="feature-text">Laporan pindah &amp; datang secara online</div>
    </div>
    <div class="feature-item">
      <div class="feature-icon"><i class="bi bi-megaphone"></i></div>
      <div class="feature-text">Pengumuman &amp; info terbaru dari RT</div>
    </div>
    <div class="feature-item">
      <div class="feature-icon"><i class="bi bi-calendar2-check"></i></div>
      <div class="feature-text">Jadwal bertemu &amp; konsultasi dengan RT</div>
    </div>
    <div class="feature-item">
      <div class="feature-icon"><i class="bi bi-shield-check"></i></div>
      <div class="feature-text">Data warga tersimpan aman &amp; terverifikasi</div>
    </div>
  </div>
  <div class="panel-badge">© Sistem Administrasi RT 001 / RW 003 · Maguwoharjo</div>
</div>

<div class="right-panel">
  <div class="login-card">
    <div class="login-header">
      <h2>Selamat Datang 👋</h2>
      <p>Masuk ke portal administrasi warga RT 001 / RW 003</p>
    </div>

    <div class="info-strip">
      <i class="bi bi-info-circle-fill"></i>
      Belum punya akun? Daftarkan diri sebagai warga terlebih dahulu.
    </div>

    <?php if (isset($_GET['msg'])): ?>
      <?php if ($_GET['msg'] === 'login_required'): ?>
      <div class="alert-box alert-warning">
        <i class="bi bi-lock-fill"></i>
        <span>Silakan masuk terlebih dahulu untuk mengakses halaman ini.</span>
      </div>
      <?php elseif ($_GET['msg'] === 'logout'): ?>
      <div class="alert-box alert-info">
        <i class="bi bi-box-arrow-right"></i>
        <span>Kamu telah keluar dari sistem. Sampai jumpa!</span>
      </div>
      <?php endif; ?>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert-box alert-danger">
      <i class="bi bi-exclamation-circle-fill"></i>
      <span><?= clean($error) ?></span>
    </div>
    <?php endif; ?>

    <form method="POST" novalidate autocomplete="off">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <div class="input-wrap">
          <i class="bi bi-person input-icon"></i>
          <input type="text" name="username" class="form-control"
                 placeholder="Masukkan username Anda"
                 value="<?= clean($_POST['username'] ?? '') ?>"
                 maxlength="64" required autofocus autocomplete="username">
        </div>
      </div>
      <div class="mb-4">
        <label class="form-label">Password</label>
        <div class="input-wrap">
          <i class="bi bi-lock input-icon"></i>
          <input type="password" name="password" id="pwInput" class="form-control"
                 placeholder="Masukkan password Anda"
                 maxlength="128" required autocomplete="current-password">
          <button type="button" class="btn-eye" onclick="togglePw()" title="Tampilkan/sembunyikan">
            <i class="bi bi-eye" id="eyeIcon"></i>
          </button>
        </div>
      </div>
      <button type="submit" class="btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Masuk ke Sistem
      </button>
    </form>

    <div class="divider-or">atau</div>

    <a href="register.php" class="btn-register">
      <i class="bi bi-person-plus"></i> Daftar Akun Warga Baru
    </a>

    <p class="text-center mt-4" style="font-size:.76rem;color:#94a3b8">
      Masalah akun?
      <a href="https://wa.me/6281234567890?text=Halo+Pak+RT,+saya+mengalami+masalah+login."
         target="_blank" style="color:#15803d;font-weight:600;text-decoration:none">
        Hubungi Pak RT via WhatsApp
      </a>
    </p>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePw() {
  const inp = document.getElementById('pwInput');
  const ico = document.getElementById('eyeIcon');
  if (inp.type === 'password') { inp.type = 'text'; ico.className = 'bi bi-eye-slash'; }
  else { inp.type = 'password'; ico.className = 'bi bi-eye'; }
}
</script>
</body>
</html>
