<?php
// auth/register.php — Registrasi Warga Baru (Multi-Step + Upload Foto KTP & KK)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';

if (isLoggedIn()) redirect('../index.php');

$pdo    = getDB();
$errors = [];
$step   = intval($_POST['step'] ?? 1);
$post   = $_POST;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_final'])) {
    $username = trim($post['username']);
    $password = trim($post['password']);
    $repass   = trim($post['repassword']);
    $no_hp    = trim($post['no_hp']);
    $email    = trim($post['email']);
    $nik      = trim($post['nik']);
    $nama     = trim($post['nama']);
    $jk       = $post['jenis_kelamin'];
    $tl       = trim($post['tempat_lahir']);
    $tgl_l    = $post['tanggal_lahir'];
    $agama    = $post['agama'];
    $kawin    = $post['status_kawin'];
    $hubungan = $post['status_hubungan'];
    $pkj      = trim($post['pekerjaan']);
    $pend     = $post['pendidikan'];
    $no_kk    = trim($post['no_kk']);
    $kk_nama  = trim($post['nama_kepala_kk']);
    $jml_kel  = intval($post['jumlah_keluarga']);
    $alamat   = trim($post['alamat']);
    $rt       = trim($post['no_rt']) ?: '001';
    $rw       = trim($post['no_rw']) ?: '003';
    $kpos     = trim($post['kode_pos']);
    $kelurahan  = trim($post['kelurahan']) ?: 'Maguwoharjo';
    $kecamatan  = trim($post['kecamatan']) ?: 'Depok';
    $kabupaten  = trim($post['kabupaten']) ?: 'Sleman';
    $provinsi   = trim($post['provinsi']) ?: 'D.I. Yogyakarta';

    if (strlen($username) < 4)       $errors[] = 'Username minimal 4 karakter.';
    if (strlen($password) < 6)       $errors[] = 'Password minimal 6 karakter.';
    if ($password !== $repass)       $errors[] = 'Konfirmasi password tidak cocok.';
    if (strlen($nik) !== 16 || !ctype_digit($nik)) $errors[] = 'NIK harus 16 angka.';
    if (!$nama)                      $errors[] = 'Nama lengkap wajib diisi.';
    if (strlen($no_kk) !== 16 || !ctype_digit($no_kk)) $errors[] = 'No. KK harus 16 angka.';
    if (!$alamat)                    $errors[] = 'Alamat wajib diisi.';
    if (!$kpos)                      $errors[] = 'Kode pos wajib diisi.';
    if ($jml_kel < 1)                $errors[] = 'Jumlah anggota keluarga minimal 1.';
    if (empty($_FILES['foto_ktp']['name'])) $errors[] = 'Foto KTP wajib diunggah.';
    if (empty($_FILES['foto_kk']['name']))  $errors[] = 'Foto Kartu Keluarga wajib diunggah.';

    if (!$errors) {
        $cekUser = $pdo->prepare("SELECT id FROM users WHERE username=?");
        $cekUser->execute([$username]);
        if ($cekUser->fetch()) $errors[] = "Username '$username' sudah digunakan.";
        $cekNik = $pdo->prepare("SELECT id FROM penduduk WHERE nik=? UNION SELECT id FROM registrasi_warga WHERE nik=? AND status='menunggu'");
        $cekNik->execute([$nik, $nik]);
        if ($cekNik->fetch()) $errors[] = "NIK sudah terdaftar atau sedang dalam proses verifikasi.";
    }

    $fotoKtpPath = null;
    $fotoKkPath  = null;
    if (!$errors) {
        $uploadDir = __DIR__ . '/../uploads/';
        $allowed   = ['image/jpeg','image/jpg','image/png','image/webp','application/pdf'];
        $maxSize   = 5 * 1024 * 1024;
        foreach (['foto_ktp' => 'ktp', 'foto_kk' => 'kk'] as $field => $subfolder) {
            $file = $_FILES[$field];
            if ($file['error'] !== UPLOAD_ERR_OK) { $errors[] = "Gagal upload " . strtoupper(str_replace('_',' ',$field)) . "."; continue; }
            if ($file['size'] > $maxSize)          { $errors[] = strtoupper(str_replace('_',' ',$field)) . " maksimal 5MB."; continue; }
            $mime = mime_content_type($file['tmp_name']);
            if (!in_array($mime, $allowed))        { $errors[] = strtoupper(str_replace('_',' ',$field)) . " harus JPG/PNG/WEBP/PDF."; continue; }
            $ext  = pathinfo($file['name'], PATHINFO_EXTENSION);
            $fname = $subfolder . '_' . $nik . '_' . time() . '.' . $ext;
            $dest  = $uploadDir . $subfolder . '/' . $fname;
            if (!is_dir($uploadDir . $subfolder)) mkdir($uploadDir . $subfolder, 0755, true);
            move_uploaded_file($file['tmp_name'], $dest);
            if ($field === 'foto_ktp') $fotoKtpPath = $subfolder . '/' . $fname;
            else                       $fotoKkPath  = $subfolder . '/' . $fname;
        }
    }

    if (!$errors) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare(
            "INSERT INTO registrasi_warga
             (username,password,no_hp,email,nik,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,
              agama,status_kawin,status_hubungan,pekerjaan,pendidikan,
              no_kk,nama_kepala_kk,jumlah_keluarga,
              alamat,no_rt,no_rw,kode_pos,kelurahan,kecamatan,kabupaten,provinsi,foto_ktp,foto_kk)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        )->execute([$username,$hashed,$no_hp,$email,$nik,$nama,$jk,$tl,$tgl_l,
            $agama,$kawin,$hubungan,$pkj,$pend,$no_kk,$kk_nama,$jml_kel,
            $alamat,$rt,$rw,$kpos,$kelurahan,$kecamatan,$kabupaten,$provinsi,$fotoKtpPath,$fotoKkPath]);
        ?><!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Registrasi Berhasil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body{font-family:'Plus Jakarta Sans',sans-serif;background:#f0fdf4;display:flex;align-items:center;justify-content:center;min-height:100vh;}
    .box{background:#fff;border-radius:20px;padding:3rem 2.5rem;max-width:460px;width:100%;box-shadow:0 8px 32px rgba(0,80,30,.1);text-align:center;}
    .chk{width:80px;height:80px;background:linear-gradient(135deg,#15803d,#22c55e);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-bottom:1.25rem;}
  </style>
</head>
<body>
<div class="box">
  <div class="chk"><i class="bi bi-check-lg text-white" style="font-size:2.8rem"></i></div>
  <h4 class="fw-bold mb-2">Pendaftaran Terkirim!</h4>
  <p class="text-muted mb-3">Data dan dokumen <strong><?= clean($nama) ?></strong> sudah diterima.<br>
  Pak RT akan memverifikasi dan menghubungi melalui <strong><?= clean($no_hp ?: '-') ?></strong>.</p>
  <div class="alert alert-info text-start small mb-4 rounded-3">
    <i class="bi bi-clock-history me-1"></i> <strong>Menunggu Verifikasi</strong> — biasanya 1–2 hari kerja.
  </div>
  <a href="login.php" class="btn btn-success px-5 py-2 fw-bold">
    <i class="bi bi-box-arrow-in-right me-1"></i>Ke Halaman Login
  </a>
</div>
</body></html>
        <?php exit;
    }
    $step = 4;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Daftar Akun — Sistem RT 001</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root{--g:#16a34a;--gd:#15803d;--gl:#f0fdf4;}
    body{font-family:'Plus Jakarta Sans',sans-serif;background:#f0fdf4;padding:2rem 1rem;}
    .reg-wrap{max-width:680px;margin:0 auto;}
    .reg-card{background:#fff;border-radius:18px;box-shadow:0 4px 24px rgba(0,60,20,.07);padding:2rem;}
    .steps{display:flex;align-items:center;justify-content:center;margin-bottom:1.75rem;}
    .si{display:flex;flex-direction:column;align-items:center;gap:5px;}
    .sc{width:34px;height:34px;border-radius:50%;border:2px solid #d1d5db;background:#fff;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:#9ca3af;}
    .sc.active{border-color:var(--g);background:var(--g);color:#fff;}
    .sc.done{border-color:var(--g);background:var(--g);color:#fff;}
    .sl{font-size:.68rem;color:#9ca3af;font-weight:600;white-space:nowrap;}
    .sl.active{color:var(--g);}
    .sline{width:50px;height:2px;background:#e5e7eb;margin-bottom:18px;flex-shrink:0;}
    .sline.done{background:var(--g);}
    .sec-lbl{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--g);border-bottom:2px solid #dcfce7;padding-bottom:.4rem;margin:1.25rem 0 .9rem;}
    .sec-lbl:first-child{margin-top:0;}
    .form-control:focus,.form-select:focus{border-color:var(--g);box-shadow:0 0 0 .2rem rgba(22,163,74,.15);}
    .btn-rt{background:var(--g);color:#fff;border:none;font-weight:700;border-radius:10px;}
    .btn-rt:hover{background:var(--gd);color:#fff;}
    .fhint{font-size:.72rem;color:#9ca3af;margin-top:.2rem;}
    .upload-area{border:2px dashed #86efac;border-radius:12px;background:#f0fdf4;padding:1.25rem;text-align:center;cursor:pointer;transition:.2s;position:relative;}
    .upload-area:hover{border-color:var(--g);background:#dcfce7;}
    .upload-area input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;}
    .upload-preview{max-width:100%;max-height:150px;border-radius:8px;margin-top:.6rem;border:1px solid #bbf7d0;display:none;}
    .prev-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:.9rem 1.1rem;}
    .pr{display:flex;padding:.28rem 0;font-size:.82rem;border-bottom:1px solid #dcfce7;}
    .pr:last-child{border-bottom:none;}
    .pl{color:#6b7280;min-width:140px;flex-shrink:0;}
    .pv{font-weight:600;color:#111827;}
    label.form-label{font-weight:600;font-size:.83rem;margin-bottom:.25rem;}
    .req{color:#ef4444;}
  </style>
</head>
<body>
<div class="reg-wrap">
  <div class="text-center mb-3">
    <div style="background:linear-gradient(135deg,#15803d,#16a34a);border-radius:14px;width:52px;height:52px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:.6rem;box-shadow:0 4px 14px rgba(22,163,74,.3)">
      <i class="bi bi-person-plus-fill text-white fs-5"></i>
    </div>
    <h5 class="fw-bold mb-0">Daftar Akun Warga</h5>
    <small class="text-muted">RT 001 / RW 003 — Kel. Maguwoharjo, Kab. Sleman</small>
  </div>

  <?php
  $cs = $step;
  $stepLabels = [1=>'Akun Login',2=>'Data Diri',3=>'KK & Alamat',4=>'Dokumen'];
  ?>
  <div class="steps">
    <?php foreach($stepLabels as $sn=>$sl):
      $done=$cs>$sn; $act=$cs===$sn; ?>
    <div class="si">
      <div class="sc <?=$done?'done':($act?'active':'')?>">
        <?=$done?'<i class="bi bi-check-lg"></i>':$sn?>
      </div>
      <div class="sl <?=$act?'active':''?>"><?=$sl?></div>
    </div>
    <?php if($sn<count($stepLabels)):?><div class="sline <?=$cs>$sn?'done':''?>"></div><?php endif;?>
    <?php endforeach;?>
  </div>

  <?php if(!empty($errors)):?>
  <div class="alert alert-danger mb-3 rounded-3 small">
    <strong><i class="bi bi-exclamation-circle me-1"></i>Perbaiki:</strong>
    <ul class="mb-0 mt-1 ps-3"><?php foreach($errors as $e):?><li><?=clean($e)?></li><?php endforeach;?></ul>
  </div>
  <?php endif;?>

  <div class="reg-card">

  <?php if($cs===1):?>
  <!-- STEP 1: Akun Login -->
  <form method="POST">
    <input type="hidden" name="step" value="2">
    <div class="sec-lbl"><i class="bi bi-person-lock me-1"></i>Informasi Akun Login</div>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Username <span class="req">*</span></label>
        <div class="input-group"><span class="input-group-text"><i class="bi bi-at"></i></span>
        <input type="text" name="username" class="form-control" placeholder="min. 4 karakter"
               value="<?=clean($post['username']??'')?>" required minlength="4"></div>
        <div class="fhint">Digunakan untuk login ke sistem.</div>
      </div>
      <div class="col-md-6">
        <label class="form-label">No. HP / WhatsApp <span class="req">*</span></label>
        <div class="input-group"><span class="input-group-text"><i class="bi bi-phone"></i></span>
        <input type="text" name="no_hp" class="form-control" placeholder="08xx-xxxx-xxxx"
               value="<?=clean($post['no_hp']??'')?>" required></div>
        <div class="fhint">Untuk konfirmasi dari Pak RT.</div>
      </div>
      <div class="col-12">
        <label class="form-label">Email (opsional)</label>
        <div class="input-group"><span class="input-group-text"><i class="bi bi-envelope"></i></span>
        <input type="email" name="email" class="form-control" placeholder="nama@email.com"
               value="<?=clean($post['email']??'')?>"></div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Password <span class="req">*</span></label>
        <div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span>
        <input type="password" name="password" id="pw1" class="form-control" placeholder="min. 6 karakter" required minlength="6">
        <button type="button" class="btn btn-outline-secondary" onclick="togglePw('pw1',this)"><i class="bi bi-eye"></i></button></div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Konfirmasi Password <span class="req">*</span></label>
        <div class="input-group"><span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
        <input type="password" name="repassword" id="pw2" class="form-control" placeholder="Ulangi password" required>
        <button type="button" class="btn btn-outline-secondary" onclick="togglePw('pw2',this)"><i class="bi bi-eye"></i></button></div>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mt-4">
      <a href="login.php" class="text-muted small"><i class="bi bi-arrow-left"></i> Sudah punya akun?</a>
      <button type="submit" class="btn btn-rt px-4">Lanjut <i class="bi bi-arrow-right-short"></i></button>
    </div>
  </form>

  <?php elseif($cs===2):?>
  <!-- STEP 2: Data Diri -->
  <form method="POST">
    <input type="hidden" name="step" value="3">
    <?php foreach(['username','no_hp','email','password','repassword'] as $f):?>
    <input type="hidden" name="<?=$f?>" value="<?=clean($post[$f]??'')?>">
    <?php endforeach;?>
    <div class="sec-lbl"><i class="bi bi-person-vcard me-1"></i>Data Pribadi</div>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">NIK (16 digit) <span class="req">*</span></label>
        <input type="text" name="nik" class="form-control font-monospace" maxlength="16"
               inputmode="numeric" placeholder="3471XXXXXXXXXXXX"
               value="<?=clean($post['nik']??'')?>" required>
        <div class="fhint">Sesuai KTP.</div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Nama Lengkap <span class="req">*</span></label>
        <input type="text" name="nama" class="form-control" placeholder="Sesuai KTP"
               value="<?=clean($post['nama']??'')?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Jenis Kelamin <span class="req">*</span></label>
        <select name="jenis_kelamin" class="form-select" required>
          <option value="L" <?=($post['jenis_kelamin']??'')==='L'?'selected':''?>>Laki-laki</option>
          <option value="P" <?=($post['jenis_kelamin']??'')==='P'?'selected':''?>>Perempuan</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Tempat Lahir</label>
        <input type="text" name="tempat_lahir" class="form-control" value="<?=clean($post['tempat_lahir']??'')?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Tanggal Lahir</label>
        <input type="date" name="tanggal_lahir" class="form-control" value="<?=clean($post['tanggal_lahir']??'')?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Agama</label>
        <select name="agama" class="form-select">
          <?php foreach(['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu'] as $ag):?>
          <option value="<?=$ag?>" <?=($post['agama']??'Islam')===$ag?'selected':''?>><?=$ag?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Status Kawin</label>
        <select name="status_kawin" class="form-select">
          <?php foreach(['Belum Kawin','Kawin','Cerai Hidup','Cerai Mati'] as $sk):?>
          <option value="<?=$sk?>" <?=($post['status_kawin']??'Belum Kawin')===$sk?'selected':''?>><?=$sk?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Hubungan dalam KK</label>
        <select name="status_hubungan" class="form-select">
          <?php foreach(['Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya'] as $h):?>
          <option value="<?=$h?>" <?=($post['status_hubungan']??'Kepala Keluarga')===$h?'selected':''?>><?=$h?></option>
          <?php endforeach;?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Pekerjaan</label>
        <input type="text" name="pekerjaan" class="form-control" value="<?=clean($post['pekerjaan']??'')?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Pendidikan Terakhir</label>
        <select name="pendidikan" class="form-select">
          <?php foreach(['Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3'] as $pd):?>
          <option value="<?=$pd?>" <?=($post['pendidikan']??'SMA/SMK')===$pd?'selected':''?>><?=$pd?></option>
          <?php endforeach;?>
        </select>
      </div>
    </div>
    <div class="d-flex justify-content-between mt-4">
      <button type="button" class="btn btn-outline-secondary" onclick="history.back()"><i class="bi bi-arrow-left"></i> Kembali</button>
      <button type="submit" class="btn btn-rt px-4">Lanjut <i class="bi bi-arrow-right-short"></i></button>
    </div>
  </form>

  <?php elseif($cs===3):?>
  <!-- STEP 3: KK & Alamat -->
  <form method="POST">
    <input type="hidden" name="step" value="4">
    <?php foreach(['username','no_hp','email','password','repassword',
                   'nik','nama','jenis_kelamin','tempat_lahir','tanggal_lahir',
                   'agama','status_kawin','status_hubungan','pekerjaan','pendidikan'] as $f):?>
    <input type="hidden" name="<?=$f?>" value="<?=clean($post[$f]??'')?>">
    <?php endforeach;?>
    <div class="sec-lbl"><i class="bi bi-house-fill me-1"></i>Data Kartu Keluarga & Alamat</div>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">No. Kartu Keluarga (16 digit) <span class="req">*</span></label>
        <input type="text" name="no_kk" class="form-control font-monospace" maxlength="16"
               inputmode="numeric" placeholder="3471XXXXXXXXXXXX"
               value="<?=clean($post['no_kk']??'')?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Nama Kepala Keluarga</label>
        <input type="text" name="nama_kepala_kk" class="form-control"
               value="<?=clean($post['nama_kepala_kk']??'')?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Jumlah Anggota KK <span class="req">*</span></label>
        <input type="number" name="jumlah_keluarga" class="form-control" min="1" max="20"
               value="<?=clean($post['jumlah_keluarga']??'1')?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">No. RT <span class="req">*</span></label>
        <input type="text" name="no_rt" class="form-control font-monospace" maxlength="5" placeholder="001"
               value="<?=clean($post['no_rt']??'001')?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">No. RW <span class="req">*</span></label>
        <input type="text" name="no_rw" class="form-control font-monospace" maxlength="5" placeholder="003"
               value="<?=clean($post['no_rw']??'003')?>" required>
      </div>
      <div class="col-12">
        <label class="form-label">Alamat Lengkap <span class="req">*</span></label>
        <textarea name="alamat" class="form-control" rows="2" required><?=clean($post['alamat']??'')?></textarea>
      </div>
      <div class="col-md-4">
        <label class="form-label">Kelurahan / Desa</label>
        <input type="text" name="kelurahan" class="form-control" value="<?=clean($post['kelurahan']??'Maguwoharjo')?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Kecamatan</label>
        <input type="text" name="kecamatan" class="form-control" value="<?=clean($post['kecamatan']??'Depok')?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Kode Pos <span class="req">*</span></label>
        <input type="text" name="kode_pos" class="form-control font-monospace" maxlength="10"
               inputmode="numeric" placeholder="55282"
               value="<?=clean($post['kode_pos']??'')?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Kabupaten / Kota</label>
        <input type="text" name="kabupaten" class="form-control" value="<?=clean($post['kabupaten']??'Sleman')?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Provinsi</label>
        <input type="text" name="provinsi" class="form-control" value="<?=clean($post['provinsi']??'D.I. Yogyakarta')?>">
      </div>
    </div>
    <div class="d-flex justify-content-between mt-4">
      <button type="button" class="btn btn-outline-secondary" onclick="history.back()"><i class="bi bi-arrow-left"></i> Kembali</button>
      <button type="submit" class="btn btn-rt px-4">Lanjut <i class="bi bi-arrow-right-short"></i></button>
    </div>
  </form>

  <?php elseif($cs===4):?>
  <!-- STEP 4: Upload Dokumen -->
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="step" value="4">
    <input type="hidden" name="submit_final" value="1">
    <?php foreach(['username','no_hp','email','password','repassword',
                   'nik','nama','jenis_kelamin','tempat_lahir','tanggal_lahir',
                   'agama','status_kawin','status_hubungan','pekerjaan','pendidikan',
                   'no_kk','nama_kepala_kk','jumlah_keluarga','alamat','no_rt','no_rw',
                   'kode_pos','kelurahan','kecamatan','kabupaten','provinsi'] as $f):?>
    <input type="hidden" name="<?=$f?>" value="<?=clean($post[$f]??'')?>">
    <?php endforeach;?>

    <div class="sec-lbl"><i class="bi bi-file-earmark-image me-1"></i>Upload Dokumen Identitas</div>
    <div class="alert alert-info small rounded-3 mb-3">
      <i class="bi bi-info-circle me-1"></i>
      Upload foto/scan <strong>KTP</strong> dan <strong>Kartu Keluarga</strong> untuk verifikasi.
      Format JPG, PNG, WEBP, atau PDF · maks. <strong>5MB</strong> per file.
    </div>
    <div class="row g-3 mb-4">
      <div class="col-md-6">
        <label class="form-label">Foto KTP <span class="req">*</span></label>
        <div class="upload-area" id="areaKtp">
          <input type="file" name="foto_ktp" accept="image/*,.pdf" required
                 onchange="previewFile(this,'prevKtp','areaKtp')">
          <i class="bi bi-card-image text-success" style="font-size:2rem"></i>
          <div class="mt-1 fw-bold small">Klik untuk upload Foto KTP</div>
          <div class="fhint">JPG / PNG / PDF · maks. 5MB</div>
          <img id="prevKtp" class="upload-preview" alt="Preview KTP">
        </div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Foto Kartu Keluarga <span class="req">*</span></label>
        <div class="upload-area" id="areaKk">
          <input type="file" name="foto_kk" accept="image/*,.pdf" required
                 onchange="previewFile(this,'prevKk','areaKk')">
          <i class="bi bi-file-person text-success" style="font-size:2rem"></i>
          <div class="mt-1 fw-bold small">Klik untuk upload Foto KK</div>
          <div class="fhint">JPG / PNG / PDF · maks. 5MB</div>
          <img id="prevKk" class="upload-preview" alt="Preview KK">
        </div>
      </div>
    </div>

    <div class="sec-lbl"><i class="bi bi-eye me-1"></i>Ringkasan Data</div>
    <div class="prev-box mb-3">
      <div class="pr"><span class="pl">Username</span><span class="pv"><?=clean($post['username']??'')?></span></div>
      <div class="pr"><span class="pl">NIK</span><span class="pv font-monospace"><?=clean($post['nik']??'')?></span></div>
      <div class="pr"><span class="pl">Nama</span><span class="pv"><?=clean($post['nama']??'')?></span></div>
      <div class="pr"><span class="pl">No. HP</span><span class="pv"><?=clean($post['no_hp']??'')?></span></div>
      <div class="pr"><span class="pl">No. KK</span><span class="pv font-monospace"><?=clean($post['no_kk']??'')?></span></div>
      <div class="pr"><span class="pl">Alamat</span><span class="pv"><?=clean($post['alamat']??'')?></span></div>
      <div class="pr"><span class="pl">RT / RW</span><span class="pv"><?=clean($post['no_rt']??'001')?> / <?=clean($post['no_rw']??'003')?></span></div>
    </div>
    <div class="alert alert-warning small rounded-3">
      <i class="bi bi-shield-check me-1"></i>
      Setelah mendaftar, akun akan <strong>diverifikasi Pak RT</strong> sebelum aktif.
    </div>
    <div class="d-flex justify-content-between mt-3">
      <button type="button" class="btn btn-outline-secondary" onclick="history.back()"><i class="bi bi-arrow-left"></i> Kembali</button>
      <button type="submit" class="btn btn-rt px-4"><i class="bi bi-send-check me-1"></i>Kirim Pendaftaran</button>
    </div>
  </form>
  <?php endif;?>
  </div>

  <p class="text-center text-muted small mt-3">
    Sudah punya akun? <a href="login.php" class="text-success fw-bold">Masuk di sini</a>
  </p>
</div>
<script>
function togglePw(id,btn){const i=document.getElementById(id);const t=i.type==='text';i.type=t?'password':'text';btn.innerHTML=t?'<i class="bi bi-eye"></i>':'<i class="bi bi-eye-slash"></i>';}
function previewFile(inp,pid,aid){const f=inp.files[0];const p=document.getElementById(pid);const a=document.getElementById(aid);if(f&&f.type.startsWith('image/')){const r=new FileReader();r.onload=e=>{p.src=e.target.result;p.style.display='block';};r.readAsDataURL(f);}else{p.style.display='none';}if(f){a.style.borderColor='#16a34a';a.style.background='#dcfce7';}}
document.querySelectorAll('input.font-monospace').forEach(i=>{if(i.inputMode==='numeric')i.addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,16);});});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
