<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ----- AUTH -----

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}   

function isAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        redirect('../index.php?msg=login_required');
    }
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        redirect('../index.php?msg=akses_ditolak');
    }
}

function currentUser(): array {
    return [
        'id'   => $_SESSION['user_id']   ?? null,
        'nama' => $_SESSION['nama']      ?? '',
        'role' => $_SESSION['role']      ?? '',
    ];
}

// ----- REDIRECT -----

function redirect(string $url): never {
    header("Location: $url");
    exit;
}

// ----- FLASH MESSAGE -----

function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function flashHtml(): string {
    $flash = getFlash();
    if (!$flash) return '';
    $icons = ['success' => '✓', 'danger' => '✕', 'warning' => '⚠', 'info' => 'ℹ'];
    $icon  = $icons[$flash['type']] ?? 'ℹ';
    return '<div class="alert alert-' . htmlspecialchars($flash['type']) . ' alert-dismissible fade show" role="alert">
        <strong>' . $icon . '</strong> ' . htmlspecialchars($flash['message']) . '
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>';
}

// ----- SANITIZE -----

function clean(string $value): string {
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

function today(): string {
    return date('Y-m-d');
}

function formatTanggal(string $date): string {
    if (!$date) return '-';
    $bulan = ['','Januari','Februari','Maret','April','Mei','Juni',
              'Juli','Agustus','September','Oktober','November','Desember'];
    [$y, $m, $d] = explode('-', $date);
    return intval($d) . ' ' . $bulan[intval($m)] . ' ' . $y;
}

function statusBadge(string $status): string {
    $map = [
        'pending'     => 'warning',
        'disetujui'   => 'success',
        'ditolak'     => 'danger',
        'menginap'    => 'primary',
        'sudah pergi' => 'secondary',
        'aktif'       => 'success',
        'pindah'      => 'warning',
        'meninggal'   => 'dark',
    ];
    $color = $map[$status] ?? 'secondary';
    return '<span class="badge bg-' . $color . '">' . ucfirst($status) . '</span>';
}
