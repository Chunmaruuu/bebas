<?php

define('DB_HOST',    'localhost');
define('DB_USER',    'root');        
define('DB_PASS',    '');             
define('DB_NAME',    'sistem_rt');
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Jangan tampilkan detail error ke user di production!
            error_log('DB Connection Error: ' . $e->getMessage());
            die('<div style="font-family:sans-serif;padding:20px;background:#fee;border:1px solid #f00;margin:20px">
                <h2>❌ Koneksi Database Gagal</h2>
                <p>Pastikan XAMPP/MySQL sudah berjalan dan database <b>sistem_rt</b> sudah dibuat.</p>
                </div>');
        }
    }
    return $pdo;
}
