<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'Beranda';
$basePath  = '.';
$pdo       = getDB();

$totalPenduduk  = $pdo->query("SELECT COUNT(*) FROM penduduk WHERE status='aktif'")->fetchColumn();
$totalLaporan   = $pdo->query("SELECT COUNT(*) FROM laporan_pindah UNION ALL SELECT COUNT(*) FROM laporan_datang")->fetchAll();
$totalLaporanN  = array_sum(array_column($totalLaporan, 'COUNT(*)'));
$totalTamu      = $pdo->query("SELECT COUNT(*) FROM laporan_tamu WHERE status='menginap'")->fetchColumn();
$pengumumanList = $pdo->query("SELECT p.*, u.nama as penulis FROM pengumuman p LEFT JOIN users u ON p.dibuat_oleh=u.id ORDER BY p.created_at DESC LIMIT 3")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<style>
/* ── HERO ─────────────────────────────────────────────────────── */
.hero-new {
  background:
    linear-gradient(135deg,
      rgba(6,43,20,.92) 0%,
      rgba(13,66,40,.85) 35%,
      rgba(21,94,54,.60) 65%,
      rgba(30,122,71,.40) 100%
    ),
    url('assets/desa.png') center right / cover no-repeat;
  border-radius: 20px;
  padding: 3rem 2.5rem;
  margin-bottom: 1.75rem;
  position: relative;
  overflow: hidden;
}
.hero-new::before {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(
    to right,
    rgba(6,43,20,.55) 0%,
    rgba(6,43,20,.10) 55%,
    transparent 100%
  );
  border-radius: inherit;
}
.hero-new::after {
  content: '';
  position: absolute;
  width: 400px; height: 400px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(110,231,183,.08) 0%, transparent 70%);
  right: -80px; bottom: -100px;
  pointer-events: none;
}

.hero-logo {
  width: 72px; height: 72px;
  border-radius: 18px;
  background: rgba(255,255,255,.12);
  border: 1px solid rgba(255,255,255,.2);
  display: inline-flex; align-items: center; justify-content: center;
  margin-bottom: 1.25rem;
}
.hero-logo i { font-size: 2.2rem; color: #fff; }

.hero-label {
  font-size: .72rem; font-weight: 700; letter-spacing: .15em;
  color: #86efac; text-transform: uppercase; margin-bottom: .5rem;
}
.hero-title {
  font-size: 2rem; font-weight: 800; color: #fff; line-height: 1.2;
  margin-bottom: .75rem;
}
.hero-title span { color: #6ee7b7; }
.hero-desc { font-size: .9rem; color: rgba(255,255,255,.7); margin-bottom: 1.75rem; line-height: 1.6; }

.hero-btn-main {
  background: #fff; color: #0d4228; border: none;
  border-radius: 10px; font-weight: 700; font-size: .9rem;
  padding: .65rem 1.5rem; text-decoration: none;
  display: inline-flex; align-items: center; gap: .4rem;
  transition: all .2s;
}
.hero-btn-main:hover { background: #d1fae5; color: #0d4228; transform: translateY(-1px); }

.hero-btn-sec {
  background: rgba(255,255,255,.1); color: #fff;
  border: 1px solid rgba(255,255,255,.25);
  border-radius: 10px; font-weight: 600; font-size: .9rem;
  padding: .65rem 1.5rem; text-decoration: none;
  display: inline-flex; align-items: center; gap: .4rem;
  transition: all .2s;
}
.hero-btn-sec:hover { background: rgba(255,255,255,.18); color: #fff; }

/* ── STATS ─────────────────────────────────────────────────────── */
.stat-new {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.25rem 1.5rem;
  display: flex; align-items: center; gap: 1rem;
  transition: transform .2s, box-shadow .2s;
}
.stat-new:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,.08); }
.stat-icon {
  width: 50px; height: 50px; border-radius: 13px; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
}
.stat-icon i { font-size: 1.4rem; }
.si-green { background: #dcfce7; } .si-green i { color: #15803d; }
.si-blue  { background: #dbeafe; } .si-blue  i { color: #1d4ed8; }
.si-amber { background: #fef3c7; } .si-amber i { color: #b45309; }
.si-rose  { background: #ffe4e6; } .si-rose  i { color: #be123c; }
.stat-val { font-size: 1.7rem; font-weight: 800; color: #0f172a; line-height: 1; }
.stat-lbl { font-size: .78rem; color: #64748b; font-weight: 500; margin-top: .15rem; }

/* ── VISI MISI ─────────────────────────────────────────────────── */
.vm-section {
  background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%);
  border: 1px solid #bbf7d0;
  border-radius: 18px;
  padding: 2rem;
  margin-bottom: 1.75rem;
}
.vm-header {
  display: flex; align-items: center; gap: .75rem; margin-bottom: 1.5rem;
}
.vm-header-icon {
  width: 44px; height: 44px; border-radius: 12px;
  background: linear-gradient(135deg, #15803d, #22c55e);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.vm-header-icon i { font-size: 1.25rem; color: #fff; }
.vm-header-text h5 { font-size: 1.05rem; font-weight: 800; color: #0f172a; margin: 0; }
.vm-header-text p  { font-size: .78rem; color: #64748b; margin: 0; }

.vm-box {
  background: #fff;
  border: 1px solid #dcfce7;
  border-radius: 14px;
  padding: 1.5rem;
  height: 100%;
}
.vm-box-title {
  font-size: .72rem; font-weight: 700; letter-spacing: .12em;
  text-transform: uppercase; color: #15803d; margin-bottom: .8rem;
  display: flex; align-items: center; gap: .4rem;
}
.vm-box-content { font-size: .9rem; color: #1e293b; line-height: 1.65; font-style: italic; font-weight: 500; }
.vm-misi-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: .6rem; }
.vm-misi-list li { display: flex; align-items: flex-start; gap: .55rem; font-size: .85rem; color: #1e293b; line-height: 1.55; }
.vm-misi-num { width: 22px; height: 22px; border-radius: 50%; background: #dcfce7; color: #15803d;
  font-size: .7rem; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; }

/* ── PENGURUS ─────────────────────────────────────────────────── */
.pengurus-section {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 18px;
  padding: 1.75rem 2rem;
  margin-bottom: 1.75rem;
}
.pengurus-card {
  text-align: center;
  padding: 1.25rem .75rem;
  border-radius: 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  transition: all .2s;
}
.pengurus-card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,.07); border-color: #bbf7d0; }
.pengurus-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  background: linear-gradient(135deg, #15803d, #22c55e);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 1rem;
  box-shadow: 0 4px 14px rgba(21,128,61,.25);
}
.pengurus-avatar i { font-size: 2rem; color: #fff; }
.pengurus-name { font-size: .92rem; font-weight: 700; color: #0f172a; margin-bottom: .2rem; }
.pengurus-role { font-size: .75rem; color: #15803d; font-weight: 600; background: #dcfce7; border-radius: 20px; padding: .15rem .6rem; display: inline-block; }
.pengurus-period { font-size: .72rem; color: #94a3b8; margin-top: .4rem; }
.pengurus-wa-link {
  display: inline-flex;
  align-items: center;
  gap: .3rem;
  color: #15803d;
  font-weight: 600;
  font-size: .75rem;
  text-decoration: none;
  background: #dcfce7;
  border: 1px solid #bbf7d0;
  border-radius: 20px;
  padding: .2rem .65rem;
  transition: background .15s, box-shadow .15s;
}
.pengurus-wa-link:hover {
  background: #bbf7d0;
  color: #14532d;
  box-shadow: 0 2px 8px rgba(21,128,61,.15);
  text-decoration: none;
}

/* ── LAYANAN MENU ─────────────────────────────────────────────── */
.service-card {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 1.25rem;
  text-decoration: none;
  display: block;
  transition: all .22s;
  height: 100%;
}
.service-card:hover {
  border-color: #86efac;
  box-shadow: 0 6px 20px rgba(21,128,61,.1);
  transform: translateY(-2px);
}
.service-icon { width: 46px; height: 46px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: .85rem; }
.service-icon i { font-size: 1.3rem; }
.service-title { font-size: .88rem; font-weight: 700; color: #0f172a; margin-bottom: .2rem; }
.service-desc  { font-size: .78rem; color: #64748b; line-height: 1.45; }

/* ── PENGUMUMAN ──────────────────────────────────────────────── */
.notif-item {
  padding: .85rem 1.25rem;
  border-bottom: 1px solid #f1f5f9;
  transition: background .15s;
}
.notif-item:last-child { border-bottom: none; }
.notif-item:hover { background: #f8fafc; }
.notif-title { font-size: .85rem; font-weight: 700; color: #0f172a; margin-bottom: .2rem; }
.notif-snippet { font-size: .8rem; color: #64748b; line-height: 1.4; }
.notif-meta { font-size: .72rem; color: #94a3b8; margin-top: .3rem; }

.section-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 1.25rem;
}
.section-header h5 { font-size: .95rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: .45rem; }
.badge-dot { width: 8px; height: 8px; border-radius: 50%; background: #22c55e; display: inline-block; }
</style>

<div class="container py-4" style="max-width:1200px;position:relative;z-index:1">
  <?= flashHtml() ?>

  <!-- ══ HERO ══════════════════════════════════════════════════════ -->
  <div class="hero-new mb-4">
    <div class="row align-items-center">
      <div class="col-lg-7" style="position:relative;z-index:1">
        <div class="hero-logo"><i class="bi bi-building-fill-check"></i></div>
        <div class="hero-label">✦ Portal Administrasi Warga ✦</div>
        <h1 class="hero-title">
          Sistem Administrasi<br>
          <span>RT 001 / RW 003</span>
        </h1>
        <p class="hero-desc">
          Layanan administrasi kependudukan digital untuk warga<br>
          Kelurahan Maguwoharjo, Kecamatan Depok, Kabupaten Sleman,<br>
          D.I. Yogyakarta cepat, mudah, dan terpercaya.
        </p>
        <div class="d-flex gap-2 flex-wrap">
          <?php if (!isLoggedIn()): ?>
          <a href="auth/login.php" class="hero-btn-main">
            <i class="bi bi-box-arrow-in-right"></i> Masuk Sekarang
          </a>
          <a href="auth/register.php" class="hero-btn-sec">
            <i class="bi bi-person-plus"></i> Daftar Warga
          </a>
          <?php else: ?>
          <?php if (!isAdmin()): ?>
          <a href="pages/jadwal_rt.php" class="hero-btn-sec">
            <i class="bi bi-calendar2-check"></i> Jadwal Bertemu RT
          </a>
          <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>

  <!-- ══ STATISTIK ════════════════════════════════════════════════ -->
  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="stat-new">
        <div class="stat-icon si-green"><i class="bi bi-people-fill"></i></div>
        <div>
          <div class="stat-val"><?= number_format($totalPenduduk) ?></div>
          <div class="stat-lbl">Penduduk Aktif</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-new">
        <div class="stat-icon si-blue"><i class="bi bi-file-earmark-check-fill"></i></div>
        <div>
          <div class="stat-val"><?= number_format($totalLaporanN) ?></div>
          <div class="stat-lbl">Total Laporan</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-new">
        <div class="stat-icon si-amber"><i class="bi bi-person-plus-fill"></i></div>
        <div>
          <div class="stat-val"><?= number_format($totalTamu) ?></div>
          <div class="stat-lbl">Tamu Menginap</div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-new">
        <div class="stat-icon si-rose"><i class="bi bi-award-fill"></i></div>
        <div>
          <div class="stat-val" style="font-size:1.25rem;margin-top:.15rem">001 / 003</div>
          <div class="stat-lbl">RT / RW</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ VISI & MISI ══════════════════════════════════════════════ -->
  <div class="vm-section">
    <div class="vm-header">
      <div class="vm-header-icon"><i class="bi bi-bullseye"></i></div>
      <div class="vm-header-text">
        <h5>Visi &amp; Misi RT 001 / RW 003</h5>
        <p>Periode 2023 — 2026 · Kel. Maguwoharjo, Kab. Sleman</p>
      </div>
    </div>
    <div class="row g-3">
      <div class="col-md-5">
        <div class="vm-box">
          <div class="vm-box-title"><i class="bi bi-eye-fill"></i> Visi</div>
          <div class="vm-box-content">
            "Mewujudkan lingkungan RT 001 / RW 003 yang aman, bersih, harmonis,
            dan sejahtera melalui pelayanan administrasi yang transparan,
            partisipatif, dan berbasis teknologi."
          </div>
        </div>
      </div>
      <div class="col-md-7">
        <div class="vm-box">
          <div class="vm-box-title"><i class="bi bi-list-check"></i> Misi</div>
          <ul class="vm-misi-list">
            <li><span class="vm-misi-num">1</span> Meningkatkan pelayanan administrasi kependudukan yang cepat dan akurat bagi seluruh warga.</li>
            <li><span class="vm-misi-num">2</span> Menjaga keamanan dan ketertiban lingkungan dengan sistem ronda dan pelaporan terpadu.</li>
            <li><span class="vm-misi-num">3</span> Mendorong partisipasi aktif warga dalam kegiatan gotong royong dan sosial kemasyarakatan.</li>
            <li><span class="vm-misi-num">4</span> Mengelola keuangan RT secara transparan, akuntabel, dan bertanggung jawab kepada warga.</li>
            <li><span class="vm-misi-num">5</span> Memanfaatkan teknologi digital untuk mempermudah komunikasi dan layanan kepada warga.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ PENGURUS RT/RW ════════════════════════════════════════════ -->
  <div class="pengurus-section">
    <div class="section-header mb-3">
      <h5 style="font-size:.95rem;font-weight:800;color:#0f172a;margin:0;display:flex;align-items:center;gap:.45rem">
        <i class="bi bi-people-fill text-success"></i> Pengurus RT 001 / RW 003
        <span style="font-size:.72rem;font-weight:500;color:#64748b;margin-left:.3rem">Periode 2023–2026</span>
      </h5>
    </div>
    <div class="row g-3 justify-content-center">
      <div class="col-6 col-md-3">
        <div class="pengurus-card">
          <div class="pengurus-avatar"><i class="bi bi-person-fill"></i></div>
          <div class="pengurus-name">Bpk. Supriyanto</div>
          <span class="pengurus-role">Ketua RT 001</span>
          <div class="pengurus-period">
            <a href="https://wa.me/6285702045509" target="_blank" class="pengurus-wa-link">
              <i class="bi bi-whatsapp"></i> 0857-0204-5509
            </a>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="pengurus-card">
          <div class="pengurus-avatar"><i class="bi bi-person-fill"></i></div>
          <div class="pengurus-name">Bpk. Wahyu Santoso</div>
          <span class="pengurus-role">Sekretaris RT</span>
          <div class="pengurus-period">
            <a href="https://wa.me/6282223238087" target="_blank" class="pengurus-wa-link">
              <i class="bi bi-whatsapp"></i> 0822-2323-8087
            </a>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="pengurus-card">
          <div class="pengurus-avatar"><i class="bi bi-person-fill"></i></div>
          <div class="pengurus-name">Bpk. Haryono</div>
          <span class="pengurus-role">Bendahara RT</span>
          <div class="pengurus-period">
            <a href="https://wa.me/6281327752007" target="_blank" class="pengurus-wa-link">
              <i class="bi bi-whatsapp"></i> 0813-2775-2007
            </a>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="pengurus-card">
          <div class="pengurus-avatar"><i class="bi bi-person-fill"></i></div>
          <div class="pengurus-name">Bpk. Eko Budi</div>
          <span class="pengurus-role">Ketua RW 003</span>
          <div class="pengurus-period">
            <a href="https://wa.me/6281545678902" target="_blank" class="pengurus-wa-link">
              <i class="bi bi-whatsapp"></i> 0815-4567-8902
            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="mt-3 p-3 rounded-3" style="background:#fffbeb;border:1px solid #fde68a;font-size:.8rem;color:#78350f">
      <i class="bi bi-info-circle me-1"></i>
      <strong>Jam Layanan Pengurus:</strong> Senin–Jumat pukul 18.00–21.00 WIB · Sabtu 09.00–12.00 WIB ·
      Di luar jam kerja, hubungi via WhatsApp.
    </div>
  </div>

  <!-- ══ LAYANAN + PENGUMUMAN ══════════════════════════════════════ -->
  <div class="row g-4">
    <!-- LAYANAN -->
    <div class="col-md-7">
      <div style="background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:1.75rem">
        <div class="section-header">
          <h5><i class="bi bi-grid-3x3-gap-fill text-success"></i> Layanan Warga</h5>
        </div>
        <div class="row g-3">
          <?php
          $menus = [
            ['icon'=>'bi-arrow-right-square-fill','bg'=>'#dcfce7','ic'=>'#15803d',
             'judul'=>'Lapor Pindah','desc'=>'Daftarkan kepindahan ke wilayah lain','link'=>'pages/lapor_pindah.php'],
            ['icon'=>'bi-arrow-left-square-fill','bg'=>'#dbeafe','ic'=>'#1d4ed8',
             'judul'=>'Lapor Datang','desc'=>'Daftarkan kedatangan warga baru','link'=>'pages/lapor_datang.php'],
            ['icon'=>'bi-person-plus-fill','bg'=>'#fef3c7','ic'=>'#b45309',
             'judul'=>'Lapor Tamu','desc'=>'Daftarkan tamu yang menginap','link'=>'pages/lapor_tamu.php'],
            ['icon'=>'bi-megaphone-fill','bg'=>'#ffe4e6','ic'=>'#be123c',
             'judul'=>'Pengumuman','desc'=>'Info & pengumuman dari RT/RW','link'=>'pages/pengumuman.php'],
          ];
          foreach ($menus as $m): ?>
          <div class="col-6">
            <a href="<?= isLoggedIn() ? $m['link'] : 'auth/login.php' ?>" class="service-card">
              <div class="service-icon" style="background:<?= $m['bg'] ?>">
                <i class="bi <?= $m['icon'] ?>" style="color:<?= $m['ic'] ?>"></i>
              </div>
              <div class="service-title"><?= $m['judul'] ?></div>
              <div class="service-desc"><?= $m['desc'] ?></div>
            </a>
          </div>
          <?php endforeach; ?>
        </div>

        <?php if (isLoggedIn() && !isAdmin()): ?>
        <div class="mt-3 pt-3 border-top">
          <div class="row g-2">
            <div class="col-6">
              <a href="pages/anggota_keluarga.php"
                 style="display:flex;align-items:center;gap:.5rem;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:.7rem 1rem;text-decoration:none;color:#374151;font-size:.82rem;font-weight:600;transition:all .2s"
                 onmouseover="this.style.borderColor='#86efac';this.style.color='#15803d'"
                 onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#374151'">
                <i class="bi bi-people text-success"></i> Data Keluarga
              </a>
            </div>
            <div class="col-6">
              <a href="pages/profil.php"
                 style="display:flex;align-items:center;gap:.5rem;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:.7rem 1rem;text-decoration:none;color:#374151;font-size:.82rem;font-weight:600;transition:all .2s"
                 onmouseover="this.style.borderColor='#86efac';this.style.color='#15803d'"
                 onmouseout="this.style.borderColor='#e2e8f0';this.style.color='#374151'">
                <i class="bi bi-person-circle text-success"></i> Profil Saya
              </a>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- PENGUMUMAN -->
    <div class="col-md-5">
      <div style="background:#fff;border:1px solid #e2e8f0;border-radius:18px;overflow:hidden;height:100%">
        <div style="padding:1.25rem 1.5rem;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between">
          <h5 style="font-size:.95rem;font-weight:800;color:#0f172a;margin:0;display:flex;align-items:center;gap:.45rem">
            <i class="bi bi-megaphone-fill text-warning"></i> Pengumuman Terbaru
          </h5>
          <a href="pages/pengumuman.php"
             style="font-size:.77rem;color:#15803d;font-weight:600;text-decoration:none;background:#f0fdf4;padding:.25rem .7rem;border-radius:20px">
            Lihat Semua
          </a>
        </div>
        <?php if (empty($pengumumanList)): ?>
        <div class="text-center py-5">
          <i class="bi bi-bell-slash" style="font-size:2.5rem;color:#d1d5db"></i>
          <p style="font-size:.82rem;color:#94a3b8;margin-top:.5rem">Belum ada pengumuman</p>
        </div>
        <?php endif; ?>
        <?php
        $badgeMap = ['umum'=>['bg'=>'#e2e8f0','c'=>'#374151'],'keamanan'=>['bg'=>'#fee2e2','c'=>'#b91c1c'],
                     'kesehatan'=>['bg'=>'#dcfce7','c'=>'#15803d'],'lingkungan'=>['bg'=>'#d1fae5','c'=>'#065f46'],
                     'lainnya'=>['bg'=>'#e0f2fe','c'=>'#0369a1']];
        foreach ($pengumumanList as $p):
          $bm = $badgeMap[$p['kategori']] ?? $badgeMap['lainnya'];
        ?>
        <div class="notif-item">
          <div style="display:flex;gap:.5rem;align-items:flex-start">
            <span style="font-size:.7rem;font-weight:700;padding:.18rem .55rem;border-radius:20px;white-space:nowrap;background:<?= $bm['bg'] ?>;color:<?= $bm['c'] ?>">
              <?= ucfirst($p['kategori']) ?>
            </span>
            <div style="flex:1;min-width:0">
              <div class="notif-title"><?= clean($p['judul']) ?></div>
              <div class="notif-snippet"><?= mb_substr(clean($p['isi']),0,75) ?>…</div>
              <div class="notif-meta">
                <i class="bi bi-person-circle"></i> <?= clean($p['penulis']??'Admin') ?>
                &bull; <?= formatTanggal(date('Y-m-d',strtotime($p['created_at']))) ?>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- ══ INFO KONTAK ═══════════════════════════════════════════════ -->
  <div class="row g-3 mt-2">
    <div class="col-md-6">
      <div style="background:linear-gradient(135deg,#ecfdf5,#f0fdf4);border:1px solid #bbf7d0;border-radius:14px;padding:1.25rem 1.5rem">
        <h6 style="font-size:.85rem;font-weight:800;color:#0f172a;margin-bottom:.8rem">
          <i class="bi bi-geo-alt-fill text-success me-2"></i>Lokasi RT 001 / RW 003
        </h6>
        <p style="font-size:.82rem;color:#374151;margin-bottom:.4rem;line-height:1.6">
          Kelurahan Maguwoharjo, Kecamatan Depok,<br>
          Kabupaten Sleman, D.I. Yogyakarta 55282
        </p>
        <a href="https://maps.app.goo.gl/K3QLkvyotSDqrexv9" target="_blank"
           style="font-size:.78rem;color:#15803d;font-weight:600;text-decoration:none">
          <i class="bi bi-map me-1"></i> Buka di Google Maps
        </a>
      </div>
    </div>
    <div class="col-md-6">
      <div style="background:linear-gradient(135deg,#f0fdf4,#ecfdf5);border:1px solid #bbf7d0;border-radius:14px;padding:1.25rem 1.5rem">
        <h6 style="font-size:.85rem;font-weight:800;color:#0f172a;margin-bottom:.8rem">
          <i class="bi bi-telephone-fill text-success me-2"></i>Kontak Pengurus
        </h6>
        <div style="display:flex;flex-direction:column;gap:.35rem">
          <div style="font-size:.82rem;color:#374151;display:flex;align-items:center;gap:.4rem">
            <i class="bi bi-whatsapp text-success"></i>
            <span>Ketua RT: <a href="https://wa.me/6286702045509" target="_blank" style="color:#15803d;font-weight:700;text-decoration:none">0867-0204-5509</a></span>
          </div>
          <div style="font-size:.82rem;color:#374151;display:flex;align-items:center;gap:.4rem">
            <i class="bi bi-whatsapp text-success"></i>
            <span>Ketua RW: <a href="https://wa.me/6281327752007" target="_blank" style="color:#15803d;font-weight:700;text-decoration:none">0813-2775-2007</a></span>
          </div>
          <div style="font-size:.78rem;color:#64748b;margin-top:.2rem">
            <i class="bi bi-clock me-1"></i> Senin–Jumat 18.00–21.00 · Sabtu 09.00–12.00
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<?php include __DIR__ . '/includes/footer.php'; ?>