-- ============================================================
--  SISTEM ADMINISTRASI RT 001 / RW 003
--  Database: sistem_rt  |  Versi 4.1 (Final Combined)
-- ============================================================

CREATE DATABASE IF NOT EXISTS sistem_rt
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sistem_rt;

-- ------------------------------------------------------------
-- TABEL: users
-- ------------------------------------------------------------
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    nama            VARCHAR(100) NOT NULL,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password        VARCHAR(255) NOT NULL,
    role            ENUM('admin','warga','pending') NOT NULL DEFAULT 'pending',
    no_hp           VARCHAR(20),
    email           VARCHAR(100),
    foto_profil     VARCHAR(255) DEFAULT NULL, -- [Patch v4.1]
    status_akun     ENUM('aktif','nonaktif','menunggu') DEFAULT 'menunggu',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: kartu_keluarga
-- ------------------------------------------------------------
CREATE TABLE kartu_keluarga (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    no_kk           VARCHAR(16) NOT NULL UNIQUE,
    nama_kepala     VARCHAR(100) NOT NULL,
    alamat          TEXT NOT NULL,
    rt              VARCHAR(5)   DEFAULT '001',
    rw              VARCHAR(5)   DEFAULT '003',
    kelurahan       VARCHAR(100) DEFAULT 'Maguwoharjo',
    kecamatan       VARCHAR(100) DEFAULT 'Depok',
    kabupaten       VARCHAR(100) DEFAULT 'Sleman',
    provinsi        VARCHAR(100) DEFAULT 'D.I. Yogyakarta',
    kode_pos        VARCHAR(10),
    jumlah_anggota  INT DEFAULT 1,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: penduduk
-- ------------------------------------------------------------
CREATE TABLE penduduk (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    nik             VARCHAR(16)  NOT NULL UNIQUE,
    no_kk           VARCHAR(16),
    nama            VARCHAR(100) NOT NULL,
    jenis_kelamin   ENUM('L','P') NOT NULL,
    tempat_lahir    VARCHAR(50),
    tanggal_lahir   DATE,
    agama           ENUM('Islam','Kristen','Katolik','Hindu','Buddha','Konghucu') DEFAULT 'Islam',
    status_kawin    ENUM('Belum Kawin','Kawin','Cerai Hidup','Cerai Mati') DEFAULT 'Belum Kawin',
    status_hubungan ENUM('Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya') DEFAULT 'Kepala Keluarga',
    pekerjaan       VARCHAR(50),
    pendidikan      ENUM('Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3') DEFAULT 'SMA/SMK',
    alamat          TEXT,
    no_rt           VARCHAR(5)   DEFAULT '001',
    no_rw           VARCHAR(5)   DEFAULT '003',
    kode_pos        VARCHAR(10),
    kelurahan       VARCHAR(100) DEFAULT 'Maguwoharjo',
    kecamatan       VARCHAR(100) DEFAULT 'Depok',
    kabupaten       VARCHAR(100) DEFAULT 'Sleman',
    provinsi        VARCHAR(100) DEFAULT 'D.I. Yogyakarta',
    status          ENUM('aktif','pindah','meninggal') DEFAULT 'aktif',
    user_id         INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: anggota_keluarga
-- ------------------------------------------------------------
CREATE TABLE anggota_keluarga (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    no_kk           VARCHAR(16) NOT NULL,
    user_id_kepala  INT NOT NULL,
    nik             VARCHAR(16) NOT NULL UNIQUE,
    nama            VARCHAR(100) NOT NULL,
    jenis_kelamin   ENUM('L','P') NOT NULL,
    tempat_lahir    VARCHAR(50),
    tanggal_lahir   DATE,
    agama           ENUM('Islam','Kristen','Katolik','Hindu','Buddha','Konghucu') DEFAULT 'Islam',
    status_kawin    ENUM('Belum Kawin','Kawin','Cerai Hidup','Cerai Mati') DEFAULT 'Belum Kawin',
    status_hubungan ENUM('Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya') DEFAULT 'Kepala Keluarga',
    pekerjaan       VARCHAR(50),
    pendidikan      ENUM('Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3') DEFAULT 'SMA/SMK',
    status_data     ENUM('aktif','nonaktif') DEFAULT 'aktif',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id_kepala) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: registrasi_warga
-- ------------------------------------------------------------
CREATE TABLE registrasi_warga (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL,
    password        VARCHAR(255) NOT NULL,
    no_hp           VARCHAR(20),
    email           VARCHAR(100),
    nik             VARCHAR(16)  NOT NULL,
    nama            VARCHAR(100) NOT NULL,
    jenis_kelamin   ENUM('L','P') NOT NULL,
    tempat_lahir    VARCHAR(50),
    tanggal_lahir   DATE,
    agama           ENUM('Islam','Kristen','Katolik','Hindu','Buddha','Konghucu') DEFAULT 'Islam',
    status_kawin    ENUM('Belum Kawin','Kawin','Cerai Hidup','Cerai Mati') DEFAULT 'Belum Kawin',
    status_hubungan ENUM('Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya') DEFAULT 'Kepala Keluarga',
    pekerjaan       VARCHAR(50),
    pendidikan      ENUM('Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3') DEFAULT 'SMA/SMK',
    no_kk           VARCHAR(16)  NOT NULL,
    nama_kepala_kk  VARCHAR(100),
    jumlah_keluarga INT DEFAULT 1,
    alamat          TEXT NOT NULL,
    no_rt           VARCHAR(5)   DEFAULT '001',
    no_rw           VARCHAR(5)   DEFAULT '003',
    kode_pos        VARCHAR(10),
    kelurahan       VARCHAR(100) DEFAULT 'Maguwoharjo',
    kecamatan       VARCHAR(100) DEFAULT 'Depok',
    kabupaten       VARCHAR(100) DEFAULT 'Sleman',
    provinsi        VARCHAR(100) DEFAULT 'D.I. Yogyakarta',
    foto_ktp        VARCHAR(255),
    foto_kk         VARCHAR(255),
    status          ENUM('menunggu','disetujui','ditolak') DEFAULT 'menunggu',
    catatan_admin   TEXT,
    diproses_oleh   INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (diproses_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: edit_profil_request
-- ------------------------------------------------------------
CREATE TABLE edit_profil_request (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    tipe_request    ENUM('akun','kependudukan') NOT NULL DEFAULT 'akun', -- [Patch v4.1]
    field_diubah    TEXT NOT NULL,
    data_lama       TEXT NOT NULL,
    data_baru       TEXT NOT NULL,
    status          ENUM('menunggu','disetujui','ditolak') DEFAULT 'menunggu',
    catatan_admin   TEXT,
    diproses_oleh   INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)       REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (diproses_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: laporan_pindah
-- ------------------------------------------------------------
CREATE TABLE laporan_pindah (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    penduduk_id     INT NOT NULL,
    tanggal_pindah  DATE NOT NULL,
    alamat_tujuan   TEXT NOT NULL,
    rt_tujuan       VARCHAR(5),
    rw_tujuan       VARCHAR(5),
    kode_pos_tujuan VARCHAR(10),
    kota_tujuan     VARCHAR(100),
    alasan          TEXT,
    status          ENUM('pending','disetujui','ditolak') DEFAULT 'pending',
    catatan_admin   TEXT,
    edit_count      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    dibuat_oleh     INT,
    diproses_oleh   INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (penduduk_id)   REFERENCES penduduk(id) ON DELETE CASCADE,
    FOREIGN KEY (dibuat_oleh)   REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (diproses_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: laporan_datang
-- ------------------------------------------------------------
CREATE TABLE laporan_datang (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    nik             VARCHAR(16) NOT NULL,
    no_kk           VARCHAR(16),
    nama            VARCHAR(100) NOT NULL,
    jenis_kelamin   ENUM('L','P') NOT NULL,
    tempat_lahir    VARCHAR(50),
    tanggal_lahir   DATE,
    alamat_asal     TEXT NOT NULL,
    kota_asal       VARCHAR(100),
    tanggal_datang  DATE NOT NULL,
    alasan          TEXT,
    status          ENUM('pending','disetujui','ditolak') DEFAULT 'pending',
    catatan_admin   TEXT,
    edit_count      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    dibuat_oleh     INT,
    diproses_oleh   INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (dibuat_oleh)   REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (diproses_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: laporan_tamu
-- ------------------------------------------------------------
CREATE TABLE laporan_tamu (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    penduduk_id     INT NOT NULL,
    nama_tamu       VARCHAR(100) NOT NULL,
    nik_tamu        VARCHAR(16),
    alamat_tamu     TEXT,
    kota_tamu       VARCHAR(100),
    hubungan        VARCHAR(50),
    tanggal_datang  DATE NOT NULL,
    tanggal_pergi   DATE,
    keperluan       TEXT,
    status          ENUM('menginap','sudah pergi') DEFAULT 'menginap',
    edit_count      TINYINT UNSIGNED NOT NULL DEFAULT 0,
    dibuat_oleh     INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (penduduk_id) REFERENCES penduduk(id) ON DELETE CASCADE,
    FOREIGN KEY (dibuat_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: jadwal_bertemu_rt
-- ------------------------------------------------------------
CREATE TABLE jadwal_bertemu_rt (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    keperluan       VARCHAR(255) NOT NULL,
    catatan         TEXT,
    tanggal_pilihan DATE NOT NULL,
    jam_pilihan     TIME NOT NULL,
    status          ENUM('menunggu','dikonfirmasi','ditolak','selesai') DEFAULT 'menunggu',
    catatan_admin   TEXT,
    diproses_oleh   INT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)       REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (diproses_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TABEL: pengumuman
-- ------------------------------------------------------------
CREATE TABLE pengumuman (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    judul       VARCHAR(200) NOT NULL,
    isi         TEXT NOT NULL,
    -- [Patch Keuangan]: Menggunakan sosial (pengganti umum) & laporan_keuangan
    kategori    ENUM('sosial','keamanan','kesehatan','lingkungan','laporan_keuangan','lainnya') DEFAULT 'sosial',
    file_pdf    VARCHAR(255) DEFAULT NULL, -- [Patch Keuangan]
    dibuat_oleh INT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dibuat_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- DATA AWAL (SEED) — password semua: 'password'
-- ============================================================

INSERT INTO users (nama, username, password, role, no_hp, email, status_akun) VALUES
('Pak RT Slamet',   'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '081234567890', 'admin@rt001.id', 'aktif'),
('Budi Santoso',    'budi',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'warga', '081298765432', 'budi@gmail.com', 'aktif'),
('Siti Rahayu',     'siti',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'warga', '082198765432', 'siti@gmail.com', 'aktif'),
('Ahmad Fauzi',     'ahmad', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'warga', '085612345678', 'ahmad@gmail.com','aktif'),
('Dewi Lestari',    'dewi',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'warga', '087812345678', 'dewi@gmail.com', 'aktif');

INSERT INTO kartu_keluarga (no_kk, nama_kepala, alamat, rt, rw, kode_pos, jumlah_anggota) VALUES
('3471010000000001','Budi Santoso',     'Jl. Melati No. 1',       '001','003','55282',2),
('3471010000000002','Ahmad Fauzi',      'Jl. Mawar No. 5',        '001','003','55282',1),
('3471010000000003','Dewi Lestari',     'Jl. Kenanga No. 3',      '001','003','55282',1),
('3471010000000004','Hendra Kurniawan', 'Jl. Anggrek No. 7',      '001','003','55282',3),
('3471010000000005','Suparman',         'Jl. Bougenville No. 6',  '001','003','55282',4);

INSERT INTO penduduk (nik,no_kk,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,agama,status_kawin,status_hubungan,pekerjaan,pendidikan,alamat,no_rt,no_rw,kode_pos,user_id) VALUES
('3471010101800001','3471010000000001','Budi Santoso',    'L','Yogyakarta','1980-01-01','Islam','Kawin',       'Kepala Keluarga','Pedagang',        'S1',     'Jl. Melati No. 1',       '001','003','55282',2),
('3471010101850002','3471010000000001','Siti Rahayu',     'P','Solo',      '1985-03-15','Islam','Kawin',       'Istri',          'Ibu Rumah Tangga','SMA/SMK','Jl. Melati No. 1',       '001','003','55282',3),
('3471010101900003','3471010000000002','Ahmad Fauzi',     'L','Bantul',    '1990-07-20','Islam','Belum Kawin', 'Kepala Keluarga','Mahasiswa',       'S1',     'Jl. Mawar No. 5',        '001','003','55282',4),
('3471010101920004','3471010000000003','Dewi Lestari',    'P','Yogyakarta','1992-11-30','Islam','Belum Kawin', 'Kepala Keluarga','Karyawan Swasta', 'S1',     'Jl. Kenanga No. 3',      '001','003','55282',5),
('3471010101750005','3471010000000004','Hendra Kurniawan','L','Semarang',  '1975-05-10','Kristen','Kawin',     'Kepala Keluarga','Wiraswasta',      'S1',     'Jl. Anggrek No. 7',      '001','003','55282',NULL),
('3471010101830006','3471010000000001','Sri Wahyuni',     'P','Klaten',    '1983-09-25','Islam','Kawin',       'Istri',          'Guru',            'S1',     'Jl. Dahlia No. 2',       '001','003','55282',NULL),
('3471010101950007','3471010000000002','Rizki Pratama',   'L','Yogyakarta','1995-04-12','Islam','Belum Kawin', 'Anak',           'Karyawan Swasta', 'SMA/SMK','Jl. Tulip No. 9',        '001','003','55282',NULL),
('3471010101880008','3471010000000004','Nurul Hidayah',   'P','Gunungkidul','1988-12-03','Islam','Kawin',      'Istri',          'Bidan',           'D1/D2/D3','Jl. Flamboyan No. 4',  '001','003','55282',NULL),
('3471010101700009','3471010000000005','Suparman',        'L','Yogyakarta','1970-08-17','Islam','Kawin',       'Kepala Keluarga','PNS',             'S1',     'Jl. Bougenville No. 6',  '001','003','55282',NULL),
('3471010101780010','3471010000000005','Rina Susanti',    'P','Magelang',  '1978-02-28','Katolik','Kawin',     'Istri',          'Dokter',          'S2/S3',  'Jl. Cempaka No. 8',      '001','003','55282',NULL);

INSERT INTO laporan_pindah (penduduk_id,tanggal_pindah,alamat_tujuan,kota_tujuan,alasan,status,dibuat_oleh) VALUES
(3,'2025-06-01','Jl. Kaliurang KM 10 No. 5','Sleman','Pindah kerja ke daerah baru','pending',4);

INSERT INTO laporan_datang (nik,no_kk,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,alamat_asal,kota_asal,tanggal_datang,alasan,status,dibuat_oleh) VALUES
('3471020101960011','3471020000000011','Fajar Nugroho','L','Purworejo','1996-03-22','Jl. Merdeka No. 10','Purworejo','2025-05-15','Menikah dan menetap di sini','disetujui',1);

INSERT INTO laporan_tamu (penduduk_id,nama_tamu,nik_tamu,alamat_tamu,kota_tamu,hubungan,tanggal_datang,keperluan,status,dibuat_oleh) VALUES
(1,'Joko Santoso','3471030101700001','Jl. Solo No. 1','Solo','Saudara','2025-06-10','Liburan keluarga','menginap',2),
(2,'Ratna Dewi','3471030101870002','Jl. Pahlawan No. 5','Semarang','Teman','2025-06-12','Menghadiri pernikahan','sudah pergi',3);

INSERT INTO pengumuman (judul,isi,kategori,dibuat_oleh) VALUES
('Kerja Bakti Minggu Depan','Warga RT 001/003 dihimbau untuk mengikuti kerja bakti pada hari Minggu, 22 Juni 2025 pukul 07.00 WIB di area lingkungan RT. Harap membawa peralatan kebersihan masing-masing.','lingkungan',1),
('Jadwal Ronda Bulan Juni','Berikut jadwal ronda bulan Juni 2025. Setiap warga yang mendapat giliran harap hadir tepat waktu. Hubungi Pak RT jika ada halangan.','keamanan',1),
('Posyandu Balita','Posyandu rutin akan dilaksanakan pada tanggal 25 Juni 2025 di Balai RT. Ibu-ibu yang memiliki balita harap membawa buku KIA.','kesehatan',1);

-- Selesai. Database siap digunakan dengan versi v4.1 lengkap.