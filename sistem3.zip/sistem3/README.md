# 📋 PANDUAN INSTALASI — Sistem RT 001/RW 003

## Persyaratan
- XAMPP (PHP 8.0+ dan MySQL 5.7+)
- Browser modern (Chrome, Firefox, Edge)

---

## Langkah Instalasi

### 1. Copy Folder Project
Salin folder `sistem_rt` ke dalam:
```
C:\xampp\htdocs\sistem_rt\
```

### 2. Import Database
1. Buka browser, akses: `http://localhost/phpmyadmin`
2. Klik tab **"Import"**
3. Pilih file `database.sql` dari folder project ini
4. Klik **"Go"** / Impor
5. Pastikan database `sistem_rt` dan semua tabel berhasil dibuat

### 3. Konfigurasi Koneksi
Buka file `config/db.php`, sesuaikan jika perlu:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');   // username MySQL kamu
define('DB_PASS', '');       // password MySQL (default XAMPP: kosong)
define('DB_NAME', 'sistem_rt');
```

### 4. Jalankan Aplikasi
Buka browser, akses:
```
http://localhost/sistem_rt/
```

---

## Akun Demo

| Role  | Username | Password |
|-------|----------|----------|
| Admin | `admin`  | `password` |
| Warga | `budi`   | `password` |
| Warga | `siti`   | `password` |

> ⚠️ Ganti password di halaman **Profil** setelah pertama kali masuk!

---

## Struktur Folder

```
sistem_rt/
├── index.php               ← Landing page utama
├── database.sql            ← Script database (import ke phpMyAdmin)
├── README.md               ← File ini
│
├── auth/
│   ├── login.php           ← Halaman login
│   └── logout.php          ← Proses logout
│
├── config/
│   ├── db.php              ← Koneksi database (PDO)
│   └── helpers.php         ← Fungsi utilitas (auth, flash, format)
│
├── includes/
│   ├── header.php          ← Navbar + head HTML
│   └── footer.php          ← Footer + script JS
│
├── pages/                  ← Halaman untuk warga
│   ├── lapor_pindah.php    ← Form laporan pindah
│   ├── lapor_datang.php    ← Form laporan datang
│   ├── lapor_tamu.php      ← Form laporan tamu menginap
│   ├── pengumuman.php      ← Daftar pengumuman
│   └── profil.php          ← Profil & ganti password
│
└── admin/                  ← Halaman khusus admin
    ├── dashboard.php       ← Dashboard + grafik Chart.js
    ├── sidebar.php         ← Navigasi sidebar
    ├── penduduk.php        ← CRUD data penduduk
    ├── laporan.php         ← Kelola & approve laporan
    ├── tamu.php            ← Monitor tamu menginap
    ├── pengumuman.php      ← CRUD pengumuman
    └── users.php           ← Kelola akun user
```

---

## Fitur Lengkap

### 👤 Warga (role: warga)
- [x] Login / Logout
- [x] Lihat pengumuman RT
- [x] Lapor pindah (dengan riwayat)
- [x] Lapor datang warga baru
- [x] Lapor tamu menginap (dengan riwayat)
- [x] Edit profil & ganti password

### 🔑 Admin / Pak RT (role: admin)
- [x] Dashboard statistik + 3 grafik Chart.js
- [x] CRUD data penduduk (tambah, edit, hapus, cari)
- [x] Kelola laporan pindah & datang (approve/tolak)
- [x] Monitor tamu menginap (tandai sudah pergi)
- [x] CRUD pengumuman (tambah, edit, hapus)
- [x] Kelola akun user (tambah, edit, hapus)

---

## Teknologi yang Digunakan

| Komponen   | Teknologi                     |
|------------|-------------------------------|
| Backend    | PHP 8 (PDO, Session)          |
| Database   | MySQL (XAMPP)                 |
| Frontend   | HTML5, Bootstrap 5.3          |
| Icons      | Bootstrap Icons 1.11          |
| Charts     | Chart.js 4.4                  |
| Font       | Plus Jakarta Sans (Google)    |

---

## ERD Singkat

```
users ──< penduduk
users ──< laporan_pindah
users ──< laporan_datang
users ──< laporan_tamu
users ──< pengumuman
penduduk ──< laporan_pindah
penduduk ──< laporan_tamu
```

---

*Dibuat untuk Tugas Mata Kuliah Sistem Informasi — Universitas Pembangunan Jaya*
