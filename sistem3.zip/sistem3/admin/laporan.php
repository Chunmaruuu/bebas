<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Kelola Laporan';
$basePath  = '..';
$pdo       = getDB();

// ── Proses approval ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_proses'])) {
    $lid     = intval($_POST['id']);
    $jenis   = $_POST['jenis'];
    $status  = $_POST['status'];
    $catatan = trim($_POST['catatan'] ?? '');
    $uid     = currentUser()['id'];

    if ($jenis === 'pindah') {
        $pdo->prepare("UPDATE laporan_pindah SET status=?,catatan_admin=?,diproses_oleh=? WHERE id=?")
            ->execute([$status, $catatan, $uid, $lid]);
        if ($status === 'disetujui') {
            $s = $pdo->prepare("SELECT penduduk_id, dibuat_oleh FROM laporan_pindah WHERE id=?");
            $s->execute([$lid]);
            $pRow = $s->fetch();
            if ($pRow) {
                $pdo->prepare("UPDATE penduduk SET status='pindah' WHERE id=?")
                    ->execute([$pRow['penduduk_id']]);
            }
        }
    } elseif ($jenis === 'datang') {
        $pdo->prepare("UPDATE laporan_datang SET status=?,catatan_admin=?,diproses_oleh=? WHERE id=?")
            ->execute([$status, $catatan, $uid, $lid]);
        if ($status === 'disetujui') {
            $s = $pdo->prepare("SELECT * FROM laporan_datang WHERE id=?");
            $s->execute([$lid]);
            $l = $s->fetch();
            if ($l) {
                $pdo->prepare(
                    "INSERT IGNORE INTO penduduk
                     (nik,no_kk,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,alamat,no_rt,no_rw)
                     VALUES (?,?,?,?,?,?,?,?,?)"
                )->execute([
                    $l['nik'], $l['no_kk'] ?? null, $l['nama'], $l['jenis_kelamin'],
                    $l['tempat_lahir'], $l['tanggal_lahir'], $l['alamat_asal'], '001', '003'
                ]);
            }
        }
    }
    setFlash('success', 'Laporan berhasil diperbarui.');
    redirect("laporan.php?tab=$jenis");
}

// ── Ambil data ───────────────────────────────────────────────
$tab = $_GET['tab'] ?? 'pindah';

$pindah = $pdo->query(
    "SELECT lp.*,
            p.nama    AS nama_penduduk,
            p.nik     AS nik_penduduk,
            p.alamat  AS alamat_penduduk,
            p.no_rt, p.no_rw,
            u.nama    AS pelapor,
            u.no_hp   AS hp_pelapor,
            ap.nama   AS diproses_nama
     FROM laporan_pindah lp
     JOIN penduduk p     ON lp.penduduk_id = p.id
     LEFT JOIN users u   ON lp.dibuat_oleh  = u.id
     LEFT JOIN users ap  ON lp.diproses_oleh = ap.id
     ORDER BY FIELD(lp.status,'pending','disetujui','ditolak'), lp.created_at DESC"
)->fetchAll();

$datang = $pdo->query(
    "SELECT ld.*,
            u.nama   AS pelapor,
            u.no_hp  AS hp_pelapor,
            ap.nama  AS diproses_nama
     FROM laporan_datang ld
     LEFT JOIN users u  ON ld.dibuat_oleh   = u.id
     LEFT JOIN users ap ON ld.diproses_oleh = ap.id
     ORDER BY FIELD(ld.status,'pending','disetujui','ditolak'), ld.created_at DESC"
)->fetchAll();

$list     = $tab === 'pindah' ? $pindah : $datang;
$isP      = $tab === 'pindah';
$npPend   = count(array_filter($pindah, fn($r) => $r['status'] === 'pending'));
$ndPend   = count(array_filter($datang, fn($r) => $r['status'] === 'pending'));

// detail dari GET
$detailId = intval($_GET['detail'] ?? 0);
$D        = null; // detail data
if ($detailId) {
    if ($isP) {
        $s = $pdo->prepare(
            "SELECT lp.*, p.nama AS nama_penduduk, p.nik AS nik_penduduk,
                    p.alamat AS alamat_penduduk, p.no_rt, p.no_rw,
                    u.nama AS pelapor, u.no_hp AS hp_pelapor, ap.nama AS diproses_nama
             FROM laporan_pindah lp
             JOIN penduduk p ON lp.penduduk_id=p.id
             LEFT JOIN users u ON lp.dibuat_oleh=u.id
             LEFT JOIN users ap ON lp.diproses_oleh=ap.id
             WHERE lp.id=?"
        );
    } else {
        $s = $pdo->prepare(
            "SELECT ld.*, u.nama AS pelapor, u.no_hp AS hp_pelapor, ap.nama AS diproses_nama
             FROM laporan_datang ld
             LEFT JOIN users u ON ld.dibuat_oleh=u.id
             LEFT JOIN users ap ON ld.diproses_oleh=ap.id
             WHERE ld.id=?"
        );
    }
    $s->execute([$detailId]);
    $D = $s->fetch();
}

include __DIR__ . '/../includes/header.php';
?>
<!-------- PAGE-SPECIFIC STYLES -------->
<style>
/* ── outer wrapper biar sidebar + content tetap fit ── */
.laporan-page { display:flex; flex-direction:column; gap:0; }

/* ── tab pills ── */
.tab-pill {
  display:inline-flex; align-items:center; gap:.45rem;
  padding:.55rem 1.2rem; border-radius:8px 8px 0 0;
  font-size:.88rem; font-weight:600; cursor:pointer;
  border:1px solid #dee2e6; border-bottom:none;
  background:#f8f9fa; color:#6b7280; text-decoration:none;
  transition:background .15s, color .15s;
}
.tab-pill:hover { background:#fff; color:var(--fr-sage); }
.tab-pill.active { background:#fff; color:var(--fr-sage); border-color:#dee2e6; }
.tab-pill .badge-pill {
  background:#dc3545; color:#fff; border-radius:10px;
  padding:1px 7px; font-size:.72rem;
}

/* ── main card ── */
.laporan-card {
  background:#fff; border:1px solid #dee2e6;
  border-radius:0 8px 8px 8px; overflow:hidden;
}

/* ── tabel ── */
.laporan-table { width:100%; border-collapse:collapse; font-size:.85rem; }
.laporan-table thead th {
  background:var(--fr-bg); color:var(--fr-sage); font-weight:700;
  font-size:.73rem; text-transform:uppercase; letter-spacing:.05em;
  padding:.7rem 1rem; border-bottom:2px solid #d1e8d9;
  white-space:nowrap;
}
.laporan-table tbody td { padding:.75rem 1rem; border-bottom:1px solid #f3f4f6; vertical-align:middle; }
.laporan-table tbody tr:last-child td { border-bottom:none; }
.laporan-table tbody tr { cursor:pointer; transition:background .12s; }
.laporan-table tbody tr:hover td { background:#f8fdf9; }
.laporan-table tbody tr.row-active td {
  background:#e8f5ee !important;
  border-left:3px solid #1a6b3a;
}
.laporan-table tbody tr.row-active td:not(:first-child) { border-left:none; }

.col-nama  { min-width:150px; }
.col-lok   { min-width:100px; max-width:120px; }
.col-alasan{ min-width:160px; max-width:200px; }
.col-tgl   { min-width:110px; white-space:nowrap; }
.col-status{ min-width:90px; }
.col-aksi  { min-width:80px; text-align:center; }

.alasan-clip {
  overflow:hidden; white-space:nowrap; text-overflow:ellipsis;
  max-width:200px; color:#6b7280; font-size:.8rem;
}
.no-alasan { color:#d1d5db; font-style:italic; font-size:.78rem; }

/* ── DETAIL PANEL — bawah tabel, bukan di samping ── */
.detail-wrap {
  margin-top:0;
  border-top:2px solid #1a6b3a;
  background:#fff;
  border-radius:0 0 8px 8px;
  animation:fadeUp .2s ease;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }

.detail-header-bar {
  background:linear-gradient(135deg,#0f3d22 0%,#1a6b3a 100%);
  color:#fff; padding:1rem 1.5rem;
  display:flex; align-items:center; justify-content:space-between; gap:1rem;
  flex-wrap:wrap;
}
.detail-header-bar .dh-left h5 { font-size:1rem; font-weight:700; margin:0; }
.detail-header-bar .dh-left .sub { font-size:.78rem; opacity:.75; margin-top:.15rem; }
.detail-header-bar .dh-right { display:flex; align-items:center; gap:.6rem; flex-shrink:0; }

.detail-body { padding:1.25rem 1.5rem; }

/* ── Info grid di dalam detail ── */
.info-grid {
  display:grid;
  grid-template-columns:repeat(auto-fill, minmax(180px, 1fr));
  gap:.75rem 1.5rem;
  margin-bottom:1rem;
}
.info-grid.full { grid-template-columns:1fr; }
.ig-label { font-size:.7rem; font-weight:700; text-transform:uppercase;
            letter-spacing:.06em; color:#9ca3af; margin-bottom:.18rem; }
.ig-value { font-size:.88rem; color:#1a1a1a; font-weight:500; }
.ig-value code { font-size:.82rem; background:#f3f4f6; padding:1px 5px; border-radius:4px; }

/* ── Section divider dalam detail ── */
.dsec {
  display:flex; align-items:center; gap:.6rem;
  font-size:.72rem; font-weight:700; text-transform:uppercase;
  letter-spacing:.07em; color:var(--fr-sage); margin:1.1rem 0 .8rem;
}
.dsec::after { content:''; flex:1; height:1.5px; background:#e5e7eb; }

/* ── Alasan box ── */
.alasan-box {
  background:#fffbeb; border:1px solid #fcd34d; border-radius:10px;
  padding:.85rem 1.1rem; font-size:.88rem; line-height:1.65; color:#78350f;
  position:relative;
}
.alasan-box.biru {
  background:#eff6ff; border-color:#bfdbfe; color:#1e40af;
}
.alasan-box .q-icon {
  font-size:1.3rem; opacity:.3; margin-right:.25rem; vertical-align:top; line-height:1;
}
.alasan-empty { color:#9ca3af; font-style:italic; font-size:.85rem; padding:.5rem 0; }

/* ── Alamat box ── */
.alamat-box {
  background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px;
  padding:.7rem 1rem; font-size:.85rem; line-height:1.6; color:#374151;
}

/* ── Action bar di detail ── */
.detail-actions {
  display:flex; gap:.75rem; flex-wrap:wrap;
  padding:1rem 1.5rem; border-top:1px solid #e5e7eb;
  background:#f9fafb; border-radius:0 0 8px 8px;
}

/* ── Status badges ── */
.sbadge { display:inline-flex; align-items:center; gap:.3rem;
          padding:.28rem .7rem; border-radius:20px; font-size:.75rem; font-weight:700; }
.sbadge.pending   { background:#fef3c7; color:#92400e; }
.sbadge.disetujui { background:#d1fae5; color:#065f46; }
.sbadge.ditolak   { background:#fee2e2; color:#991b1b; }

/* ── Empty state ── */
.empty-state { text-align:center; padding:3rem 1rem; color:#9ca3af; }
.empty-state i { font-size:2.5rem; opacity:.2; display:block; margin-bottom:.75rem; }
</style>

<div class="container-fluid">
  <div class="row">

    <!-------- SIDEBAR -------->
    <div class="col-md-2 sidebar d-none d-md-block">
      <?php include 'sidebar.php'; ?>
    </div>

    <!-------- MAIN CONTENT -------->
    <div class="col-md-10 py-4 px-4">

      <!---- Top bar ---->
      <div class="d-flex align-items-center justify-content-between mb-4">
        <h4 class="fw-bold mb-0">
          <i class="bi bi-file-earmark-text" style="color:#185fa5"></i>
          Kelola Laporan
        </h4>
        <?php if ($npPend + $ndPend > 0): ?>
        <span class="sbadge pending" style="font-size:.82rem; padding:.35rem .9rem">
          <i class="bi bi-clock-history"></i>
          <?= $npPend + $ndPend ?> menunggu diproses
        </span>
        <?php endif; ?>
      </div>

      <?= flashHtml() ?>

      <!---- Tabs ---->
      <div class="d-flex gap-0 mb-0">
        <a href="?tab=pindah<?= $detailId && $tab==='pindah' ? '&detail='.$detailId : '' ?>"
           class="tab-pill <?= $tab==='pindah' ? 'active' : '' ?>">
          <i class="bi bi-arrow-right-square" style="color:#f59e0b"></i>
          Laporan Pindah
          <?php if ($npPend): ?>
          <span class="badge-pill"><?= $npPend ?></span>
          <?php endif; ?>
        </a>
        <a href="?tab=datang<?= $detailId && $tab==='datang' ? '&detail='.$detailId : '' ?>"
           class="tab-pill <?= $tab==='datang' ? 'active' : '' ?>" style="margin-left:4px">
          <i class="bi bi-arrow-left-square" style="color:#185fa5"></i>
          Laporan Datang
          <?php if ($ndPend): ?>
          <span class="badge-pill"><?= $ndPend ?></span>
          <?php endif; ?>
        </a>
      </div>

      <!---- Card utama ---->
      <div class="laporan-card">

        <!---- Tabel ---->
        <div class="table-responsive">
          <table class="laporan-table">
            <thead>
              <tr>
                <th style="width:36px">#</th>
                <th class="col-nama">Nama</th>
                <th class="col-lok"><?= $isP ? 'Tujuan' : 'Asal' ?></th>
                <th class="col-alasan">Alasan</th>
                <th class="col-tgl">Tanggal</th>
                <th class="col-status">Status</th>
                <th class="col-aksi">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($list)): ?>
              <tr>
                <td colspan="7">
                  <div class="empty-state">
                    <i class="bi bi-inbox"></i>
                    Belum ada laporan <?= $isP ? 'pindah' : 'datang' ?>.
                  </div>
                </td>
              </tr>
              <?php endif; ?>

              <?php foreach ($list as $i => $l):
                $namaRow   = $isP ? $l['nama_penduduk'] : $l['nama'];
                $lokasiRow = $isP ? ($l['kota_tujuan'] ?: '-') : ($l['kota_asal'] ?: '-');
                $tglRow    = $isP ? $l['tanggal_pindah'] : $l['tanggal_datang'];
                $alasanRow = trim($l['alasan'] ?? '');
                $isActive  = $D && $D['id'] == $l['id'];
                $rowUrl    = "?tab=$tab&detail={$l['id']}#detail-anchor";
              ?>
              <tr class="<?= $isActive ? 'row-active' : '' ?>"
                  onclick="window.location='<?= $rowUrl ?>'">
                <td class="text-muted"><?= $i + 1 ?></td>
                <td class="col-nama">
                  <div style="font-weight:600;font-size:.87rem"><?= clean($namaRow) ?></div>
                  <div style="font-size:.72rem;color:#9ca3af;margin-top:.1rem">
                    oleh <?= clean($l['pelapor'] ?? 'Admin') ?>
                  </div>
                </td>
                <td class="col-lok" style="color:#374151;font-size:.84rem">
                  <?= clean($lokasiRow) ?>
                </td>
                <td class="col-alasan">
                  <?php if ($alasanRow): ?>
                  <span class="alasan-clip" title="<?= clean($alasanRow) ?>">
                    <?= clean($alasanRow) ?>
                  </span>
                  <?php else: ?>
                  <span class="no-alasan">—</span>
                  <?php endif; ?>
                </td>
                <td class="col-tgl" style="font-size:.82rem;color:#6b7280">
                  <?= formatTanggal($tglRow) ?>
                </td>
                <td class="col-status">
                  <?php
                  $sc = ['pending'=>'pending','disetujui'=>'disetujui','ditolak'=>'ditolak'];
                  $sl = $sc[$l['status']] ?? 'pending';
                  $si = ['pending'=>'bi-clock','disetujui'=>'bi-check-circle','ditolak'=>'bi-x-circle'];
                  ?>
                  <span class="sbadge <?= $sl ?>">
                    <i class="bi <?= $si[$l['status']] ?? 'bi-clock' ?>"></i>
                    <?= ucfirst($l['status']) ?>
                  </span>
                </td>
                <td class="col-aksi" onclick="event.stopPropagation()">
                  <?php if ($l['status'] === 'pending'): ?>
                  <button class="btn btn-sm fw-600"
                          style="background:var(--fr-sage);color:#fff;font-size:.78rem;padding:.3rem .7rem"
                          data-bs-toggle="modal" data-bs-target="#modalProses"
                          data-id="<?= $l['id'] ?>"
                          data-jenis="<?= $tab ?>"
                          data-nama="<?= clean($namaRow) ?>"
                          data-lokasi="<?= clean($lokasiRow) ?>"
                          data-alasan="<?= clean($alasanRow) ?>">
                    <i class="bi bi-check2-square"></i> Proses
                  </button>
                  <?php else: ?>
                  <a href="<?= $rowUrl ?>"
                     class="btn btn-sm btn-outline-secondary"
                     style="font-size:.78rem;padding:.3rem .65rem">
                    <i class="bi bi-eye"></i> Detail
                  </a>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!---- Hint klik ---->
        <?php if (!empty($list)): ?>
        <div style="padding:.5rem 1rem .65rem;font-size:.74rem;color:#9ca3af;border-top:1px solid #f3f4f6">
          <i class="bi bi-hand-index"></i>
          Klik baris untuk melihat detail lengkap laporan
        </div>
        <?php endif; ?>

      </div><!-- /.laporan-card -->

      <!-------- DETAIL PANEL — terpisah di bawah tabel -------->
      <?php if ($D): ?>
      <div class="detail-wrap mt-3" id="detail-anchor">

        <!---- Header detail ---->
        <div class="detail-header-bar">
          <div class="dh-left">
            <div style="font-size:.72rem;opacity:.65;margin-bottom:.2rem">
              <?= $isP ? '↗ LAPORAN PINDAH' : '↙ LAPORAN DATANG' ?>
              &nbsp;#<?= $D['id'] ?>
            </div>
            <h5><?= clean($isP ? $D['nama_penduduk'] : $D['nama']) ?></h5>
            <div class="sub">
              NIK:&nbsp;<code style="color:#86efac;font-size:.8rem">
                <?= clean($isP ? $D['nik_penduduk'] : $D['nik']) ?>
              </code>
            </div>
          </div>
          <div class="dh-right">
            <span class="sbadge <?= $D['status'] ?>"
                  style="font-size:.8rem;padding:.35rem .9rem">
              <i class="bi <?= ['pending'=>'bi-clock','disetujui'=>'bi-check-circle','ditolak'=>'bi-x-circle'][$D['status']] ?? 'bi-clock' ?>"></i>
              <?= ucfirst($D['status']) ?>
            </span>
            <a href="?tab=<?= $tab ?>"
               class="btn btn-sm"
               style="background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.35);font-size:.8rem">
              <i class="bi bi-x-lg"></i> Tutup
            </a>
          </div>
        </div>

        <div class="detail-body">

          <!---- ALASAN (paling atas, paling penting) ---->
          <div class="dsec">
            <i class="bi bi-chat-left-quote"></i>
            <?= $isP ? 'Alasan Pindah' : 'Alasan Pindah ke Sini' ?>
          </div>
          <?php if (!empty(trim($D['alasan']))): ?>
          <div class="alasan-box <?= $isP ? '' : 'biru' ?>">
            <span class="q-icon">"</span><?= nl2br(clean($D['alasan'])) ?>"
          </div>
          <?php else: ?>
          <div class="alasan-empty">Tidak ada alasan yang dicantumkan oleh pelapor.</div>
          <?php endif; ?>

          <?php if ($isP): ?>
          <!---- DATA PINDAH ---->
          <div class="dsec"><i class="bi bi-person-vcard"></i> Data Penduduk</div>
          <div class="info-grid">
            <div>
              <div class="ig-label">Nama Lengkap</div>
              <div class="ig-value"><?= clean($D['nama_penduduk']) ?></div>
            </div>
            <div>
              <div class="ig-label">NIK</div>
              <div class="ig-value"><code><?= clean($D['nik_penduduk']) ?></code></div>
            </div>
            <div>
              <div class="ig-label">Alamat Sekarang</div>
              <div class="ig-value"><?= clean($D['alamat_penduduk'] ?: '-') ?></div>
            </div>
            <div>
              <div class="ig-label">RT / RW</div>
              <div class="ig-value"><?= clean($D['no_rt'] ?? '001') ?> / <?= clean($D['no_rw'] ?? '003') ?></div>
            </div>
          </div>

          <div class="dsec"><i class="bi bi-geo-alt"></i> Tujuan Kepindahan</div>
          <div class="info-grid">
            <div>
              <div class="ig-label">Tanggal Pindah</div>
              <div class="ig-value" style="font-weight:700"><?= formatTanggal($D['tanggal_pindah']) ?></div>
            </div>
            <div>
              <div class="ig-label">Kota / Kabupaten</div>
              <div class="ig-value"><?= clean($D['kota_tujuan'] ?: '-') ?></div>
            </div>
            <?php if (!empty($D['rt_tujuan'])): ?>
            <div>
              <div class="ig-label">RT / RW Tujuan</div>
              <div class="ig-value"><?= clean($D['rt_tujuan']) ?>/<?= clean($D['rw_tujuan'] ?? '-') ?></div>
            </div>
            <?php endif; ?>
            <?php if (!empty($D['kode_pos_tujuan'])): ?>
            <div>
              <div class="ig-label">Kode Pos Tujuan</div>
              <div class="ig-value"><?= clean($D['kode_pos_tujuan']) ?></div>
            </div>
            <?php endif; ?>
          </div>
          <div class="ig-label">Alamat Tujuan Lengkap</div>
          <div class="alamat-box mt-1"><?= nl2br(clean($D['alamat_tujuan'])) ?></div>

          <?php else: ?>
          <!---- DATA DATANG ---->
          <div class="dsec"><i class="bi bi-person-vcard"></i> Identitas Penduduk Baru</div>
          <div class="info-grid">
            <div>
              <div class="ig-label">Nama Lengkap</div>
              <div class="ig-value"><?= clean($D['nama']) ?></div>
            </div>
            <div>
              <div class="ig-label">Jenis Kelamin</div>
              <div class="ig-value"><?= $D['jenis_kelamin']==='L' ? 'Laki-laki' : 'Perempuan' ?></div>
            </div>
            <div>
              <div class="ig-label">NIK</div>
              <div class="ig-value"><code><?= clean($D['nik']) ?></code></div>
            </div>
            <?php if (!empty($D['no_kk'])): ?>
            <div>
              <div class="ig-label">No. KK</div>
              <div class="ig-value"><code><?= clean($D['no_kk']) ?></code></div>
            </div>
            <?php endif; ?>
            <div>
              <div class="ig-label">Tempat, Tgl Lahir</div>
              <div class="ig-value">
                <?= clean($D['tempat_lahir'] ?: '-') ?>
                <?= $D['tanggal_lahir'] ? ', '.formatTanggal($D['tanggal_lahir']) : '' ?>
              </div>
            </div>
            <div>
              <div class="ig-label">Tanggal Datang</div>
              <div class="ig-value" style="font-weight:700"><?= formatTanggal($D['tanggal_datang']) ?></div>
            </div>
          </div>

          <div class="dsec"><i class="bi bi-geo-alt"></i> Asal</div>
          <div class="info-grid">
            <div>
              <div class="ig-label">Kota Asal</div>
              <div class="ig-value"><?= clean($D['kota_asal'] ?: '-') ?></div>
            </div>
          </div>
          <div class="ig-label">Alamat Asal Lengkap</div>
          <div class="alamat-box mt-1"><?= nl2br(clean($D['alamat_asal'])) ?></div>
          <?php endif; ?>

          <!---- PELAPOR ---->
          <div class="dsec"><i class="bi bi-person-check"></i> Informasi Pelaporan</div>
          <div class="info-grid">
            <div>
              <div class="ig-label">Dilaporkan oleh</div>
              <div class="ig-value"><?= clean($D['pelapor'] ?? 'Admin') ?></div>
            </div>
            <?php if (!empty($D['hp_pelapor'])): ?>
            <div>
              <div class="ig-label">No. HP Pelapor</div>
              <div class="ig-value"><?= clean($D['hp_pelapor']) ?></div>
            </div>
            <?php endif; ?>
            <div>
              <div class="ig-label">Tanggal Laporan Masuk</div>
              <div class="ig-value"><?= formatTanggal(date('Y-m-d',strtotime($D['created_at']))) ?></div>
            </div>
            <?php if ($D['status'] !== 'pending' && !empty($D['diproses_nama'])): ?>
            <div>
              <div class="ig-label">Diproses oleh</div>
              <div class="ig-value"><?= clean($D['diproses_nama']) ?></div>
            </div>
            <?php endif; ?>
          </div>

          <!---- CATATAN ADMIN ---->
          <?php if (!empty($D['catatan_admin'])): ?>
          <div class="dsec"><i class="bi bi-sticky"></i> Catatan Admin</div>
          <div class="p-3 rounded" style="background:#fef9c3;border:1px solid #fde68a;font-size:.87rem;color:#713f12">
            <?= nl2br(clean($D['catatan_admin'])) ?>
          </div>
          <?php endif; ?>

          <!---- Status sudah diproses ---->
          <?php if ($D['status'] !== 'pending'): ?>
          <div class="alert <?= $D['status']==='disetujui' ? 'alert-success' : 'alert-danger' ?> mt-3 small mb-0">
            <i class="bi bi-<?= $D['status']==='disetujui' ? 'check-circle' : 'x-circle' ?>"></i>
            Laporan ini sudah <strong><?= $D['status'] ?></strong>
            <?= !empty($D['diproses_nama']) ? ' oleh '.clean($D['diproses_nama']) : '' ?>.
          </div>
          <?php endif; ?>

        </div><!-- /.detail-body -->

        <!---- Tombol aksi ---->
        <?php if ($D['status'] === 'pending'): ?>
        <div class="detail-actions">
          <button class="btn fw-600 px-4"
                  style="background:var(--fr-sage);color:#fff"
                  data-bs-toggle="modal" data-bs-target="#modalProses"
                  data-id="<?= $D['id'] ?>" data-jenis="<?= $tab ?>"
                  data-nama="<?= clean($isP ? $D['nama_penduduk'] : $D['nama']) ?>"
                  data-lokasi="<?= clean($isP ? ($D['kota_tujuan']??'-') : ($D['kota_asal']??'-')) ?>"
                  data-alasan="<?= clean($D['alasan']??'') ?>">
            <i class="bi bi-check-lg me-1"></i> Setujui Laporan
          </button>
          <button class="btn btn-danger fw-600 px-4"
                  data-bs-toggle="modal" data-bs-target="#modalProses"
                  data-id="<?= $D['id'] ?>" data-jenis="<?= $tab ?>"
                  data-nama="<?= clean($isP ? $D['nama_penduduk'] : $D['nama']) ?>"
                  data-lokasi="<?= clean($isP ? ($D['kota_tujuan']??'-') : ($D['kota_asal']??'-')) ?>"
                  data-alasan="<?= clean($D['alasan']??'') ?>"
                  data-force-tolak="1">
            <i class="bi bi-x-lg me-1"></i> Tolak Laporan
          </button>
          <a href="?tab=<?= $tab ?>" class="btn btn-outline-secondary ms-auto">
            <i class="bi bi-x"></i> Tutup Detail
          </a>
        </div>
        <?php else: ?>
        <div class="detail-actions">
          <a href="?tab=<?= $tab ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Kembali ke Daftar
          </a>
        </div>
        <?php endif; ?>

      </div><!-- /.detail-wrap -->
      <?php endif; ?>

    </div><!-- /.col-md-10 -->
  </div><!-- /.row -->
</div><!-- /.container-fluid -->

<!-------- MODAL PROSES -------->
<div class="modal fade" id="modalProses" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius:14px;overflow:hidden">

      <div class="modal-header" id="mHeader" style="border-bottom:none;padding:1.25rem 1.5rem">
        <h5 class="modal-title fw-bold" id="mTitle">Proses Laporan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form method="POST">
        <input type="hidden" name="submit_proses" value="1">
        <div class="modal-body" style="padding:0 1.5rem 1rem">
          <input type="hidden" name="id"    id="mId">
          <input type="hidden" name="jenis" id="mJenis">

          <!-- Ringkasan -->
          <div class="rounded-3 p-3 mb-3" style="background:#f8fafc;border:1px solid #e2e8f0;font-size:.85rem">
            <div class="d-flex gap-4 flex-wrap">
              <div><span class="text-muted">Nama:</span> <strong id="mNama"></strong></div>
              <div><span class="text-muted" id="mLokasiLabel">Tujuan:</span> <strong id="mLokasi"></strong></div>
            </div>
          </div>

          <!-- Alasan warga -->
          <div class="mb-3">
            <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#6b7280;margin-bottom:.4rem">
              <i class="bi bi-chat-left-quote"></i> Alasan dari Pelapor
            </div>
            <div class="alasan-box" id="mAlasanBox"></div>
          </div>

          <!-- Pilihan keputusan -->
          <div class="mb-3">
            <div style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#6b7280;margin-bottom:.5rem">
              Keputusan Admin
            </div>
            <div class="d-flex gap-2">
              <label class="opt-card flex-fill text-center p-3 rounded-3 border" id="optS"
                     style="cursor:pointer;transition:.15s">
                <input type="radio" name="status" value="disetujui" id="rS" class="d-none" checked>
                <i class="bi bi-check-circle-fill d-block mb-1" style="font-size:1.6rem;color:#16a34a"></i>
                <span style="font-size:.85rem;font-weight:700;color:#15803d">Setujui</span>
              </label>
              <label class="opt-card flex-fill text-center p-3 rounded-3 border" id="optT"
                     style="cursor:pointer;transition:.15s">
                <input type="radio" name="status" value="ditolak" id="rT" class="d-none">
                <i class="bi bi-x-circle-fill d-block mb-1" style="font-size:1.6rem;color:#dc2626"></i>
                <span style="font-size:.85rem;font-weight:700;color:#dc2626">Tolak</span>
              </label>
            </div>
          </div>

          <!-- Catatan -->
          <div>
            <label class="form-label" style="font-size:.8rem;font-weight:600">
              Catatan untuk Warga
              <span class="text-muted fw-400" id="cHint">(opsional)</span>
            </label>
            <textarea name="catatan" id="mCatatan" class="form-control" rows="3"
                      placeholder="Tuliskan catatan, alasan penolakan, atau informasi tambahan..."
                      style="font-size:.87rem"></textarea>
          </div>
        </div>

        <div class="modal-footer" style="padding:.9rem 1.5rem;border-top:1px solid #e5e7eb">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn fw-600 px-4" id="mSubmit"
                  style="background:var(--fr-sage);color:#fff">
            <i class="bi bi-check-lg me-1"></i> Simpan Keputusan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php
$extraJs = <<<'JS'
<script>
const mEl     = document.getElementById("modalProses");
const mId     = document.getElementById("mId");
const mJenis  = document.getElementById("mJenis");
const mNama   = document.getElementById("mNama");
const mLokasi = document.getElementById("mLokasi");
const mLokasiLabel = document.getElementById("mLokasiLabel");
const mAlasan = document.getElementById("mAlasanBox");
const mSubmit = document.getElementById("mSubmit");
const mTitle  = document.getElementById("mTitle");
const mHeader = document.getElementById("mHeader");
const rS      = document.getElementById("rS");
const rT      = document.getElementById("rT");
const optS    = document.getElementById("optS");
const optT    = document.getElementById("optT");
const cHint   = document.getElementById("cHint");
const mCatatan= document.getElementById("mCatatan");

mEl.addEventListener("show.bs.modal", function(e) {
  const b = e.relatedTarget;
  mId.value    = b.dataset.id;
  mJenis.value = b.dataset.jenis;
  mNama.textContent   = b.dataset.nama   || "-";
  mLokasi.textContent = b.dataset.lokasi || "-";
  mLokasiLabel.textContent = b.dataset.jenis === "pindah" ? "Tujuan:" : "Asal:";

  const al = (b.dataset.alasan || "").trim();
  if (al && al !== "-") {
    mAlasan.innerHTML = "\u201C " + al.replace(/\n/g,"<br>") + " \u201D";
    mAlasan.className = "alasan-box " + (b.dataset.jenis === "datang" ? "biru" : "");
  } else {
    mAlasan.innerHTML = "<em style='color:#9ca3af'>Tidak ada alasan dicantumkan.</em>";
    mAlasan.className = "alasan-box";
    mAlasan.style.background = "#f9fafb";
    mAlasan.style.borderColor = "#e5e7eb";
  }

  const forceTolak = b.dataset.forceTolak === "1";
  if (forceTolak) { rT.checked = true; } else { rS.checked = true; }
  updateModal();
});

function updateModal() {
  const setuju = rS.checked;
  optS.style.background   = setuju ? "#f0fdf4" : "#fff";
  optS.style.borderColor  = setuju ? "#22c55e" : "#dee2e6";
  optT.style.background   = !setuju ? "#fff5f5" : "#fff";
  optT.style.borderColor  = !setuju ? "#ef4444" : "#dee2e6";
  mSubmit.style.background = setuju ? "#1a6b3a" : "#dc2626";
  mSubmit.innerHTML = setuju
    ? '<i class="bi bi-check-lg me-1"></i> Setujui Laporan'
    : '<i class="bi bi-x-lg me-1"></i> Tolak Laporan';
  cHint.textContent = setuju ? "(opsional)" : "(wajib diisi)";
  mCatatan.required = !setuju;
}

[optS, optT].forEach(el => {
  el.addEventListener("click", function() {
    this.querySelector("input").checked = true;
    updateModal();
  });
});
</script>
JS;
include __DIR__ . "/../includes/footer.php"; ?>
