<?php
// admin/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
$pdo2 = getDB();
$pendingReg    = $pdo2->query("SELECT COUNT(*) FROM registrasi_warga WHERE status='menunggu'")->fetchColumn();
$pendingLap    = $pdo2->query("SELECT COUNT(*) FROM laporan_pindah WHERE status='pending'")->fetchColumn()
               + $pdo2->query("SELECT COUNT(*) FROM laporan_datang WHERE status='pending'")->fetchColumn();
$pendingJadwal = $pdo2->query("SELECT COUNT(*) FROM jadwal_bertemu_rt WHERE status='menunggu'")->fetchColumn();
$pendingEdit   = $pdo2->query("SELECT COUNT(*) FROM edit_profil_request WHERE status='menunggu'")->fetchColumn();

$menus = [
  ['file'=>'dashboard.php',    'icon'=>'bi-speedometer2',     'label'=>'Dashboard'],
  ['file'=>'penduduk.php',     'icon'=>'bi-people',            'label'=>'Data Penduduk'],
  ['file'=>'registrasi.php',   'icon'=>'bi-person-plus-fill',  'label'=>'Registrasi Warga',  'badge'=>$pendingReg],
  ['file'=>'laporan.php',      'icon'=>'bi-file-earmark-text', 'label'=>'Kelola Laporan',    'badge'=>$pendingLap],
  ['file'=>'tamu.php',         'icon'=>'bi-person-badge',      'label'=>'Data Tamu'],
  ['file'=>'jadwal_rt.php',    'icon'=>'bi-calendar2-check',   'label'=>'Jadwal Bertemu RT', 'badge'=>$pendingJadwal],
  ['file'=>'edit_request.php', 'icon'=>'bi-pencil-square',     'label'=>'Edit Data Warga',   'badge'=>$pendingEdit],
  ['file'=>'pengumuman.php',   'icon'=>'bi-megaphone',         'label'=>'Pengumuman'],
  ['file'=>'users.php',        'icon'=>'bi-people-fill',       'label'=>'Kelola User'],
];
?>
<div style="padding:.5rem .5rem 1rem;text-align:center">
  <div style="font-family:'Cinzel',serif;font-size:.6rem;letter-spacing:.2em;color:var(--fr-gold);opacity:.7;padding:.4rem 0">✦ &nbsp;PANEL ADMIN&nbsp; ✦</div>
  <div class="rune-divider" style="margin:.4rem 0"></div>
</div>
<ul class="nav flex-column">
  <?php foreach ($menus as $m): ?>
  <li class="nav-item">
    <a class="nav-link <?= $currentPage === $m['file'] ? 'active' : '' ?>" href="<?= $m['file'] ?>">
      <i class="bi <?= $m['icon'] ?>"></i>
      <?= $m['label'] ?>
      <?php if (!empty($m['badge']) && $m['badge'] > 0): ?>
      <span class="badge bg-danger ms-auto"><?= $m['badge'] ?></span>
      <?php endif; ?>
    </a>
  </li>
  <?php endforeach; ?>
  <li><div class="sidebar-divider mt-2"></div></li>
  <li class="nav-item">
    <a class="nav-link" href="../auth/logout.php" style="color:#c08080 !important">
      <i class="bi bi-box-arrow-right"></i> Keluar
    </a>
  </li>
</ul>
