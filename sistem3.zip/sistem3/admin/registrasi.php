<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Verifikasi Registrasi';
$basePath  = '..';
$pdo       = getDB();

// Proses approve / tolak
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rid     = intval($_POST['id']);
    $status  = $_POST['status'];
    $catatan = trim($_POST['catatan'] ?? '');
    $uid     = currentUser()['id'];

    $stmt = $pdo->prepare("SELECT * FROM registrasi_warga WHERE id=?");
    $stmt->execute([$rid]); $reg = $stmt->fetch();

    if ($reg && $status === 'disetujui') {
        $pdo->prepare(
            "INSERT INTO users (nama,username,password,role,no_hp,email,status_akun) VALUES (?,?,?,'warga',?,?,'aktif')"
        )->execute([$reg['nama'],$reg['username'],$reg['password'],$reg['no_hp'],$reg['email']]);
        $newUserId = $pdo->lastInsertId();

        $pdo->prepare(
            "INSERT INTO kartu_keluarga (no_kk,nama_kepala,alamat,rt,rw,kode_pos,kelurahan,kecamatan,kabupaten,provinsi,jumlah_anggota)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE jumlah_anggota=VALUES(jumlah_anggota)"
        )->execute([
            $reg['no_kk'], $reg['nama_kepala_kk']?:$reg['nama'],
            $reg['alamat'],$reg['no_rt'],$reg['no_rw'],
            $reg['kode_pos'],$reg['kelurahan'],$reg['kecamatan'],$reg['kabupaten'],$reg['provinsi'],
            $reg['jumlah_keluarga']
        ]);

        $pdo->prepare(
            "INSERT IGNORE INTO penduduk
             (nik,no_kk,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,agama,status_kawin,
              status_hubungan,pekerjaan,pendidikan,alamat,no_rt,no_rw,kode_pos,
              kelurahan,kecamatan,kabupaten,provinsi,user_id)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        )->execute([
            $reg['nik'],$reg['no_kk'],$reg['nama'],$reg['jenis_kelamin'],
            $reg['tempat_lahir'],$reg['tanggal_lahir'],$reg['agama'],
            $reg['status_kawin'],$reg['status_hubungan'],$reg['pekerjaan'],
            $reg['pendidikan'],$reg['alamat'],$reg['no_rt'],$reg['no_rw'],
            $reg['kode_pos'],$reg['kelurahan'],$reg['kecamatan'],$reg['kabupaten'],
            $reg['provinsi'],$newUserId
        ]);
        setFlash('success', "Registrasi <strong>{$reg['nama']}</strong> disetujui. Akun warga aktif.");
    } elseif ($reg && $status === 'ditolak') {
        setFlash('warning', "Registrasi <strong>{$reg['nama']}</strong> ditolak.");
    }

    $pdo->prepare("UPDATE registrasi_warga SET status=?,catatan_admin=?,diproses_oleh=? WHERE id=?")
        ->execute([$status,$catatan,$uid,$rid]);
    redirect('registrasi.php');
}

$tab    = $_GET['tab'] ?? 'menunggu';
$detail = isset($_GET['detail']) ? intval($_GET['detail']) : null;

$list = $pdo->prepare("SELECT * FROM registrasi_warga WHERE status=? ORDER BY created_at DESC");
$list->execute([$tab]); $list = $list->fetchAll();

$counts = [
    'menunggu'  => $pdo->query("SELECT COUNT(*) FROM registrasi_warga WHERE status='menunggu'")->fetchColumn(),
    'disetujui' => $pdo->query("SELECT COUNT(*) FROM registrasi_warga WHERE status='disetujui'")->fetchColumn(),
    'ditolak'   => $pdo->query("SELECT COUNT(*) FROM registrasi_warga WHERE status='ditolak'")->fetchColumn(),
];

$detailReg = null;
if ($detail) {
    $s = $pdo->prepare("SELECT * FROM registrasi_warga WHERE id=?");
    $s->execute([$detail]); $detailReg = $s->fetch();
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 sidebar d-none d-md-block"><?php include __DIR__ . '/sidebar.php'; ?></div>
<div class="col-md-10 py-4 px-4">

<div class="d-flex justify-content-between align-items-center mb-4">
  <h4 class="fw-bold mb-0"><i class="bi bi-person-plus-fill me-2 text-success"></i>Verifikasi Registrasi Warga</h4>
</div>

<!-- Tabs -->
<div class="d-flex gap-2 mb-4 flex-wrap">
  <?php foreach (['menunggu'=>['warning','hourglass-split'],'disetujui'=>['success','check-circle'],'ditolak'=>['danger','x-circle']] as $t=>[$c,$ic]): ?>
  <a href="?tab=<?=$t?>" class="btn btn-<?=$tab===$t?$c:'outline-'.$c?> d-flex align-items-center gap-2">
    <i class="bi bi-<?=$ic?>"></i>
    <?=ucfirst($t)?>
    <span class="badge bg-white text-<?=$c?>"><?=$counts[$t]?></span>
  </a>
  <?php endforeach; ?>
</div>

<?= flashHtml() ?>

<?php if ($detailReg): ?>
<!-- Modal Detail -->
<div class="card mb-4 border-success">
  <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
    <span><i class="bi bi-person-vcard me-2"></i>Detail Registrasi — <?= clean($detailReg['nama']) ?></span>
    <a href="?tab=<?=$tab?>" class="btn btn-sm btn-light"><i class="bi bi-x-lg"></i> Tutup</a>
  </div>
  <div class="card-body">
    <div class="row g-4">
      <!-- Foto Dokumen -->
      <div class="col-md-5">
        <h6 class="fw-bold mb-3"><i class="bi bi-file-earmark-image me-1"></i>Dokumen Identitas</h6>
        <div class="row g-3">
          <div class="col-6">
            <div class="fw-semibold small mb-1 text-muted">Foto KTP</div>
            <?php
            $ktpPath    = $detailReg['foto_ktp'] ?? null;
            $ktpAbsPath = $ktpPath ? __DIR__ . '/../uploads/' . $ktpPath : null;
            $ktpUrl     = $ktpPath ? '../uploads/' . $ktpPath : null;
            if ($ktpAbsPath && file_exists($ktpAbsPath) && strpos($ktpPath,'.pdf')===false): ?>
            <a href="<?=$ktpUrl?>" target="_blank">
              <img src="<?=$ktpUrl?>" class="img-thumbnail w-100" style="max-height:160px;object-fit:cover" alt="Foto KTP">
            </a>
            <div class="text-center mt-1"><a href="<?=$ktpUrl?>" target="_blank" class="btn btn-sm btn-outline-success w-100"><i class="bi bi-eye me-1"></i>Lihat Penuh</a></div>
            <?php elseif ($ktpAbsPath && file_exists($ktpAbsPath) && strpos($ktpPath,'.pdf')!==false): ?>
            <a href="<?=$ktpUrl?>" target="_blank" class="btn btn-outline-secondary w-100">
              <i class="bi bi-file-pdf me-1"></i>Lihat PDF KTP
            </a>
            <?php else: ?>
            <div class="alert alert-secondary small text-center py-3"><i class="bi bi-image d-block mb-1 fs-4 opacity-25"></i>Tidak ada foto</div>
            <?php endif; ?>
          </div>
          <div class="col-6">
            <div class="fw-semibold small mb-1 text-muted">Foto Kartu Keluarga</div>
            <?php
            $kkPath    = $detailReg['foto_kk'] ?? null;
            $kkAbsPath = $kkPath ? __DIR__ . '/../uploads/' . $kkPath : null;
            $kkUrl     = $kkPath ? '../uploads/' . $kkPath : null;
            if ($kkAbsPath && file_exists($kkAbsPath) && strpos($kkPath,'.pdf')===false): ?>
            <a href="<?=$kkUrl?>" target="_blank">
              <img src="<?=$kkUrl?>" class="img-thumbnail w-100" style="max-height:160px;object-fit:cover" alt="Foto KK">
            </a>
            <div class="text-center mt-1"><a href="<?=$kkUrl?>" target="_blank" class="btn btn-sm btn-outline-success w-100"><i class="bi bi-eye me-1"></i>Lihat Penuh</a></div>
            <?php elseif ($kkAbsPath && file_exists($kkAbsPath) && strpos($kkPath,'.pdf')!==false): ?>
            <a href="<?=$kkUrl?>" target="_blank" class="btn btn-outline-secondary w-100">
              <i class="bi bi-file-pdf me-1"></i>Lihat PDF KK
            </a>
            <?php else: ?>
            <div class="alert alert-secondary small text-center py-3"><i class="bi bi-image d-block mb-1 fs-4 opacity-25"></i>Tidak ada foto</div>
            <?php endif; ?>
          </div>
        </div>
        <?php if ($detailReg['status'] === 'menunggu'): ?>
        <hr class="my-3">
        <h6 class="fw-bold mb-3"><i class="bi bi-check2-square me-1"></i>Tindakan</h6>
        <form method="POST">
          <input type="hidden" name="id" value="<?= $detailReg['id'] ?>">
          <div class="mb-3">
            <label class="form-label fw-semibold small">Catatan (opsional)</label>
            <textarea name="catatan" class="form-control" rows="2"
                      placeholder="Alasan ditolak atau pesan untuk warga..."></textarea>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" name="status" value="disetujui" class="btn btn-success flex-fill"
                    onclick="return confirm('Setujui registrasi ini dan aktifkan akun warga?')">
              <i class="bi bi-check-circle me-1"></i>Setujui
            </button>
            <button type="submit" name="status" value="ditolak" class="btn btn-danger flex-fill"
                    onclick="return confirm('Tolak registrasi ini?')">
              <i class="bi bi-x-circle me-1"></i>Tolak
            </button>
          </div>
        </form>
        <?php endif; ?>
      </div>

      <!-- Data Detail -->
      <div class="col-md-7">
        <h6 class="fw-bold mb-2"><i class="bi bi-person me-1"></i>Data Pribadi</h6>
        <?php
        $fields = [
          'Nama Lengkap'    => $detailReg['nama'],
          'Username'        => '@'.$detailReg['username'],
          'No. HP'          => $detailReg['no_hp']?:'-',
          'Email'           => $detailReg['email']?:'-',
          'NIK'             => '<code>'.$detailReg['nik'].'</code>',
          'Jenis Kelamin'   => $detailReg['jenis_kelamin']==='L'?'Laki-laki':'Perempuan',
          'Tempat, Tgl Lahir'=> ($detailReg['tempat_lahir']?:'-').', '.($detailReg['tanggal_lahir']?formatTanggal($detailReg['tanggal_lahir']):'-'),
          'Agama'           => $detailReg['agama'],
          'Status Kawin'    => $detailReg['status_kawin'],
          'Hubungan KK'     => $detailReg['status_hubungan'],
          'Pekerjaan'       => $detailReg['pekerjaan']?:'-',
          'Pendidikan'      => $detailReg['pendidikan'],
        ];
        ?>
        <table class="table table-sm table-borderless small">
          <?php foreach($fields as $lb=>$val): ?>
          <tr class="border-bottom"><td class="text-muted" style="width:40%"><?=$lb?></td><td><?=$val?></td></tr>
          <?php endforeach; ?>
        </table>

        <h6 class="fw-bold mb-2 mt-2"><i class="bi bi-house me-1"></i>Data KK & Alamat</h6>
        <?php
        $fields2 = [
          'No. KK'          => '<code>'.$detailReg['no_kk'].'</code>',
          'Nama Kepala KK'  => $detailReg['nama_kepala_kk']?:'-',
          'Jml Anggota KK'  => $detailReg['jumlah_keluarga'].' orang',
          'Alamat'          => $detailReg['alamat'],
          'RT / RW'         => $detailReg['no_rt'].' / '.$detailReg['no_rw'],
          'Kel / Kec'       => $detailReg['kelurahan'].', '.$detailReg['kecamatan'],
          'Kab / Prov'      => $detailReg['kabupaten'].', '.$detailReg['provinsi'],
          'Kode Pos'        => $detailReg['kode_pos'],
          'Tgl Daftar'      => formatTanggal(date('Y-m-d',strtotime($detailReg['created_at']))),
          'Status'          => statusBadge($detailReg['status']),
        ];
        ?>
        <table class="table table-sm table-borderless small">
          <?php foreach($fields2 as $lb=>$val): ?>
          <tr class="border-bottom"><td class="text-muted" style="width:40%"><?=$lb?></td><td><?=$val?></td></tr>
          <?php endforeach; ?>
        </table>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Tabel Daftar -->
<div class="card">
  <div class="card-header"><i class="bi bi-list-ul me-1"></i>
    Daftar Registrasi — <?= ucfirst($tab) ?> (<?= count($list) ?>)
  </div>
  <?php if (empty($list)): ?>
  <div class="card-body text-center text-muted py-5">
    <i class="bi bi-inbox fs-1 d-block mb-2 opacity-25"></i>
    Tidak ada registrasi berstatus <strong><?= $tab ?></strong>.
  </div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0 small">
      <thead class="table-light">
        <tr><th>Nama</th><th>Username</th><th>NIK</th><th>No. HP</th><th>Dokumen</th><th>Tgl Daftar</th><th>Status</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($list as $r): ?>
        <tr class="<?= !$r['foto_ktp'] || !$r['foto_kk'] ? 'table-warning' : '' ?>">
          <td class="fw-semibold"><?= clean($r['nama']) ?></td>
          <td class="text-muted">@<?= clean($r['username']) ?></td>
          <td class="font-monospace text-muted" style="font-size:.75rem"><?= clean($r['nik']) ?></td>
          <td><?= clean($r['no_hp']?:'-') ?></td>
          <td>
            <?php if ($r['foto_ktp'] && $r['foto_kk']): ?>
            <span class="badge bg-success"><i class="bi bi-check2 me-1"></i>Lengkap</span>
            <?php elseif ($r['foto_ktp'] || $r['foto_kk']): ?>
            <span class="badge bg-warning text-dark"><i class="bi bi-exclamation me-1"></i>Sebagian</span>
            <?php else: ?>
            <span class="badge bg-danger"><i class="bi bi-x me-1"></i>Tidak Ada</span>
            <?php endif; ?>
          </td>
          <td><?= formatTanggal(date('Y-m-d',strtotime($r['created_at']))) ?></td>
          <td><?= statusBadge($r['status']) ?></td>
          <td>
            <a href="?tab=<?=$tab?>&detail=<?=$r['id']?>" class="btn btn-sm btn-outline-primary">
              <i class="bi bi-eye me-1"></i>Detail
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php
echo "</div></div></div>"; // close col, row, container-fluid
include __DIR__ . '/../includes/footer.php'; ?>
