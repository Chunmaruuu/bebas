<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Dashboard Admin';
$basePath  = '..';
$pdo       = getDB();

// Statistik utama
$totalPenduduk  = $pdo->query("SELECT COUNT(*) FROM penduduk WHERE status='aktif'")->fetchColumn();
$totalPindah    = $pdo->query("SELECT COUNT(*) FROM laporan_pindah")->fetchColumn();
$totalDatang    = $pdo->query("SELECT COUNT(*) FROM laporan_datang")->fetchColumn();
$totalTamu      = $pdo->query("SELECT COUNT(*) FROM laporan_tamu WHERE status='menginap'")->fetchColumn();
$totalPending   = $pdo->query("SELECT COUNT(*) FROM laporan_pindah WHERE status='pending'")->fetchColumn()
                + $pdo->query("SELECT COUNT(*) FROM laporan_datang WHERE status='pending'")->fetchColumn();

// Data untuk chart: penduduk per bulan (simulasi dari created_at)
$chartBulan = $pdo->query(
    "SELECT DATE_FORMAT(created_at,'%b') as bln, COUNT(*) as jumlah
     FROM penduduk GROUP BY MONTH(created_at) ORDER BY MONTH(created_at)"
)->fetchAll();

// Gender chart
$laki   = $pdo->query("SELECT COUNT(*) FROM penduduk WHERE jenis_kelamin='L' AND status='aktif'")->fetchColumn();
$perempuan = $pdo->query("SELECT COUNT(*) FROM penduduk WHERE jenis_kelamin='P' AND status='aktif'")->fetchColumn();

// Laporan terbaru
$laporanTerbaru = $pdo->query(
    "SELECT 'Pindah' as jenis, p.nama, lp.status, lp.created_at
     FROM laporan_pindah lp JOIN penduduk p ON lp.penduduk_id=p.id
     UNION ALL
     SELECT 'Datang', nama, status, created_at FROM laporan_datang
     ORDER BY created_at DESC LIMIT 6"
)->fetchAll();

// Tamu aktif
$tamuAktif = $pdo->query(
    "SELECT lt.*, pd.nama as nama_pemilik FROM laporan_tamu lt
     JOIN penduduk pd ON lt.penduduk_id=pd.id
     WHERE lt.status='menginap' ORDER BY lt.tanggal_datang DESC LIMIT 5"
)->fetchAll();

$chartData = json_encode([
    'bulan'     => array_column($chartBulan, 'bln'),
    'jumlah'    => array_column($chartBulan, 'jumlah'),
    'gender'    => [$laki, $perempuan],
    'laporan'   => [$totalPindah, $totalDatang, $totalTamu],
]);

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <!-- SIDEBAR -->
    <div class="col-md-2 sidebar d-none d-md-block">
      <?php include __DIR__ . '/sidebar.php'; ?>
    </div>

    <!-- MAIN -->
    <div class="col-md-10 py-4 px-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h4 class="fw-bold mb-0">Dashboard</h4>
          <small class="text-muted">Selamat datang, <?= clean(currentUser()['nama']) ?></small>
        </div>
        <div>
          <?php if ($totalPending > 0): ?>
          <a href="laporan.php" class="btn btn-warning btn-sm">
            <i class="bi bi-clock-history"></i>
            <?= $totalPending ?> laporan menunggu
          </a>
          <?php endif; ?>
        </div>
      </div>

      <?= flashHtml() ?>

      <!-- STAT CARDS -->
      <div class="row g-3 mb-4">
        <?php
        $stats = [
          ['label'=>'Penduduk Aktif','val'=>$totalPenduduk,'icon'=>'bi-people-fill','cls'=>'stat-sage'],
          ['label'=>'Laporan Pindah','val'=>$totalPindah,  'icon'=>'bi-arrow-right-square-fill','cls'=>'stat-lavender'],
          ['label'=>'Laporan Datang','val'=>$totalDatang,  'icon'=>'bi-arrow-left-square-fill', 'cls'=>'stat-gold'],
          ['label'=>'Tamu Menginap', 'val'=>$totalTamu,    'icon'=>'bi-person-plus-fill',       'cls'=>'stat-sage'],
        ];
        foreach ($stats as $s): ?>
        <div class="col-6 col-md-3">
          <div class="stat-card <?= $s['cls'] ?>">
            <h6><?= $s['label'] ?></h6>
            <div class="display-6"><?= $s['val'] ?></div>
            <div class="icon"><i class="bi <?= $s['icon'] ?>"></i></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- CHARTS -->
      <div class="row g-4 mb-4">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
              <i class="bi bi-bar-chart text-success"></i>
              <span style="font-family:'Cinzel',serif;font-size:.85rem;letter-spacing:.04em">Distribusi Penduduk per Bulan Registrasi</span>
            </div>
            <div class="card-body">
              <canvas id="chartPenduduk" height="120"></canvas>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <i class="bi bi-pie-chart text-primary"></i>
              <span style="font-family:'Cinzel',serif;font-size:.85rem;letter-spacing:.04em">Komposisi Gender</span>
            </div>
            <div class="card-body d-flex flex-column align-items-center">
              <canvas id="chartGender" height="180"></canvas>
              <div class="d-flex gap-3 mt-2 small">
                <span><span class="badge" style="background:var(--fr-sage)">L</span> <?= $laki ?> jiwa</span>
                <span><span class="badge" style="background:#e75480">P</span> <?= $perempuan ?> jiwa</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- CHART LAPORAN + TABEL -->
      <div class="row g-4">
        <div class="col-md-5">
          <div class="card">
            <div class="card-header">
              <i class="bi bi-graph-up text-warning"></i>
              <span style="font-family:'Cinzel',serif;font-size:.85rem;letter-spacing:.04em">Rekap Laporan</span>
            </div>
            <div class="card-body">
              <canvas id="chartLaporan" height="200"></canvas>
            </div>
          </div>
        </div>
        <div class="col-md-7">
          <div class="card">
            <div class="card-header d-flex justify-content-between">
              <span><i class="bi bi-clock-history text-danger"></i> <strong>Laporan Terbaru</span></span>
              <a href="laporan.php" class="btn btn-sm btn-outline-primary">Kelola</a>
            </div>
            <div class="card-body p-0">
              <table class="table table-hover mb-0">
                <thead>
                  <tr><th>Jenis</th><th>Nama</th><th>Status</th><th>Tanggal</th></tr>
                </thead>
                <tbody>
                  <?php foreach ($laporanTerbaru as $l): ?>
                  <tr>
                    <td><span class="badge <?= $l['jenis']==='Pindah' ? 'bg-warning text-dark' : 'bg-primary' ?>">
                      <?= $l['jenis'] ?></span></td>
                    <td class="small"><?= clean($l['nama']) ?></td>
                    <td><?= statusBadge($l['status']) ?></td>
                    <td class="small text-muted"><?= formatTanggal(date('Y-m-d', strtotime($l['created_at']))) ?></td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- TAMU AKTIF -->
      <?php if (!empty($tamuAktif)): ?>
      <div class="card mt-4">
        <div class="card-header">
          <i class="bi bi-person-check text-purple"></i>
          <span style="font-family:'Cinzel',serif;font-size:.85rem;letter-spacing:.04em">Tamu Sedang Menginap</span>
        </div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0">
            <thead><tr><th>Nama Tamu</th><th>Di Rumah</th><th>Hubungan</th><th>Tgl Datang</th><th>Keperluan</th></tr></thead>
            <tbody>
              <?php foreach ($tamuAktif as $t): ?>
              <tr>
                <td class="fw-600 small"><?= clean($t['nama_tamu']) ?></td>
                <td class="small"><?= clean($t['nama_pemilik']) ?></td>
                <td class="small"><?= clean($t['hubungan']) ?></td>
                <td class="small text-muted"><?= formatTanggal($t['tanggal_datang']) ?></td>
                <td class="small text-muted"><?= mb_substr(clean($t['keperluan'] ?? '-'), 0, 40) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$extraJs = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
const d = ' . $chartData . ';
Chart.defaults.font.family = "Crimson Pro, sans-serif";
Chart.defaults.font.size   = 12;

// Chart penduduk per bulan
new Chart(document.getElementById("chartPenduduk"), {
  type: "bar",
  data: {
    labels: d.bulan.length ? d.bulan : ["Jan","Feb","Mar","Apr","Mei","Jun"],
    datasets: [{
      label: "Jumlah Penduduk",
      data: d.jumlah.length ? d.jumlah : [5,8,12,10,7,9],
      backgroundColor: "rgba(26,107,58,.75)",
      borderRadius: 6,
    }]
  },
  options: { responsive:true, plugins:{ legend:{display:false} }, scales:{ y:{beginAtZero:true,ticks:{stepSize:1}} } }
});

// Chart gender (doughnut)
new Chart(document.getElementById("chartGender"), {
  type: "doughnut",
  data: {
    labels: ["Laki-laki","Perempuan"],
    datasets: [{ data: d.gender, backgroundColor:["#5f7a5e","#e75480"], borderWidth:0 }]
  },
  options: { cutout:"65%", plugins:{ legend:{display:false} } }
});

// Chart laporan (horizontal bar)
new Chart(document.getElementById("chartLaporan"), {
  type: "bar",
  data: {
    labels: ["Pindah","Datang","Tamu"],
    datasets: [{
      data: d.laporan,
      backgroundColor: ["#f59e0b","#8b7fa8","#7c3aed"],
      borderRadius: 6,
    }]
  },
  options: {
    indexAxis: "y", responsive:true,
    plugins:{ legend:{display:false} },
    scales:{ x:{beginAtZero:true,ticks:{stepSize:1}} }
  }
});
</script>';
include __DIR__ . '/../includes/footer.php'; ?>
