<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Data Penduduk';
$basePath  = '..';
$pdo       = getDB();
$action    = $_GET['action'] ?? 'list';
$id        = intval($_GET['id'] ?? 0);
$error     = '';

// ---- DELETE ----
if ($action === 'delete' && $id) {
    $pdo->prepare("DELETE FROM penduduk WHERE id=?")->execute([$id]);
    setFlash('success', 'Data penduduk berhasil dihapus.');
    redirect('penduduk.php');
}

// ---- SAVE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nik'             => trim($_POST['nik']),
        'no_kk'           => trim($_POST['no_kk']),
        'nama'            => trim($_POST['nama']),
        'jenis_kelamin'   => $_POST['jenis_kelamin'],
        'tempat_lahir'    => trim($_POST['tempat_lahir']),
        'tanggal_lahir'   => $_POST['tanggal_lahir'],
        'agama'           => $_POST['agama'],
        'status_kawin'    => $_POST['status_kawin'],
        'status_hubungan' => $_POST['status_hubungan'],
        'pekerjaan'       => trim($_POST['pekerjaan']),
        'pendidikan'      => $_POST['pendidikan'],
        'alamat'          => trim($_POST['alamat']),
        'no_rt'           => trim($_POST['no_rt'] ?: '001'),
        'no_rw'           => trim($_POST['no_rw'] ?: '003'),
        'kode_pos'        => trim($_POST['kode_pos']),
        'kelurahan'       => trim($_POST['kelurahan'] ?: 'Maguwoharjo'),
        'kecamatan'       => trim($_POST['kecamatan'] ?: 'Depok'),
        'kabupaten'       => trim($_POST['kabupaten'] ?: 'Sleman'),
        'provinsi'        => trim($_POST['provinsi'] ?: 'D.I. Yogyakarta'),
    ];

    if (strlen($data['nik']) !== 16)  { $error = 'NIK harus 16 digit.'; }
    elseif (!$data['nama'])           { $error = 'Nama wajib diisi.'; }
    elseif (!$data['alamat'])         { $error = 'Alamat wajib diisi.'; }
    else {
        if ($id) {
            $cols = implode(', ', array_map(fn($k) => "$k=:$k", array_keys($data)));
            $data['id'] = $id;
            $pdo->prepare("UPDATE penduduk SET $cols WHERE id=:id")->execute($data);
        } else {
            $cols = implode(', ', array_keys($data));
            $vals = implode(', ', array_map(fn($k) => ":$k", array_keys($data)));
            $pdo->prepare("INSERT INTO penduduk ($cols) VALUES ($vals)")->execute($data);
        }
        setFlash('success', $id ? 'Data berhasil diperbarui.' : 'Penduduk baru berhasil ditambahkan.');
        redirect('penduduk.php');
    }
}

// ---- EDIT DATA ----
$editData = [];
if (in_array($action, ['edit']) && $id) {
    $stmt = $pdo->prepare("SELECT * FROM penduduk WHERE id=?");
    $stmt->execute([$id]);
    $editData = $stmt->fetch();
}

// ---- LIST ----
$search = clean($_GET['q'] ?? '');
$where  = $search ? "WHERE nama LIKE :nama OR nik LIKE :nik OR no_kk LIKE :no_kk" : "";
$stmt   = $pdo->prepare("SELECT * FROM penduduk $where ORDER BY nama");
$stmt->execute($search ? [
    ':nama'  => "%$search%",
    ':nik'   => "%$search%",
    ':no_kk' => "%$search%"
] : []);
$pendudukList = $stmt->fetchAll();

$agamaOpts    = ['Islam','Kawin','Belum Kawin','Kristen','Katolik','Hindu','Buddha','Konghucu'];
$agamaList    = ['Islam','Kristen','Katolik','Hindu','Buddha','Konghucu'];
$kawinList    = ['Belum Kawin','Kawin','Cerai Hidup','Cerai Mati'];
$hubList      = ['Kepala Keluarga','Istri','Anak','Orang Tua','Mertua','Cucu','Lainnya'];
$pendidList   = ['Tidak Sekolah','SD','SMP','SMA/SMK','D1/D2/D3','S1','S2/S3'];

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar d-none d-md-block"><?php include 'sidebar.php'; ?></div>
    <div class="col-md-10 py-4 px-4">

      <?= flashHtml() ?>

      <?php if ($action === 'list'): ?>
      <!-- ── LIST ── -->
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0"><i class="bi bi-people text-success"></i> Data Penduduk</h4>
        <a href="?action=add" class="btn btn-rt">
          <i class="bi bi-plus-lg"></i> Tambah Penduduk
        </a>
      </div>
      <div class="card">
        <div class="card-body">
          <form class="d-flex gap-2 mb-3" method="GET">
            <input type="hidden" name="action" value="list">
            <input type="text" name="q" class="form-control form-control-sm" style="max-width:300px"
                   placeholder="Cari nama / NIK / No. KK..." value="<?= $search ?>">
            <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i> Cari</button>
            <?php if ($search): ?>
            <a href="penduduk.php" class="btn btn-sm btn-outline-danger">
              <i class="bi bi-x"></i> Reset
            </a>
            <?php endif; ?>
          </form>
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead>
                <tr>
                  <th>#</th><th>NIK</th><th>No. KK</th><th>Nama</th>
                  <th>JK</th><th>RT/RW</th><th>Kode Pos</th><th>Pekerjaan</th><th>Status</th><th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pendudukList as $i => $p): ?>
                <tr>
                  <td class="small text-muted"><?= $i+1 ?></td>
                  <td><code class="small"><?= clean($p['nik']) ?></code></td>
                  <td><code class="small"><?= clean($p['no_kk'] ?: '-') ?></code></td>
                  <td>
                    <div class="fw-600"><?= clean($p['nama']) ?></div>
                    <div class="text-muted" style="font-size:.75rem"><?= clean($p['status_hubungan'] ?? '') ?></div>
                  </td>
                  <td><?= $p['jenis_kelamin'] === 'L' ? '<span class="badge bg-primary">L</span>' : '<span class="badge bg-pink" style="background:#e75480">P</span>' ?></td>
                  <td class="small"><?= clean($p['no_rt']) ?>/<?= clean($p['no_rw']) ?></td>
                  <td class="small text-muted"><?= clean($p['kode_pos'] ?: '-') ?></td>
                  <td class="small text-muted"><?= clean($p['pekerjaan'] ?: '-') ?></td>
                  <td><?= statusBadge($p['status']) ?></td>
                  <td>
                    <a href="?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                      <i class="bi bi-pencil"></i>
                    </a>
                    <a href="?action=delete&id=<?= $p['id'] ?>"
                       class="btn btn-sm btn-outline-danger" title="Hapus"
                       onclick="return confirm('Hapus data <?= clean($p['nama']) ?>?')">
                      <i class="bi bi-trash"></i>
                    </a>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($pendudukList)): ?>
                <tr>
                  <td colspan="10" class="text-center text-muted py-4">
                    <i class="bi bi-search fs-3 d-block mb-2 opacity-25"></i>
                    Tidak ada data ditemukan.
                  </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <small class="text-muted">Total: <?= count($pendudukList) ?> data</small>
        </div>
      </div>

      <?php else: ?>
      <!-- ── FORM ADD/EDIT ── -->
      <div class="d-flex align-items-center gap-3 mb-3">
        <a href="penduduk.php" class="btn btn-sm btn-outline-secondary">
          <i class="bi bi-arrow-left"></i>
        </a>
        <h4 class="fw-bold mb-0"><?= $id ? 'Edit' : 'Tambah' ?> Data Penduduk</h4>
      </div>
      <?php if ($error): ?>
      <div class="alert alert-danger small"><i class="bi bi-exclamation-circle"></i> <?= $error ?></div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <form method="POST">

            <!-- Seksi 1: Identitas -->
            <div class="section-divider">
              <span><i class="bi bi-person-vcard text-primary"></i> Identitas Kependudukan</span>
            </div>
            <div class="row g-3 mb-4">
              <div class="col-md-6">
                <label class="form-label fw-600 small">NIK <span class="text-danger">*</span></label>
                <input type="text" name="nik" class="form-control font-monospace"
                       maxlength="16" placeholder="16 digit NIK"
                       value="<?= clean($editData['nik'] ?? $_POST['nik'] ?? '') ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-600 small">No. Kartu Keluarga</label>
                <input type="text" name="no_kk" class="form-control font-monospace"
                       maxlength="16" placeholder="16 digit No. KK"
                       value="<?= clean($editData['no_kk'] ?? $_POST['no_kk'] ?? '') ?>">
              </div>
              <div class="col-md-8">
                <label class="form-label fw-600 small">Nama Lengkap <span class="text-danger">*</span></label>
                <input type="text" name="nama" class="form-control"
                       value="<?= clean($editData['nama'] ?? $_POST['nama'] ?? '') ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-select">
                  <option value="L" <?= ($editData['jenis_kelamin'] ?? 'L') === 'L' ? 'selected' : '' ?>>Laki-laki</option>
                  <option value="P" <?= ($editData['jenis_kelamin'] ?? '') === 'P' ? 'selected' : '' ?>>Perempuan</option>
                </select>
              </div>
              <div class="col-md-5">
                <label class="form-label fw-600 small">Tempat Lahir</label>
                <input type="text" name="tempat_lahir" class="form-control"
                       value="<?= clean($editData['tempat_lahir'] ?? '') ?>">
              </div>
              <div class="col-md-3">
                <label class="form-label fw-600 small">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" class="form-control"
                       value="<?= clean($editData['tanggal_lahir'] ?? '') ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Agama</label>
                <select name="agama" class="form-select">
                  <?php foreach ($agamaList as $ag): ?>
                  <option value="<?= $ag ?>" <?= ($editData['agama'] ?? 'Islam') === $ag ? 'selected' : '' ?>><?= $ag ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Status Kawin</label>
                <select name="status_kawin" class="form-select">
                  <?php foreach ($kawinList as $sk): ?>
                  <option value="<?= $sk ?>" <?= ($editData['status_kawin'] ?? 'Belum Kawin') === $sk ? 'selected' : '' ?>><?= $sk ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Hubungan dalam KK</label>
                <select name="status_hubungan" class="form-select">
                  <?php foreach ($hubList as $h): ?>
                  <option value="<?= $h ?>" <?= ($editData['status_hubungan'] ?? 'Kepala Keluarga') === $h ? 'selected' : '' ?>><?= $h ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label fw-600 small">Pekerjaan</label>
                <input type="text" name="pekerjaan" class="form-control"
                       value="<?= clean($editData['pekerjaan'] ?? '') ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label fw-600 small">Pendidikan Terakhir</label>
                <select name="pendidikan" class="form-select">
                  <?php foreach ($pendidList as $pd): ?>
                  <option value="<?= $pd ?>" <?= ($editData['pendidikan'] ?? 'SMA/SMK') === $pd ? 'selected' : '' ?>><?= $pd ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <!-- Seksi 2: Alamat -->
            <div class="section-divider">
              <span><i class="bi bi-house text-success"></i> Alamat Tempat Tinggal</span>
            </div>
            <div class="row g-3">
              <div class="col-12">
                <label class="form-label fw-600 small">Alamat Lengkap <span class="text-danger">*</span></label>
                <textarea name="alamat" class="form-control" rows="2" required><?= clean($editData['alamat'] ?? '') ?></textarea>
              </div>
              <div class="col-md-2">
                <label class="form-label fw-600 small">No. RT</label>
                <input type="text" name="no_rt" class="form-control font-monospace"
                       maxlength="5" value="<?= clean($editData['no_rt'] ?? '001') ?>">
              </div>
              <div class="col-md-2">
                <label class="form-label fw-600 small">No. RW</label>
                <input type="text" name="no_rw" class="form-control font-monospace"
                       maxlength="5" value="<?= clean($editData['no_rw'] ?? '003') ?>">
              </div>
              <div class="col-md-3">
                <label class="form-label fw-600 small">Kode Pos</label>
                <input type="text" name="kode_pos" class="form-control font-monospace"
                       maxlength="10" placeholder="55282"
                       value="<?= clean($editData['kode_pos'] ?? '') ?>">
              </div>
              <div class="col-md-5">
                <label class="form-label fw-600 small">Kelurahan / Desa</label>
                <input type="text" name="kelurahan" class="form-control"
                       value="<?= clean($editData['kelurahan'] ?? 'Maguwoharjo') ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Kecamatan</label>
                <input type="text" name="kecamatan" class="form-control"
                       value="<?= clean($editData['kecamatan'] ?? 'Depok') ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Kabupaten / Kota</label>
                <input type="text" name="kabupaten" class="form-control"
                       value="<?= clean($editData['kabupaten'] ?? 'Sleman') ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-600 small">Provinsi</label>
                <input type="text" name="provinsi" class="form-control"
                       value="<?= clean($editData['provinsi'] ?? 'D.I. Yogyakarta') ?>">
              </div>
              <div class="col-12 d-flex gap-2 mt-2">
                <button type="submit" class="btn btn-rt px-4">
                  <i class="bi bi-save"></i> Simpan Data
                </button>
                <a href="penduduk.php" class="btn btn-outline-secondary">Batal</a>
              </div>
            </div>
          </form>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<style>
.section-divider {
  display: flex; align-items: center; gap: .75rem;
  font-size: .78rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: .07em; color: #555;
  margin: .5rem 0 1rem;
}
.section-divider::after {
  content: ''; flex: 1; height: 1px; background: #e5e7eb;
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
