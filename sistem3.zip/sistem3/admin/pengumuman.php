<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Pengumuman';
$basePath  = '..';
$pdo       = getDB();
$action    = $_GET['action'] ?? 'list';
$id        = intval($_GET['id'] ?? 0);
$error     = '';

// ─── Kategori & Warna ────────────────────────────────────────
$kategoriList = ['sosial','keamanan','kesehatan','lingkungan','laporan_keuangan','lainnya'];
$bColors = [
    'sosial'           => 'primary',
    'keamanan'         => 'danger',
    'kesehatan'        => 'success',
    'lingkungan'       => 'success',
    'laporan_keuangan' => 'warning',
    'lainnya'          => 'info',
];
$bLabels = [
    'sosial'           => 'Sosial',
    'keamanan'         => 'Keamanan',
    'kesehatan'        => 'Kesehatan',
    'lingkungan'       => 'Lingkungan',
    'laporan_keuangan' => 'Laporan Keuangan',
    'lainnya'          => 'Lainnya',
];

// ─── Hapus Pengumuman ────────────────────────────────────────
if ($action === 'delete' && $id) {
    // Hapus file PDF jika ada
    $row = $pdo->prepare("SELECT file_pdf FROM pengumuman WHERE id=?");
    $row->execute([$id]);
    $data = $row->fetch();
    if (!empty($data['file_pdf'])) {
        $path = __DIR__ . '/../uploads/pengumuman/' . $data['file_pdf'];
        if (file_exists($path)) unlink($path);
    }
    $pdo->prepare("DELETE FROM pengumuman WHERE id=?")->execute([$id]);
    setFlash('success', 'Pengumuman dihapus.');
    redirect('pengumuman.php');
}

// ─── Simpan / Edit ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul    = trim($_POST['judul'] ?? '');
    $isi      = trim($_POST['isi'] ?? '');
    $kategori = $_POST['kategori'] ?? 'sosial';
    $uid      = currentUser()['id'];

    if (!in_array($kategori, $kategoriList)) $kategori = 'sosial';

    if (!$judul || !$isi) {
        $error = 'Judul dan isi wajib diisi.';
    } else {
        // ── Proses Upload PDF ─────────────────────────────────
        $filePdf   = null;
        $hapusPdf  = isset($_POST['hapus_pdf']) && $_POST['hapus_pdf'] === '1';

        if (isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] === UPLOAD_ERR_OK) {
            $file     = $_FILES['file_pdf'];
            $maxSize  = 5 * 1024 * 1024; // 5 MB
            $mimeOk   = $file['type'] === 'application/pdf';
            $sizeOk   = $file['size'] <= $maxSize;
            $extOk    = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) === 'pdf';

            if (!$mimeOk || !$extOk) {
                $error = 'File harus berformat PDF.';
            } elseif (!$sizeOk) {
                $error = 'Ukuran file PDF maksimal 5 MB.';
            } else {
                $uploadDir = __DIR__ . '/../uploads/pengumuman/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0750, true);

                // Hapus PDF lama jika edit
                if ($id) {
                    $oldRow = $pdo->prepare("SELECT file_pdf FROM pengumuman WHERE id=?");
                    $oldRow->execute([$id]);
                    $oldData = $oldRow->fetch();
                    if (!empty($oldData['file_pdf'])) {
                        $oldPath = $uploadDir . $oldData['file_pdf'];
                        if (file_exists($oldPath)) unlink($oldPath);
                    }
                }

                $safeName = 'pengumuman_' . time() . '_' . bin2hex(random_bytes(4)) . '.pdf';
                if (move_uploaded_file($file['tmp_name'], $uploadDir . $safeName)) {
                    $filePdf = $safeName;
                } else {
                    $error = 'Gagal menyimpan file PDF. Coba lagi.';
                }
            }
        }

        if (!$error) {
            if ($id) {
                // Edit
                if ($filePdf) {
                    // PDF baru diupload
                    $pdo->prepare("UPDATE pengumuman SET judul=?,isi=?,kategori=?,file_pdf=? WHERE id=?")
                        ->execute([$judul, $isi, $kategori, $filePdf, $id]);
                } elseif ($hapusPdf) {
                    // Hapus PDF tanpa upload baru
                    $oldRow = $pdo->prepare("SELECT file_pdf FROM pengumuman WHERE id=?");
                    $oldRow->execute([$id]);
                    $oldData = $oldRow->fetch();
                    if (!empty($oldData['file_pdf'])) {
                        $oldPath = __DIR__ . '/../uploads/pengumuman/' . $oldData['file_pdf'];
                        if (file_exists($oldPath)) unlink($oldPath);
                    }
                    $pdo->prepare("UPDATE pengumuman SET judul=?,isi=?,kategori=?,file_pdf=NULL WHERE id=?")
                        ->execute([$judul, $isi, $kategori, $id]);
                } else {
                    // Tidak ada perubahan PDF
                    $pdo->prepare("UPDATE pengumuman SET judul=?,isi=?,kategori=? WHERE id=?")
                        ->execute([$judul, $isi, $kategori, $id]);
                }
            } else {
                // Tambah baru
                $pdo->prepare("INSERT INTO pengumuman (judul,isi,kategori,file_pdf,dibuat_oleh) VALUES (?,?,?,?,?)")
                    ->execute([$judul, $isi, $kategori, $filePdf, $uid]);
            }
            setFlash('success', 'Pengumuman berhasil disimpan.');
            redirect('pengumuman.php');
        }
    }
}

// ─── Load data edit ──────────────────────────────────────────
$editData = [];
if ($action === 'edit' && $id) {
    $stmt = $pdo->prepare("SELECT * FROM pengumuman WHERE id=?");
    $stmt->execute([$id]);
    $editData = $stmt->fetch();
}

$pengList = $pdo->query(
    "SELECT p.*, u.nama as penulis FROM pengumuman p LEFT JOIN users u ON p.dibuat_oleh=u.id ORDER BY p.created_at DESC"
)->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar d-none d-md-block"><?php include 'sidebar.php'; ?></div>
    <div class="col-md-10 py-4 px-4">
      <?= flashHtml() ?>

      <?php if ($action === 'list'): ?>
      <!-- ═══════════════════════════════════════════════════════
           LIST PENGUMUMAN
      ═══════════════════════════════════════════════════════ -->
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0"><i class="bi bi-megaphone text-warning"></i> Pengumuman</h4>
        <a href="?action=add" class="btn btn-rt"><i class="bi bi-plus-lg"></i> Buat Pengumuman</a>
      </div>

      <div class="row g-3">
        <?php foreach ($pengList as $p):
          $bc    = $bColors[$p['kategori']] ?? 'secondary';
          $label = $bLabels[$p['kategori']] ?? ucfirst($p['kategori']);
          $isKeu = $p['kategori'] === 'laporan_keuangan';
        ?>
        <div class="col-md-6">
          <div class="card h-100 <?= $isKeu ? 'border-warning' : '' ?>">
            <?php if ($isKeu): ?>
            <div class="card-header bg-warning bg-opacity-10 border-bottom border-warning py-2 d-flex align-items-center gap-2">
              <i class="bi bi-cash-coin text-warning"></i>
              <small class="fw-semibold text-warning-emphasis">Laporan Keuangan RT</small>
            </div>
            <?php endif; ?>
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="badge bg-<?= $bc ?>"><?= $label ?></span>
                <small class="text-muted"><?= formatTanggal(date('Y-m-d', strtotime($p['created_at']))) ?></small>
              </div>
              <h6 class="fw-bold"><?= clean($p['judul']) ?></h6>
              <p class="small text-muted mb-2"><?= nl2br(clean(mb_substr($p['isi'], 0, 120))) ?>…</p>

              <?php if (!empty($p['file_pdf'])): ?>
              <a href="../uploads/pengumuman/<?= clean($p['file_pdf']) ?>"
                 target="_blank" class="badge bg-danger text-decoration-none mb-2">
                <i class="bi bi-file-earmark-pdf"></i> PDF terlampir
              </a>
              <?php endif; ?>

              <div class="d-flex justify-content-between align-items-center mt-2">
                <small class="text-muted"><i class="bi bi-person"></i> <?= clean($p['penulis'] ?? 'Admin') ?></small>
                <div class="d-flex gap-1">
                  <a href="?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-pencil"></i></a>
                  <a href="?action=delete&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger"
                     onclick="return confirm('Hapus pengumuman ini?')">
                    <i class="bi bi-trash"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <?php else: ?>
      <!-- ═══════════════════════════════════════════════════════
           FORM TAMBAH / EDIT
      ═══════════════════════════════════════════════════════ -->
      <div class="d-flex align-items-center gap-3 mb-3">
        <a href="pengumuman.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
        <h4 class="fw-bold mb-0"><?= $id ? 'Edit' : 'Buat' ?> Pengumuman</h4>
      </div>

      <?php if ($error): ?><div class="alert alert-danger small"><?= clean($error) ?></div><?php endif; ?>

      <div class="card">
        <div class="card-body">
          <form method="POST" enctype="multipart/form-data">

            <!-- Judul -->
            <div class="mb-3">
              <label class="form-label fw-semibold small">Judul <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control"
                     value="<?= clean($editData['judul'] ?? '') ?>" required maxlength="200">
            </div>

            <!-- Kategori -->
            <div class="mb-3">
              <label class="form-label fw-semibold small">Kategori</label>
              <select name="kategori" class="form-select" id="kategoriSelect" onchange="onKategoriChange()">
                <?php foreach ($kategoriList as $kat): ?>
                <option value="<?= $kat ?>"
                  <?= ($editData['kategori'] ?? 'sosial') === $kat ? 'selected' : '' ?>>
                  <?= $bLabels[$kat] ?? ucfirst($kat) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>

            <!-- Isi -->
            <div class="mb-3">
              <label class="form-label fw-semibold small">Isi Pengumuman <span class="text-danger">*</span></label>
              <textarea name="isi" class="form-control" rows="6" required><?= clean($editData['isi'] ?? '') ?></textarea>
              <div class="form-text" id="pdfHint" style="display:none">
                <i class="bi bi-info-circle text-warning"></i>
                Untuk Laporan Keuangan, lampirkan file PDF laporan keuangan di bawah.
              </div>
            </div>

            <!-- Upload PDF -->
            <div class="mb-4">
              <label class="form-label fw-semibold small">
                <i class="bi bi-file-earmark-pdf text-danger"></i>
                Lampiran PDF
                <span class="text-muted fw-normal">(opsional, maks. 5 MB)</span>
              </label>

              <?php if (!empty($editData['file_pdf'])): ?>
              <!-- PDF yang sudah ada -->
              <div class="alert alert-light border d-flex align-items-center gap-3 mb-2 py-2">
                <i class="bi bi-file-earmark-pdf fs-4 text-danger"></i>
                <div class="flex-grow-1">
                  <div class="small fw-semibold">PDF saat ini:</div>
                  <a href="../uploads/pengumuman/<?= clean($editData['file_pdf']) ?>"
                     target="_blank" class="small text-danger">
                    <?= clean($editData['file_pdf']) ?>
                  </a>
                </div>
                <div class="form-check mb-0">
                  <input class="form-check-input" type="checkbox" name="hapus_pdf" value="1" id="hapusPdf">
                  <label class="form-check-label small text-danger" for="hapusPdf">Hapus PDF ini</label>
                </div>
              </div>
              <div class="form-text mb-2">Upload PDF baru untuk menggantikan yang lama.</div>
              <?php endif; ?>

              <input type="file" name="file_pdf" class="form-control" accept="application/pdf,.pdf"
                     id="pdfInput">
              <div class="form-text">Format: PDF saja. Ukuran maksimal 5 MB.</div>
            </div>

            <!-- Preview nama file -->
            <div id="pdfPreview" class="alert alert-info small d-none align-items-center gap-2 mb-3">
              <i class="bi bi-file-earmark-pdf text-danger fs-5"></i>
              <span id="pdfFileName"></span>
            </div>

            <div class="d-flex gap-2">
              <button type="submit" class="btn btn-rt px-4"><i class="bi bi-save"></i> Simpan</button>
              <a href="pengumuman.php" class="btn btn-outline-secondary">Batal</a>
            </div>
          </form>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
// Tampilkan hint PDF kalau kategori laporan_keuangan
function onKategoriChange() {
  const val  = document.getElementById('kategoriSelect').value;
  const hint = document.getElementById('pdfHint');
  if (hint) hint.style.display = (val === 'laporan_keuangan') ? 'block' : 'none';
}
// Init saat load
document.addEventListener('DOMContentLoaded', onKategoriChange);

// Preview nama file PDF yang dipilih
document.getElementById('pdfInput')?.addEventListener('change', function () {
  const preview  = document.getElementById('pdfPreview');
  const fileName = document.getElementById('pdfFileName');
  if (this.files.length > 0) {
    fileName.textContent = this.files[0].name;
    preview.classList.remove('d-none');
    preview.classList.add('d-flex');
  } else {
    preview.classList.add('d-none');
    preview.classList.remove('d-flex');
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
