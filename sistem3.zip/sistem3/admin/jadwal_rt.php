<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Jadwal Bertemu RT';
$basePath  = '..';
$pdo       = getDB();

// Proses konfirmasi/tolak/selesai
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jid     = intval($_POST['id']);
    $status  = $_POST['status'];
    $catatan = trim($_POST['catatan'] ?? '');
    $uid     = currentUser()['id'];
    $pdo->prepare("UPDATE jadwal_bertemu_rt SET status=?,catatan_admin=?,diproses_oleh=? WHERE id=?")
        ->execute([$status,$catatan,$uid,$jid]);
    setFlash('success','Status jadwal berhasil diperbarui.');
    redirect('jadwal_rt.php');
}

$tab = $_GET['tab'] ?? 'menunggu';
$list = $pdo->prepare(
    "SELECT j.*, u.nama as nama_warga, u.no_hp as hp_warga
     FROM jadwal_bertemu_rt j
     JOIN users u ON j.user_id=u.id
     WHERE j.status=?
     ORDER BY j.tanggal_pilihan ASC, j.jam_pilihan ASC"
);
$list->execute([$tab]); $list = $list->fetchAll();

$counts = [
    'menunggu'     => $pdo->query("SELECT COUNT(*) FROM jadwal_bertemu_rt WHERE status='menunggu'")->fetchColumn(),
    'dikonfirmasi' => $pdo->query("SELECT COUNT(*) FROM jadwal_bertemu_rt WHERE status='dikonfirmasi'")->fetchColumn(),
    'ditolak'      => $pdo->query("SELECT COUNT(*) FROM jadwal_bertemu_rt WHERE status='ditolak'")->fetchColumn(),
    'selesai'      => $pdo->query("SELECT COUNT(*) FROM jadwal_bertemu_rt WHERE status='selesai'")->fetchColumn(),
];

include __DIR__ . '/../includes/header.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 sidebar d-none d-md-block"><?php include __DIR__ . '/sidebar.php'; ?></div>
<div class="col-md-10 py-4 px-4">

<h4 class="fw-bold mb-4"><i class="bi bi-calendar2-check text-success me-2"></i>Jadwal Bertemu Pak RT</h4>
<?= flashHtml() ?>

<!-- Tabs -->
<div class="d-flex gap-2 mb-4 flex-wrap">
  <?php
  $tabDef = [
    'menunggu'     => ['warning','hourglass-split'],
    'dikonfirmasi' => ['success','check-circle'],
    'ditolak'      => ['danger','x-circle'],
    'selesai'      => ['secondary','check-all'],
  ];
  foreach ($tabDef as $t => [$c,$ic]):?>
  <a href="?tab=<?=$t?>" class="btn btn-<?=$tab===$t?$c:'outline-'.$c?> d-flex align-items-center gap-2">
    <i class="bi bi-<?=$ic?>"></i>
    <?=ucfirst($t)?>
    <span class="badge bg-white text-<?=$c?>"><?=$counts[$t]?></span>
  </a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header"><i class="bi bi-list-ul me-1"></i>Permintaan Jadwal — <?=ucfirst($tab)?> (<?=count($list)?>)</div>
  <?php if (empty($list)): ?>
  <div class="card-body text-center text-muted py-5">
    <i class="bi bi-calendar-x fs-1 d-block mb-2 opacity-25"></i>
    Tidak ada jadwal berstatus <strong><?=$tab?></strong>.
  </div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0 small">
      <thead class="table-light">
        <tr><th>Warga</th><th>No. HP</th><th>Keperluan</th><th>Tanggal</th><th>Jam</th><th>Catatan</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($list as $j): ?>
        <tr>
          <td class="fw-semibold"><?=clean($j['nama_warga'])?></td>
          <td><?=clean($j['hp_warga']?:'-')?></td>
          <td><?=clean($j['keperluan'])?></td>
          <td><?=formatTanggal($j['tanggal_pilihan'])?></td>
          <td><?=substr($j['jam_pilihan'],0,5)?> WIB</td>
          <td class="text-muted" style="max-width:160px">
            <?php if ($j['catatan']): ?><div class="text-truncate" title="<?=clean($j['catatan'])?>"><?=clean($j['catatan'])?></div><?php else: ?>—<?php endif; ?>
            <?php if ($j['catatan_admin']): ?>
            <div class="text-primary mt-1 small"><i class="bi bi-reply me-1"></i><?=clean($j['catatan_admin'])?></div>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($j['status'] === 'menunggu' || $j['status'] === 'dikonfirmasi'): ?>
            <button class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#modalJadwal"
                    data-id="<?=$j['id']?>" data-nama="<?=clean($j['nama_warga'])?>"
                    data-keperluan="<?=clean($j['keperluan'])?>"
                    data-tanggal="<?=formatTanggal($j['tanggal_pilihan'])?>"
                    data-jam="<?=substr($j['jam_pilihan'],0,5)?>">
              <i class="bi bi-pencil"></i> Kelola
            </button>
            <?php elseif ($j['status'] === 'dikonfirmasi'): ?>
            <form method="POST" class="d-inline">
              <input type="hidden" name="id" value="<?=$j['id']?>">
              <input type="hidden" name="status" value="selesai">
              <button type="submit" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Tandai selesai?')">
                <i class="bi bi-check-all"></i> Selesai
              </button>
            </form>
            <?php else: ?>
            <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

</div></div></div>

<!-- Modal kelola jadwal -->
<div class="modal fade" id="modalJadwal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content rounded-3">
      <div class="modal-header">
        <h5 class="modal-title fw-bold"><i class="bi bi-calendar-check me-2"></i>Kelola Jadwal</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <input type="hidden" name="id" id="mId">
          <div class="alert alert-light border small p-3 mb-3">
            <strong id="mNama"></strong><br>
            <span id="mKeperluan" class="text-muted"></span><br>
            <i class="bi bi-calendar3 me-1"></i><span id="mTanggal"></span>
            &nbsp;&bull;&nbsp;
            <i class="bi bi-clock me-1"></i><span id="mJam"></span> WIB
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold small">Keputusan</label>
            <div class="d-flex gap-2">
              <label class="flex-fill border rounded-3 text-center p-3" style="cursor:pointer">
                <input type="radio" name="status" value="dikonfirmasi" class="d-none" checked>
                <i class="bi bi-check-circle-fill d-block mb-1 text-success" style="font-size:1.5rem"></i>
                <span class="small fw-bold text-success">Konfirmasi</span>
              </label>
              <label class="flex-fill border rounded-3 text-center p-3" style="cursor:pointer">
                <input type="radio" name="status" value="selesai" class="d-none">
                <i class="bi bi-check-all d-block mb-1 text-secondary" style="font-size:1.5rem"></i>
                <span class="small fw-bold text-secondary">Tandai Selesai</span>
              </label>
              <label class="flex-fill border rounded-3 text-center p-3" style="cursor:pointer">
                <input type="radio" name="status" value="ditolak" class="d-none">
                <i class="bi bi-x-circle-fill d-block mb-1 text-danger" style="font-size:1.5rem"></i>
                <span class="small fw-bold text-danger">Tolak</span>
              </label>
            </div>
          </div>
          <div>
            <label class="form-label fw-semibold small">Catatan untuk Warga</label>
            <textarea name="catatan" class="form-control" rows="2"
                      placeholder="Konfirmasi lokasi, perubahan waktu, alasan penolakan..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-success px-4"><i class="bi bi-check-lg me-1"></i>Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('modalJadwal').addEventListener('show.bs.modal',function(e){
  const b=e.relatedTarget;
  document.getElementById('mId').value=b.dataset.id;
  document.getElementById('mNama').textContent=b.dataset.nama;
  document.getElementById('mKeperluan').textContent=b.dataset.keperluan;
  document.getElementById('mTanggal').textContent=b.dataset.tanggal;
  document.getElementById('mJam').textContent=b.dataset.jam;
});
document.querySelectorAll('#modalJadwal label').forEach(l=>{
  l.addEventListener('click',function(){
    document.querySelectorAll('#modalJadwal label').forEach(x=>{x.style.background='';x.style.borderColor='';});
    const inp=this.querySelector('input');
    if(inp.value==='dikonfirmasi'){this.style.background='#f0fdf4';this.style.borderColor='#22c55e';}
    else if(inp.value==='ditolak'){this.style.background='#fff5f5';this.style.borderColor='#ef4444';}
    else{this.style.background='#f9fafb';this.style.borderColor='#6b7280';}
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
