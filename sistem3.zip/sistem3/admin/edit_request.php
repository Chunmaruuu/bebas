<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Permintaan Edit Data';
$basePath  = '..';
$pdo       = getDB();

// Proses approve / tolak
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rid     = intval($_POST['id']);
    $status  = $_POST['status'];
    $catatan = trim($_POST['catatan'] ?? '');
    $uid     = currentUser()['id'];

    $req = $pdo->prepare("SELECT * FROM edit_profil_request WHERE id=?");
    $req->execute([$rid]); $req = $req->fetch();

    if ($req && $status === 'disetujui') {
        $dataBaru   = json_decode($req['data_baru'], true);
        $userId     = $req['user_id'];
        $tipeReq    = $req['tipe_request'] ?? 'akun';

        if ($tipeReq === 'kependudukan') {
            // Update tabel penduduk
            $kepFields = ['nik','no_kk','tempat_lahir','tanggal_lahir','agama','status_kawin',
                          'status_hubungan','pekerjaan','pendidikan','alamat','no_rt','no_rw',
                          'kode_pos','kelurahan','kecamatan','kabupaten','provinsi'];
            $setParts = [];
            $vals     = [];
            foreach ($kepFields as $f) {
                if (isset($dataBaru[$f])) {
                    $setParts[] = "$f=?";
                    $vals[]     = $dataBaru[$f];
                }
            }
            if ($setParts) {
                $vals[] = $userId;
                $pdo->prepare("UPDATE penduduk SET " . implode(',', $setParts) . " WHERE user_id=?")
                    ->execute($vals);
            }
            setFlash('success','Data kependudukan warga berhasil diperbarui.');
        } else {
            // Update users table (data akun)
            if (!empty($dataBaru['nama']))  $pdo->prepare("UPDATE users SET nama=? WHERE id=?")->execute([$dataBaru['nama'],$userId]);
            if (!empty($dataBaru['no_hp'])) $pdo->prepare("UPDATE users SET no_hp=? WHERE id=?")->execute([$dataBaru['no_hp'],$userId]);
            if (!empty($dataBaru['email'])) $pdo->prepare("UPDATE users SET email=? WHERE id=?")->execute([$dataBaru['email'],$userId]);
            if (!empty($dataBaru['password_baru'])) {
                $hashed = password_hash($dataBaru['password_baru'], PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hashed,$userId]);
            }
            setFlash('success','Perubahan data akun warga berhasil diterapkan.');
        }
    } elseif ($req && $status === 'ditolak') {
        setFlash('warning','Permintaan edit ditolak.');
    }

    $pdo->prepare("UPDATE edit_profil_request SET status=?,catatan_admin=?,diproses_oleh=? WHERE id=?")
        ->execute([$status,$catatan,$uid,$rid]);
    redirect('edit_request.php');
}

$tab = $_GET['tab'] ?? 'menunggu';
$list = $pdo->prepare(
    "SELECT er.*, u.nama as nama_warga, u.username, u.no_hp as hp_warga
     FROM edit_profil_request er
     JOIN users u ON er.user_id=u.id
     WHERE er.status=?
     ORDER BY er.created_at DESC"
);
$list->execute([$tab]); $list = $list->fetchAll();

$counts = [
    'menunggu'  => $pdo->query("SELECT COUNT(*) FROM edit_profil_request WHERE status='menunggu'")->fetchColumn(),
    'disetujui' => $pdo->query("SELECT COUNT(*) FROM edit_profil_request WHERE status='disetujui'")->fetchColumn(),
    'ditolak'   => $pdo->query("SELECT COUNT(*) FROM edit_profil_request WHERE status='ditolak'")->fetchColumn(),
];

include __DIR__ . '/../includes/header.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 sidebar d-none d-md-block"><?php include __DIR__ . '/sidebar.php'; ?></div>
<div class="col-md-10 py-4 px-4">

<h4 class="fw-bold mb-4"><i class="bi bi-pencil-square text-warning me-2"></i>Permintaan Edit Data Warga</h4>
<?= flashHtml() ?>

<!-- Tabs -->
<div class="d-flex gap-2 mb-4 flex-wrap">
  <?php foreach (['menunggu'=>['warning','hourglass-split'],'disetujui'=>['success','check-circle'],'ditolak'=>['danger','x-circle']] as $t=>[$c,$ic]): ?>
  <a href="?tab=<?=$t?>" class="btn btn-<?=$tab===$t?$c:'outline-'.$c?> d-flex align-items-center gap-2">
    <i class="bi bi-<?=$ic?>"></i> <?=ucfirst($t)?>
    <span class="badge bg-white text-<?=$c?>"><?=$counts[$t]?></span>
  </a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header"><i class="bi bi-list-ul me-1"></i>Permintaan Edit — <?=ucfirst($tab)?> (<?=count($list)?>)</div>
  <?php if (empty($list)): ?>
  <div class="card-body text-center text-muted py-5">
    <i class="bi bi-inbox fs-1 d-block mb-2 opacity-25"></i>
    Tidak ada permintaan edit berstatus <strong><?=$tab?></strong>.
  </div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0 small">
      <thead class="table-light">
        <tr><th>Warga</th><th>Username</th><th>Tipe</th><th>Field Diubah</th><th>Data Lama → Baru</th><th>Tgl Ajukan</th><th>Status</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($list as $r):
          $dataLama = json_decode($r['data_lama'], true) ?? [];
          $dataBaru = json_decode($r['data_baru'], true) ?? [];
          $fields   = json_decode($r['field_diubah'], true) ?? [];
        ?>
        <tr>
          <td class="fw-semibold"><?=clean($r['nama_warga'])?></td>
          <td><span class="badge <?=($r['tipe_request']??'akun')==='kependudukan'?'bg-info text-dark':'bg-light text-dark border'?>"><?=($r['tipe_request']??'akun')==='kependudukan'?'Kependudukan':'Akun'?></span></td>
          <td class="text-muted">@<?=clean($r['username'])?></td>
          <td>
            <?php foreach ($fields as $f): ?>
            <span class="badge bg-light text-dark border me-1"><?=clean($f)?></span>
            <?php endforeach; ?>
          </td>
          <td style="max-width:220px">
            <?php foreach ($fields as $f):
              if ($f === 'password_baru') continue;
              $lama = $dataLama[$f] ?? '—';
              $baru = $dataBaru[$f] ?? '—';
            ?>
            <div class="d-flex align-items-center gap-1 mb-1 small text-truncate" title="<?=clean($lama)?> → <?=clean($baru)?>">
              <span class="text-danger text-decoration-line-through text-truncate" style="max-width:80px"><?=clean($lama)?></span>
              <i class="bi bi-arrow-right text-muted flex-shrink-0"></i>
              <span class="text-success fw-semibold text-truncate" style="max-width:80px"><?=clean($baru)?></span>
            </div>
            <?php endforeach; ?>
            <?php if (in_array('password_baru',$fields)): ?>
            <span class="badge bg-info text-white">Ganti password</span>
            <?php endif; ?>
          </td>
          <td><?=formatTanggal(date('Y-m-d',strtotime($r['created_at'])))?></td>
          <td><?=statusBadge($r['status'])?></td>
          <td>
            <?php if ($r['status'] === 'menunggu'): ?>
            <button class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#modalEdit"
                    data-id="<?=$r['id']?>"
                    data-nama="<?=clean($r['nama_warga'])?>"
                    data-fields="<?=clean(implode(', ',$fields))?>"
                    data-lama="<?=htmlspecialchars(json_encode($dataLama,JSON_UNESCAPED_UNICODE))?>"
                    data-baru="<?=htmlspecialchars(json_encode($dataBaru,JSON_UNESCAPED_UNICODE))?>">
              <i class="bi bi-eye me-1"></i>Tinjau
            </button>
            <?php else: ?>
            <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

</div></div></div>

<!-- Modal Tinjau Edit -->
<div class="modal fade" id="modalEdit" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content rounded-3">
      <div class="modal-header">
        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i>Tinjau Permintaan Edit</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body">
          <input type="hidden" name="id" id="mId">
          <div class="mb-3">
            <div class="fw-semibold mb-1"><i class="bi bi-person me-1"></i>Warga: <span id="mNama" class="text-success"></span></div>
            <div class="small text-muted">Field yang diubah: <span id="mFields" class="fw-semibold text-dark"></span></div>
          </div>
          <div id="mDiff" class="mb-3"></div>
          <div class="mb-3">
            <label class="form-label fw-semibold small">Keputusan</label>
            <div class="d-flex gap-2">
              <label class="flex-fill border rounded-3 text-center p-3" id="optS" style="cursor:pointer;background:#f0fdf4;border-color:#22c55e !important">
                <input type="radio" name="status" value="disetujui" class="d-none" checked>
                <i class="bi bi-check-circle-fill d-block mb-1 text-success" style="font-size:1.5rem"></i>
                <span class="small fw-bold text-success">Setujui & Terapkan</span>
              </label>
              <label class="flex-fill border rounded-3 text-center p-3" id="optT" style="cursor:pointer">
                <input type="radio" name="status" value="ditolak" class="d-none">
                <i class="bi bi-x-circle-fill d-block mb-1 text-danger" style="font-size:1.5rem"></i>
                <span class="small fw-bold text-danger">Tolak</span>
              </label>
            </div>
          </div>
          <div>
            <label class="form-label fw-semibold small">Catatan untuk Warga</label>
            <textarea name="catatan" class="form-control" rows="2"
                      placeholder="Alasan penolakan atau keterangan tambahan..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-success px-4"><i class="bi bi-check-lg me-1"></i>Simpan Keputusan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('modalEdit').addEventListener('show.bs.modal',function(e){
  const b=e.relatedTarget;
  document.getElementById('mId').value=b.dataset.id;
  document.getElementById('mNama').textContent=b.dataset.nama;
  document.getElementById('mFields').textContent=b.dataset.fields;
  try {
    const lama=JSON.parse(b.dataset.lama||'{}');
    const baru=JSON.parse(b.dataset.baru||'{}');
    let html='<table class="table table-sm table-bordered small mb-0"><thead class="table-light"><tr><th>Field</th><th class="text-danger">Data Lama</th><th class="text-success">Data Baru</th></tr></thead><tbody>';
    for(const k in baru){
      if(k==='password_baru'){html+=`<tr><td>password</td><td class="text-muted fst-italic">(terenkripsi)</td><td class="text-success fw-bold">••••••</td></tr>`;continue;}
      html+=`<tr><td>${k}</td><td class="text-danger">${lama[k]||'—'}</td><td class="text-success fw-bold">${baru[k]||'—'}</td></tr>`;
    }
    html+='</tbody></table>';
    document.getElementById('mDiff').innerHTML=html;
  } catch(err){}
});
[document.getElementById('optS'),document.getElementById('optT')].forEach(el=>{
  el.addEventListener('click',function(){
    document.getElementById('optS').style.background='';document.getElementById('optS').style.borderColor='';
    document.getElementById('optT').style.background='';document.getElementById('optT').style.borderColor='';
    const inp=this.querySelector('input');inp.checked=true;
    if(inp.value==='disetujui'){this.style.background='#f0fdf4';this.style.borderColor='#22c55e';}
    else{this.style.background='#fff5f5';this.style.borderColor='#ef4444';}
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
