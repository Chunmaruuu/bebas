<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Kelola User';
$basePath  = '..';
$pdo       = getDB();
$action    = $_GET['action'] ?? 'list';
$id        = intval($_GET['id'] ?? 0);
$error     = '';

// Delete user (tidak bisa hapus diri sendiri)
if ($action === 'delete' && $id) {
    if ($id === currentUser()['id']) {
        setFlash('danger', 'Tidak bisa menghapus akun sendiri.');
    } else {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
        setFlash('success', 'User berhasil dihapus.');
    }
    redirect('users.php');
}

// Simpan user baru
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $role     = $_POST['role'];
    $no_hp    = trim($_POST['no_hp']);
    $pw       = trim($_POST['password']);

    if (!$nama || !$username) { $error = 'Nama dan username wajib diisi.'; }
    elseif (!$id && !$pw)     { $error = 'Password wajib diisi untuk user baru.'; }
    else {
        // Cek username unik
        $cek = $pdo->prepare("SELECT id FROM users WHERE username=? AND id!=?");
        $cek->execute([$username, $id ?: 0]);
        if ($cek->fetch()) {
            $error = 'Username sudah dipakai.';
        } else {
            if ($id) {
                if ($pw) {
                    $pdo->prepare("UPDATE users SET nama=?,username=?,role=?,no_hp=?,password=? WHERE id=?")
                        ->execute([$nama, $username, $role, $no_hp, password_hash($pw, PASSWORD_DEFAULT), $id]);
                } else {
                    $pdo->prepare("UPDATE users SET nama=?,username=?,role=?,no_hp=? WHERE id=?")
                        ->execute([$nama, $username, $role, $no_hp, $id]);
                }
            } else {
                $pdo->prepare("INSERT INTO users (nama,username,password,role,no_hp) VALUES (?,?,?,?,?)")
                    ->execute([$nama, $username, password_hash($pw, PASSWORD_DEFAULT), $role, $no_hp]);
            }
            setFlash('success', $id ? 'User diperbarui.' : 'User baru ditambahkan.');
            redirect('users.php');
        }
    }
}

$editData = [];
if ($action === 'edit' && $id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([$id]);
    $editData = $stmt->fetch();
}

$userList = $pdo->query("SELECT u.*, p.nik FROM users u LEFT JOIN penduduk p ON p.user_id=u.id ORDER BY u.created_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar d-none d-md-block"><?php include 'sidebar.php'; ?></div>
    <div class="col-md-10 py-4 px-4">
      <?= flashHtml() ?>

      <?php if ($action === 'list'): ?>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0"><i class="bi bi-people-fill text-primary"></i> Kelola User</h4>
        <a href="?action=add" class="btn btn-rt"><i class="bi bi-plus-lg"></i> Tambah User</a>
      </div>
      <div class="card">
        <div class="card-body p-0">
          <table class="table table-hover align-middle mb-0">
            <thead><tr><th>#</th><th>Nama</th><th>Username</th><th>Role</th><th>No. HP</th><th>NIK Terhubung</th><th>Aksi</th></tr></thead>
            <tbody>
              <?php foreach ($userList as $i => $u): ?>
              <tr>
                <td class="small text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= clean($u['nama']) ?></td>
                <td><code class="small"><?= clean($u['username']) ?></code></td>
                <td>
                  <span class="badge <?= $u['role']==='admin' ? 'bg-warning text-dark' : 'bg-secondary' ?>">
                    <?= ucfirst($u['role']) ?>
                  </span>
                </td>
                <td class="small text-muted"><?= clean($u['no_hp'] ?: '-') ?></td>
                <td><code class="small"><?= clean($u['nik'] ?: '-') ?></code></td>
                <td>
                  <a href="?action=edit&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-pencil"></i>
                  </a>
                  <?php if ($u['id'] !== currentUser()['id']): ?>
                  <a href="?action=delete&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger"
                     onclick="return confirm('Hapus user <?= clean($u['username']) ?>?')">
                    <i class="bi bi-trash"></i>
                  </a>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php else: ?>
      <div class="d-flex align-items-center gap-3 mb-3">
        <a href="users.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
        <h4 class="fw-bold mb-0"><?= $id ? 'Edit' : 'Tambah' ?> User</h4>
      </div>
      <?php if ($error): ?><div class="alert alert-danger small"><?= $error ?></div><?php endif; ?>
      <div class="card" style="max-width:580px">
        <div class="card-body">
          <form method="POST">
            <div class="mb-3">
              <label class="form-label fw-600 small">Nama Lengkap *</label>
              <input type="text" name="nama" class="form-control"
                     value="<?= clean($editData['nama'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-600 small">Username *</label>
              <input type="text" name="username" class="form-control"
                     value="<?= clean($editData['username'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-600 small">Role</label>
              <select name="role" class="form-select">
                <option value="warga" <?= ($editData['role'] ?? 'warga') === 'warga' ? 'selected' : '' ?>>Warga</option>
                <option value="admin" <?= ($editData['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin (RT)</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label fw-600 small">No. HP</label>
              <input type="text" name="no_hp" class="form-control"
                     value="<?= clean($editData['no_hp'] ?? '') ?>">
            </div>
            <div class="mb-4">
              <label class="form-label fw-600 small">
                Password <?= $id ? '<span class="text-muted">(kosongkan jika tidak diubah)</span>' : '*' ?>
              </label>
              <input type="password" name="password" class="form-control"
                     <?= $id ? '' : 'required' ?>>
            </div>
            <div class="d-flex gap-2">
              <button type="submit" class="btn btn-rt px-4"><i class="bi bi-save"></i> Simpan</button>
              <a href="users.php" class="btn btn-outline-secondary">Batal</a>
            </div>
          </form>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
