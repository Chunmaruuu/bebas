<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
requireAdmin();

$pageTitle = 'Data Tamu';
$basePath  = '..';
$pdo       = getDB();
$action    = $_GET['action'] ?? 'list';

// Update status tamu jadi 'sudah pergi'
if ($action === 'pergi' && ($id = intval($_GET['id']))) {
    $pdo->prepare("UPDATE laporan_tamu SET status='sudah pergi',tanggal_pergi=? WHERE id=?")
        ->execute([today(), $id]);
    setFlash('success', 'Status tamu diperbarui.');
    redirect('tamu.php');
}

$tamuList = $pdo->query(
    "SELECT lt.*, pd.nama as nama_pemilik, pd.alamat
     FROM laporan_tamu lt
     JOIN penduduk pd ON lt.penduduk_id=pd.id
     ORDER BY lt.created_at DESC"
)->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar d-none d-md-block"><?php include 'sidebar.php'; ?></div>
    <div class="col-md-10 py-4 px-4">
      <h4 class="fw-bold mb-3"><i class="bi bi-person-plus text-warning"></i> Data Tamu Menginap</h4>
      <?= flashHtml() ?>
      <div class="card">
        <div class="card-body p-0">
          <table class="table table-hover align-middle mb-0">
            <thead><tr>
              <th>#</th><th>Nama Tamu</th><th>NIK Tamu</th><th>Di Rumah</th>
              <th>Hubungan</th><th>Tgl Datang</th><th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>
              <?php foreach ($tamuList as $i => $t): ?>
              <tr>
                <td class="small text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= clean($t['nama_tamu']) ?></td>
                <td><code class="small"><?= clean($t['nik_tamu'] ?? '-') ?></code></td>
                <td class="small">
                  <?= clean($t['nama_pemilik']) ?>
                  <div class="text-muted" style="font-size:.75rem"><?= clean($t['alamat'] ?? '') ?></div>
                </td>
                <td class="small"><?= clean($t['hubungan']) ?></td>
                <td class="small text-muted"><?= formatTanggal($t['tanggal_datang']) ?></td>
                <td><?= statusBadge($t['status']) ?></td>
                <td>
                  <?php if ($t['status'] === 'menginap'): ?>
                  <a href="?action=pergi&id=<?= $t['id'] ?>" class="btn btn-sm btn-outline-secondary"
                     onclick="return confirm('Tandai tamu sudah pergi?')">
                    <i class="bi bi-door-open"></i> Tandai Pergi
                  </a>
                  <?php else: ?>
                  <span class="text-muted small"><?= formatTanggal($t['tanggal_pergi'] ?? '') ?></span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($tamuList)): ?>
              <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data tamu.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
