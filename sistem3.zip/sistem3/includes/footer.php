<?php
// includes/footer.php
$waNumber = '6285702045509';
$waPesan  = urlencode('Halo Pak RT, saya warga RT 001/RW 003 ingin bertanya mengenai administrasi.');
$waUrl    = "https://wa.me/{$waNumber}?text={$waPesan}";
$isWarga  = isLoggedIn() && !isAdmin();
?>
</div><!-- /.main-content -->

<?php if ($isWarga): ?>
<!-- Footer profesional untuk warga -->
<footer class="fr-footer">

  <!-- Top section: brand + navigasi + kontak -->
  <div class="fr-footer-top">
    <div class="container">
      <div class="row g-4">

        <!-- Kolom 1: Brand & Identitas -->
        <div class="col-lg-4 col-md-6">
          <div class="fr-footer-brand">
            <div class="fr-footer-logo">
              <i class="bi bi-stars fr-footer-rune"></i>
            </div>
            <div>
              <div class="fr-footer-title">Sistem RT 001/RW 003</div>
              <div class="fr-footer-subtitle">Portal Administrasi Warga</div>
            </div>
          </div>
          <div class="fr-footer-divider"></div>
          <p class="fr-footer-desc">
            Melayani warga Kelurahan Maguwoharjo dengan sistem administrasi
            berbasis digital yang mudah, cepat, dan transparan.
          </p>
          <div class="fr-footer-badge mt-3">
            <span class="badge-rt">RT 001</span>
            <span class="badge-rw">RW 003</span>
          </div>
        </div>

        <!-- Kolom 2: Layanan Warga -->
        <div class="col-lg-2 col-md-6">
          <div class="fr-footer-heading">Layanan</div>
          <ul class="fr-footer-links">
            <li>
              <a href="<?= ($basePath??'..') ?>/pages/lapor_datang.php">
                <i class="bi bi-box-arrow-in-right me-2"></i>Lapor Datang
              </a>
            </li>
            <li>
              <a href="<?= ($basePath??'..') ?>/pages/lapor_pindah.php">
                <i class="bi bi-box-arrow-right me-2"></i>Lapor Pindah
              </a>
            </li>
            <li>
              <a href="<?= ($basePath??'..') ?>/pages/lapor_tamu.php">
                <i class="bi bi-person-badge me-2"></i>Lapor Tamu
              </a>
            </li>
            <li>
              <a href="<?= ($basePath??'..') ?>/pages/jadwal_rt.php">
                <i class="bi bi-calendar2-check me-2"></i>Jadwal Bertemu RT
              </a>
            </li>
            <li>
              <a href="<?= ($basePath??'..') ?>/pages/anggota_keluarga.php">
                <i class="bi bi-people me-2"></i>Data Keluarga
              </a>
            </li>
          </ul>
        </div>

        <!-- Kolom 3: Jam Pelayanan -->
        <div class="col-lg-3 col-md-6">
          <div class="fr-footer-heading">Jam Pelayanan RT</div>
          <ul class="fr-footer-hours">
            <li>
              <span class="fr-day">Senin – Jumat</span>
              <span class="fr-time">08:00 – 16:00</span>
            </li>
            <li>
              <span class="fr-day">Sabtu</span>
              <span class="fr-time">08:00 – 12:00</span>
            </li>
            <li>
              <span class="fr-day">Minggu &amp; Libur</span>
              <span class="fr-time">Tutup</span>
            </li>
          </ul>
          <div class="fr-footer-divider mt-3"></div>
          <p class="fr-footer-desc mt-2" style="font-size:.78rem">
            <i class="bi bi-geo-alt me-1" style="color:rgba(184,148,63,.6)"></i>
            Kel. Maguwoharjo, Kec. Depok,<br>Kab. Sleman, D.I. Yogyakarta
          </p>
        </div>

        <!-- Kolom 4: Kontak & WA -->
        <div class="col-lg-3 col-md-6">
          <div class="fr-footer-heading">Hubungi Kami</div>
          <p class="fr-footer-desc mb-3">
            Butuh bantuan administrasi atau informasi seputar RT? Hubungi langsung melalui WhatsApp.
          </p>
        </div>

      </div><!-- /.row -->
    </div><!-- /.container -->
  </div><!-- /.fr-footer-top -->

  <!-- Bottom bar: copyright -->
  <div class="fr-footer-bottom">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6 text-center text-md-start">
          <span class="fr-copyright">
            &copy; <?= date('Y') ?> Sistem RT 001/RW 003 &mdash; Maguwoharjo, Sleman
          </span>
        </div>
        <div class="col-md-6 text-center text-md-end mt-1 mt-md-0">
          <span class="fr-tagline">Melayani dengan tulus, membangun bersama.</span>
        </div>
      </div>
    </div>
  </div><!-- /.fr-footer-bottom -->

</footer>

<!-- Tombol WA Float -->
<style>
  /* Sembunyikan tombol WA saat modal Bootstrap aktif */
  body.modal-open #waFloat { display: none !important; }
</style>
<a href="<?= $waUrl ?>" target="_blank" id="waFloat"
   style="position:fixed;bottom:1.5rem;right:1.5rem;background:#25D366;color:#fff;border-radius:50px;
          padding:.6rem 1.1rem .6rem .8rem;display:flex;align-items:center;gap:.5rem;
          text-decoration:none;font-size:.82rem;font-weight:600;box-shadow:0 4px 16px rgba(37,211,102,.4);
          z-index:900;transition:transform .2s" title="Hubungi Pak RT via WhatsApp"
   onmouseover="this.style.transform='scale(1.06)'" onmouseout="this.style.transform='scale(1)'">
  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
    <path d="M13.601 2.326A7.85 7.85 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.9 7.9 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.9 7.9 0 0 0 13.6 2.326zM7.994 14.521a6.6 6.6 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.56 6.56 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592m3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.73.73 0 0 0-.529.247c-.182.198-.691.677-.691 1.654s.71 1.916.81 2.049c.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232"/>
  </svg>
  Hubungi RT
</a>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.alert-dismissible').forEach(el=>{
  setTimeout(()=>{try{bootstrap.Alert.getOrCreateInstance(el).close();}catch(e){}},5000);
});
</script>
<?php if(isset($extraJs)): ?><?= $extraJs ?><?php endif; ?>
</body></html>
