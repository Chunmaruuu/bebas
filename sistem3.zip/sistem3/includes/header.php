<?php
// includes/header.php
$pageTitle = $pageTitle ?? 'Sistem RT';
$user = currentUser();
$basePath = $basePath ?? '..';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= clean($pageTitle) ?> — RT 001/RW 003</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Crimson+Pro:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap" rel="stylesheet">
  <link href="<?= $basePath ?>/assets/css/frieren.css" rel="stylesheet">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-rt">
  <div class="container-fluid px-4">
    <a class="navbar-brand" href="<?= $basePath ?>/index.php">
      <span class="brand-icon"><i class="bi bi-stars"></i></span>
      Sistem RT 001/RW 003
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"
            style="color:rgba(240,237,232,.7)">
      <i class="bi bi-list fs-5"></i>
    </button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?= $basePath ?>/index.php">
            <i class="bi bi-house me-1"></i>Beranda
          </a>
        </li>
        <?php if (isLoggedIn()): ?>
        <?php if (!isAdmin()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?= $basePath ?>/pages/jadwal_rt.php">
            <i class="bi bi-calendar2-check me-1"></i>Jadwal Bertemu RT
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= $basePath ?>/pages/anggota_keluarga.php">
            <i class="bi bi-people me-1"></i>Keluarga
          </a>
        </li>
        <?php endif; ?>
        <?php if (isAdmin()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?= $basePath ?>/admin/dashboard.php">
            <i class="bi bi-speedometer2 me-1"></i>Dashboard Admin
          </a>
        </li>
        <?php endif; ?>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <?php if (isLoggedIn()): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i>
            <?= clean($user['nama']) ?>
            <span class="badge <?= isAdmin() ? 'bg-warning text-dark' : 'bg-info' ?>" style="font-size:.68rem">
              <?= isAdmin() ? 'Admin' : 'Warga' ?>
            </span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <?php if (!isAdmin()): ?>
            <li><a class="dropdown-item" href="<?= $basePath ?>/pages/profil.php">
              <i class="bi bi-person me-2"></i>Profil Saya</a></li>
            <li><hr class="dropdown-divider"></li>
            <?php endif; ?>
            <li><a class="dropdown-item text-danger" href="<?= $basePath ?>/auth/logout.php">
              <i class="bi bi-box-arrow-right me-2"></i>Keluar</a></li>
          </ul>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <a class="btn btn-warning btn-sm px-3 ms-2 nav-link"
             href="<?= $basePath ?>/auth/login.php">
            <i class="bi bi-box-arrow-in-right me-1"></i>Masuk
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="main-content">
